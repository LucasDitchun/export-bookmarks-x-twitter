(function(){"use strict";function V(e){return typeof e=="object"&&e!==null&&!Array.isArray(e)}function R(e){if(typeof e!="string"||e.length===0||e.length>2048)return null;try{const t=new URL(e);return t.protocol!=="https:"||t.hostname!=="pbs.twimg.com"||t.username!==""||t.password!==""||t.port!==""?null:(t.hash="",t.toString())}catch{return null}}function G(e){const t=new URL(e);return`${t.origin}${t.pathname}`}function j(e){return R(e.currentSrc)??R(e.getAttribute("src")||e.src)}function le(e){const t=new Set(e.filter(({thumbnailUrl:a})=>a!==null).map(({postUrl:a})=>a)),r=[],n=new Set;for(const a of e){if(a.thumbnailUrl===null&&t.has(a.postUrl))continue;const o=`${a.postUrl}\0${a.thumbnailUrl===null?"":G(a.thumbnailUrl)}`;if(!n.has(o)&&(n.add(o),r.push(a),r.length===4))break}return r}function ue(e,t){const r=[],n=new Set;for(const i of Array.from(e.querySelectorAll('[data-testid="tweetPhoto"] img'))){const s=j(i);if(s===null)continue;const l=G(s);if(!n.has(l)&&(n.add(l),r.push(s),r.length===16))break}const o=Array.from(e.querySelectorAll("video")).map(i=>({thumbnailUrl:R(i.poster||i.getAttribute("poster")),postUrl:t}));for(const i of Array.from(e.querySelectorAll('[data-testid="videoPlayer"], [data-testid="videoComponent"]'))){if(i.querySelector("video"))continue;const s=i.querySelector("img");o.push({thumbnailUrl:s?j(s):null,postUrl:t})}return{images:r,videos:le(o)}}function me(e,t){return!V(e)||!Array.isArray(e.images)||!Array.isArray(e.videos)||e.images.length>16||e.videos.length>4||e.images.some(r=>typeof r!="string"||R(r)!==r)?!1:e.videos.every(r=>V(r)&&r.postUrl===t&&(r.thumbnailUrl===null||typeof r.thumbnailUrl=="string"&&R(r.thumbnailUrl)===r.thumbnailUrl))}const fe=/^\/([A-Za-z0-9_]+)\/status\/(\d+)(?:\/|$)/;function z(e){return(e?.textContent??"").replace(/\s+/g," ").trim()}function pe(e){const t=e.querySelector("time[datetime]")?.closest("a[href]"),r=Array.from(e.querySelectorAll("a[href]"));if(t){const n=r.indexOf(t);n>=0&&r.splice(n,1),r.unshift(t)}for(const n of r){let a;try{a=new URL(n.getAttribute("href")??"","https://x.com")}catch{continue}if(a.hostname!=="x.com"&&a.hostname!=="www.x.com")continue;const o=fe.exec(a.pathname);if(!o)continue;const i=o[1],s=o[2];if(!(!i||!s))return{id:s,username:i,url:`https://x.com/${i}/status/${s}`}}return null}function ge(e,t){const r=e.querySelector('[data-testid="User-Name"]'),n=Array.from(r?.querySelectorAll("a[href]")??[]).find(i=>i.getAttribute("href")?.toLocaleLowerCase()===`/${t.toLocaleLowerCase()}`),a=z(n);return a&&!a.startsWith("@")?a:Array.from(r?.querySelectorAll("span")??[]).map(z).filter(i=>i.length>0&&!i.startsWith("@")&&i!=="·"&&i.toLocaleLowerCase()!==t.toLocaleLowerCase())[0]??t}function $(e=document){const t=new Map,r=Array.from(e.querySelectorAll('article[data-testid="tweet"]')),n=e instanceof Element&&e.matches('article[data-testid="tweet"]')?[e,...r]:r;for(const a of n){const o=pe(a);if(!o||t.has(o.id))continue;const i=a.querySelector("time[datetime]");t.set(o.id,{id:o.id,text:z(a.querySelector('[data-testid="tweetText"]')),url:o.url,author:{id:o.username.toLocaleLowerCase(),username:o.username,name:ge(a,o.username)},postCreatedAt:i?.dateTime??"",media:ue(a,o.url)})}return[...t.values()]}const he=['main [role="progressbar"]','main [data-testid="progressBar"]','main [aria-busy="true"]','main[aria-busy="true"]'].join(",");function be(e){if(e.closest('[hidden], [aria-hidden="true"]'))return!0;const t=e.ownerDocument.defaultView;if(!t)return!1;const r=t.getComputedStyle(e);return r.display==="none"||r.visibility==="hidden"}function B(e){return Array.from(e.querySelectorAll(he)).some(t=>!be(t))}function ye({scrollTop:e,viewportHeight:t,documentHeight:r},n=8){return e+t>=r-n}async function ke({scan:e,checkpointIds:t=[],isLoading:r=()=>!1,isAtEnd:n=()=>!0,isPageValid:a=()=>!0,scroll:o,waitForContent:i,onBatch:s,onProgress:l,signal:d,idlePassLimit:b=4,maximumLoadingPasses:u=180,batchSize:w=100}){if(!Number.isSafeInteger(w)||w<1||w>100)throw new RangeError("Scrape batch size must be between 1 and 100.");if(!Number.isSafeInteger(b)||b<1)throw new RangeError("Idle pass limit must be a positive integer.");if(!Number.isSafeInteger(u)||u<1)throw new RangeError("Loading pass limit must be a positive integer.");const x=new Set,v=new Set(t);let y=0,c=0,p=0,m=0,f=-1;for(;!d?.aborted;){if(!a())return{status:"incomplete",fetched:y,errorCode:"capture_navigation_changed"};const h=[];let g=!1;for(const O of e()){if(x.has(O.id))continue;const{id:_}=O;if(x.add(_),h.push(O),c=v.has(_)?c+1:0,v.size>0&&c>=3){g=!0;break}}const k=r(),T=n(),A=h.length===0&&!k&&T;if(h.length>0){p=0;const O=y;for(let _=0;_<h.length&&!d?.aborted;_+=w){const ce=h.slice(_,_+w);await s(ce),y+=ce.length}y>O&&(m=0)}else(k||!T)&&(p=0);f!==y&&(await l({fetched:y}),f=y);const S=i(d);!k&&!A&&!g&&o();const E=await S;if(!a())return{status:"incomplete",fetched:y,errorCode:"capture_navigation_changed"};const I=r(),K=n();if((k||E?.loadingObserved||I)&&(m+=1,m>=u))return{status:"incomplete",fetched:y,errorCode:"capture_loading_timeout"};if(g&&!d?.aborted){if(!k&&E?.reason==="timeout"&&!E?.loadingObserved&&!I)return{status:"completed",fetched:y,completionReason:"checkpoint_stop"};c=0}if(A&&!d?.aborted&&E?.reason!=="activity"&&!E?.loadingObserved&&!I&&K){if(p+=1,p>=b)return{status:"completed",fetched:y,...v.size>0?{completionReason:"stable_end"}:{}}}else(E?.loadingObserved||E?.reason==="activity"||I||!K)&&(p=0)}return{status:"cancelled",fetched:y}}const X='article[data-testid="tweet"]';function we(e){return Array.from(e.querySelectorAll(X)).filter(t=>!t.parentElement?.closest(X))}function ve(e,{viewportHeight:t,scrollBy:r}){const n=we(e).at(-1),a=n&&n.getBoundingClientRect().top>t*.25;return!n||!a?(r(),"fallback"):(n.scrollIntoView({behavior:"auto",block:"start"}),"anchor")}const Ae='article[data-testid="tweet"] a[href*="/status/"]',W='[role="progressbar"], [data-testid="progressBar"], [aria-busy="true"]';function Y(e){return e.some(t=>Array.from(t.addedNodes).some(r=>{if(r.nodeType!==1)return!1;const n=r;return n.matches(W)||n.querySelector(W)!==null}))}function Q(e){const t=Array.from(e.querySelectorAll(Ae),r=>r.getAttribute("href")??"");return`${B(e.ownerDocument)?"loading":"idle"}|${t.join("|")}`}function xe({root:e,view:t,signal:r,settleMs:n=75,scrollSettleMs:a=180,maximumWaitMs:o=1100}){return r?.aborted?Promise.resolve({reason:"aborted",loadingObserved:!1}):new Promise(i=>{const s=Q(e);let l=B(e.ownerDocument),d=!1,b;const u=m=>{if(d)return;d=!0;const f=c.takeRecords(),h=Y(f);l||=h||B(e.ownerDocument),c.disconnect(),b!==void 0&&t.clearTimeout(b),t.clearTimeout(p),t.removeEventListener("scroll",v),r?.removeEventListener("abort",y),i({reason:m==="timeout"&&h?"activity":m,loadingObserved:l})},w=(m,f)=>{b!==void 0&&t.clearTimeout(b),b=t.setTimeout(()=>u(m),f)},x=m=>{const f=Y(m);if(l||=f||B(e.ownerDocument),f){w("activity",n);return}Q(e)!==s&&w("activity",n)},v=()=>w("activity",a),y=()=>u("aborted"),c=new t.MutationObserver(x);c.observe(e,{attributes:!0,attributeFilter:["aria-busy","aria-hidden","data-testid","hidden","href","style"],childList:!0,subtree:!0}),t.addEventListener("scroll",v,{passive:!0});const p=t.setTimeout(()=>u("timeout"),o);r?.addEventListener("abort",y,{once:!0})})}const Ee=`
  :host {
    all: initial;
    color-scheme: light;
    font-family: "Segoe UI Variable Text", "Helvetica Neue", Helvetica, sans-serif;
    font-size: 15px;
    line-height: 1.4;
    position: fixed;
    inset: 0;
    z-index: 2147483647;
  }
  :host([hidden]) { display: none; }
  *, *::before, *::after { box-sizing: border-box; }
  .backdrop {
    align-items: center;
    background: rgb(15 20 25 / 48%);
    display: flex;
    inset: 0;
    justify-content: center;
    padding: 16px;
    position: absolute;
  }
  .dialog {
    background: #fff;
    border: 1px solid #cfd9de;
    border-radius: 20px;
    box-shadow: 0 20px 64px rgb(15 20 25 / 24%);
    color: #0f1419;
    max-height: min(680px, calc(100vh - 32px));
    max-width: 480px;
    overflow: auto;
    padding: 20px;
    width: 100%;
  }
  .heading { align-items: start; display: flex; gap: 12px; justify-content: space-between; }
  h2 { font-size: 1.25rem; letter-spacing: -0.02em; line-height: 1.2; margin: 0; }
  .bookmark {
    background: #f7f9f9;
    border-radius: 12px;
    color: #536471;
    display: -webkit-box;
    font-size: 0.875rem;
    margin: 14px 0;
    overflow: hidden;
    overflow-wrap: anywhere;
    padding: 10px 12px;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 2;
  }
  .status { border: 1px solid #cfd9de; border-radius: 12px; margin: 0 0 14px; padding: 10px 12px; }
  .status[data-state="success"] { border-color: #16733d; }
  .status[data-state="error"] { border-color: #a52222; }
  form { display: grid; gap: 12px; }
  form[hidden] { display: none; }
  label { color: #536471; display: block; font-size: 0.8125rem; font-weight: 700; }
  .metadata-grid { display: grid; gap: 12px; grid-template-columns: repeat(2, minmax(0, 1fr)); }
  .field { min-width: 0; }
  input, textarea {
    background: white;
    border: 1px solid #cfd9de;
    border-radius: 12px;
    color: #0f1419;
    display: block;
    font: inherit;
    margin-top: 5px;
    min-height: 44px;
    padding: 10px 12px;
    width: 100%;
  }
  textarea { min-height: 112px; resize: vertical; }
  button {
    background: #0f1419;
    border: 1px solid #0f1419;
    border-radius: 999px;
    color: white;
    cursor: pointer;
    font: 700 0.875rem/1 "Segoe UI Variable Text", "Helvetica Neue", Helvetica, sans-serif;
    min-height: 44px;
    padding: 10px 18px;
  }
  .close { background: transparent; color: #0f1419; flex: 0 0 auto; }
  .save { margin-top: 2px; width: 100%; }
  :focus-visible { outline: 3px solid #1d9bf0; outline-offset: 2px; }
  @media (max-width: 520px) {
    .backdrop { align-items: end; padding: 8px; }
    .dialog { border-radius: 20px 20px 12px 12px; max-height: calc(100vh - 16px); padding: 18px; }
    .metadata-grid { grid-template-columns: 1fr; }
  }
  @media (prefers-reduced-motion: reduce) {
    *, *::before, *::after { scroll-behavior: auto !important; }
  }
`;function Z(e,t,r,n,a){const o=e.createElement("label");o.htmlFor=r,o.textContent=n;const i=e.createElement("input");i.id=r,i.value=a,i.autocomplete="off";const s=e.createElement("div");return s.className="field",s.append(o,i),t.append(s),i}function Se(e){const{document:t}=e,r=t.createElement("bookmark-x-note-modal");r.hidden=!0,r.tabIndex=-1;const n=r.attachShadow({mode:"open"}),a=t.createElement("style");a.textContent=Ee;const o=t.createElement("div");o.className="backdrop";const i=t.createElement("section");i.className="dialog",i.setAttribute("role","dialog"),i.setAttribute("aria-modal","true"),i.setAttribute("aria-labelledby","bookmark-x-modal-title");const s=t.createElement("div");s.className="heading";const l=t.createElement("h2");l.id="bookmark-x-modal-title",l.textContent=e.title;const d=t.createElement("button");d.className="close",d.type="button",d.textContent=e.labels.close,s.append(l,d);const b=t.createElement("p");b.className="bookmark",b.textContent=e.bookmarkTitle;const u=t.createElement("p");u.className="status",u.setAttribute("role","status"),u.setAttribute("aria-live","polite"),u.setAttribute("aria-atomic","true"),u.dataset.state=e.labels.pending?"pending":"ready",u.textContent=e.labels.pending??"",u.hidden=u.textContent.length===0;const w=t.createElement("form"),x=t.createElement("label");x.htmlFor="bookmark-x-modal-description",x.textContent=e.labels.description;const v=t.createElement("textarea");v.id="bookmark-x-modal-description",v.maxLength=2e4,v.value=e.values?.description??"",w.append(x,v);const y=t.createElement("div");y.className="metadata-grid";const c=Z(t,y,"bookmark-x-modal-tags",e.labels.tags,e.values?.tags??""),p=Z(t,y,"bookmark-x-modal-folder",e.labels.folder,e.values?.folder??""),m=t.createElement("button");m.className="save",m.type="submit",m.textContent=e.labels.save,w.append(y,m),w.hidden=e.labels.pending!==void 0,i.append(s,b,u,w),o.append(i),n.append(a,o),t.body.append(r);let f=null;const h=()=>{r.hidden||(r.hidden=!0,e.onClose?.(),f?.focus())};return d.addEventListener("click",h),o.addEventListener("click",g=>{g.target===o&&h()}),r.addEventListener("keydown",g=>{if(g.key==="Escape"){g.preventDefault(),h();return}if(g.key!=="Tab")return;const k=[d,v,c,p,m],T=n.activeElement;g.shiftKey&&T===k[0]?(g.preventDefault(),k.at(-1)?.focus()):!g.shiftKey&&T===k.at(-1)&&(g.preventDefault(),k[0]?.focus())}),w.addEventListener("submit",g=>{g.preventDefault(),Promise.resolve(e.onSave?.({description:v.value,folder:p.value,tags:c.value})).catch(()=>{})}),{host:r,open(){const g=t.activeElement;f=g instanceof HTMLElement?g:null,r.hidden=!1,d.focus()},close:h,setValues(g){g.tags!==void 0&&(c.value=g.tags),g.folder!==void 0&&(p.value=g.folder),g.description!==void 0&&(v.value=g.description)},setState(g,k){u.dataset.state=g,u.textContent=k,u.hidden=k.length===0,w.hidden=g!=="ready"},destroy(){r.remove()}}}const Te=2e4,Ce=50,J=50,Ie=100,ee=32;function U(e){return e.trim().normalize("NFKC")}function L(e){return U(e).toLocaleLowerCase("en-US")}function Me(e){return Array.from(e).some(t=>{const r=t.codePointAt(0)??0;return r<=31||r===127})}function te(e,t){const r=U(e),n=t==="tag"?Ce:Ie;if(!r||r.length>n||Me(r))throw new Error(`Invalid ${t} name.`);return r}function _e(e){if(e.description.length>Te)throw new Error("The note must contain at most 20,000 characters.");const t=[...new Map(e.tags.split(",").filter(a=>U(a).length>0).map(a=>{const o=te(a,"tag");return[L(o),o]})).values()];if(t.length>J)throw new Error(`A bookmark can have at most ${J} tags.`);const r=e.folder.split("/").filter(a=>U(a).length>0);if(r.length>ee)throw new Error(`A folder path can have at most ${ee} levels.`);const n=r.map(a=>te(a,"folder"));return{note:e.description,tags:t,folderPath:n}}function q(e){if(e?.aborted)throw new DOMException("The operation was aborted.","AbortError")}async function C(e,t,r){q(r);const n=await e(t);if(q(r),!n.ok)throw new Error(n.error.message||n.error.code);return n.data}function re(e){return typeof e=="object"&&e!==null&&Array.isArray(e.tags)}function Le(e,t){if(typeof e!="object"||e===null)return!1;const r=e.bookmark;return typeof r=="object"&&r!==null&&r.id===t&&Array.isArray(r.tagIds)&&r.tagIds.every(n=>typeof n=="string")}function ae(e){return typeof e=="object"&&e!==null&&Array.isArray(e.folders)}function Oe(e,t){if(!e)return"";const r=new Map(t.map(i=>[i.id,i])),n=[],a=new Set;let o=r.get(e);for(;o&&!a.has(o.id);)a.add(o.id),n.unshift(o.name),o=o.parentId?r.get(o.parentId):void 0;return n.join(" / ")}async function Re(e){const[t,r]=await Promise.all([C(e.send,{type:"LIST_TAGS"},e.signal),C(e.send,{type:"LIST_FOLDERS"},e.signal)]);if(!re(t)||!ae(r))throw new Error("Invalid metadata response.");const n=new Map(t.tags.map(a=>[a.id,a]));return{description:e.bookmark.note,folder:Oe(e.bookmark.folderId,r.folders),tags:e.bookmark.tagIds.map(a=>n.get(a)?.name).filter(a=>typeof a=="string").join(", ")}}async function Be(e,t){const[r,n]=await Promise.all([C(e.send,{type:"LIST_TAGS"},e.signal),C(e.send,{type:"GET_BOOKMARK",payload:{id:e.bookmark.id}},e.signal)]);if(!re(r))throw new Error("Invalid tag response.");if(!Le(n,e.bookmark.id))throw new Error("Invalid bookmark response.");const a=new Map(r.tags.map(l=>[l.id,l])),o=n.bookmark.tagIds.map(l=>a.get(l)).filter(l=>l!==void 0),i=new Map(t.map(l=>[L(l),l]));for(const l of o)i.has(L(l.normalizedName||l.name))||await C(e.send,{type:"REMOVE_BOOKMARK_TAG",payload:{id:e.bookmark.id,tagId:l.id}},e.signal);const s=new Set(o.map(l=>L(l.normalizedName||l.name)));for(const[l,d]of i)s.has(l)||await C(e.send,{type:"ADD_BOOKMARK_TAG",payload:{id:e.bookmark.id,name:d}},e.signal)}async function Ne(e,t){if(t.length===0)return null;const r=await C(e.send,{type:"LIST_FOLDERS"},e.signal);if(!ae(r))throw new Error("Invalid folder response.");const n=[...r.folders];let a=null;for(const o of t){let i=n.find(s=>s.parentId===a&&L(s.name)===L(o));if(!i){const s=await C(e.send,{type:"CREATE_FOLDER",payload:{name:o,parentId:a}},e.signal);if(!s?.folder)throw new Error("Invalid folder response.");const l=s.folder;i=l,n.push(l)}a=i.id}return a}async function Fe(e){const t=_e(e.values);q(e.signal),await C(e.send,{type:"SAVE_BOOKMARK_NOTE",payload:{id:e.bookmark.id,note:t.note}},e.signal),await Be(e,t.tags);const r=await Ne(e,t.folderPath);await C(e.send,{type:"ASSIGN_BOOKMARK_FOLDER",payload:{bookmarkId:e.bookmark.id,folderId:r}},e.signal)}const De=900,Pe=6e3;function Ke(e){if(typeof e!="object"||e===null)return!1;const t=e;return typeof t.id=="string"&&typeof t.text=="string"&&typeof t.url=="string"&&typeof t.author=="object"&&t.author!==null&&typeof t.author.id=="string"&&typeof t.author.username=="string"&&typeof t.author.name=="string"&&typeof t.postCreatedAt=="string"&&me(t.media,t.url)&&typeof t.note=="string"&&(t.folderId===null||typeof t.folderId=="string")&&Array.isArray(t.tagIds)&&t.tagIds.every(r=>typeof r=="string")&&typeof t.firstSavedAt=="string"&&typeof t.lastSeenAt=="string"&&(t.archivedAt===null||typeof t.archivedAt=="string")&&typeof t.metadataUpdatedAt=="string"&&(t.status==="current"||t.status==="archived")}function Ue(e){return e.dataset.testid==="bookmark"?"save":e.dataset.testid==="removeBookmark"?"remove":null}function ze(e,t){const r=e.querySelector('button[data-testid="bookmark"], button[data-testid="removeBookmark"]');return r?t==="save"?r.dataset.testid==="removeBookmark"||r.getAttribute("aria-pressed")==="true":r.dataset.testid==="bookmark"||r.getAttribute("aria-pressed")==="false":!1}function qe(e){return new Promise(t=>{let r=!1,n=null;const a=d=>{r||(r=!0,i.disconnect(),n!==null&&clearTimeout(n),clearTimeout(s),e.signal.removeEventListener("abort",l),t(d))},o=()=>{ze(e.article,e.action)?n??=setTimeout(()=>a(!0),e.stableForMs):n!==null&&(clearTimeout(n),n=null)},i=new MutationObserver(o),s=setTimeout(()=>a(!1),e.timeoutMs),l=()=>a(!1);e.signal.addEventListener("abort",l,{once:!0}),i.observe(e.document.documentElement,{attributes:!0,attributeFilter:["aria-pressed","data-testid"],childList:!0,subtree:!0}),o()})}function He(){return crypto.randomUUID()}function Ve(e){return{close:e("bookmarkPromptClose"),description:e("bookmarkPromptNote"),folder:e("bookmarkPromptFolder"),save:e("bookmarkPromptSave"),tags:e("bookmarkPromptTags"),pending:e("liveBookmarkPending")}}function Ge(e){const t=new Map,r=new Map;let n=!1;const a=async(i,s,l)=>{const d=t.get(s.id);d?.controller.abort(),d?.metadataController?.abort();const b=r.get(s.id);b?.controller.abort(),b?.metadataController?.abort(),b?.modal?.destroy(),r.delete(s.id);const u={controller:new AbortController,intentId:He(),metadataController:null,modal:null};t.set(s.id,u);const w={type:"LIVE_BOOKMARK_PENDING",intentId:u.intentId,action:i,bookmark:s};e.onPending?.(l,s.id);const x=e.send(w),v=qe({document:e.document,article:l,action:i,signal:u.controller.signal,stableForMs:e.stableForMs??De,timeoutMs:e.timeoutMs??Pe}),y=await x.catch(()=>null),c=y?.ok?y.data:null;if(!n&&!u.controller.signal.aborted&&c?.prompt&&c.surface==="modal"){let f=null;const h=new AbortController;u.metadataController=h;let g=null,k=null,T=null;const A=S=>(k=S,T??=Promise.resolve().then(async()=>{for(;k;){const E=k;if(k=null,!g)throw new Error("Bookmark metadata is not ready.");await Fe({bookmark:g,values:E,send:e.send,signal:h.signal})}}).finally(()=>{T=null}),T);f=Se({document:e.document,title:e.translate("bookmarkPromptTitle"),bookmarkTitle:s.text||s.url,labels:Ve(e.translate),onSave:async S=>{u.modal?.setState("pending",e.translate("liveBookmarkPending"));try{await A(S),e.onChanged?.(s.id),u.modal?.setState("ready",e.translate("liveBookmarkSaved"))}catch{h.signal.aborted||u.modal?.setState("ready",e.translate("liveBookmarkFailed"))}},onClose:()=>{f&&r.get(s.id)===u&&(r.delete(s.id),u.metadataController?.abort(),u.metadataController=null,u.modal=null,delete u.prepareMetadata,f.destroy(),f=null)}}),u.modal=f,r.set(s.id,u),f.open(),u.prepareMetadata=async S=>{g=S;const E=await Re({bookmark:S,send:e.send,signal:h.signal});h.signal.aborted||f?.setValues(E)}}const p=await v;if(n||t.get(s.id)!==u)return;if(!p){await e.send({type:"LIVE_BOOKMARK_CANCELLED",intentId:u.intentId}).catch(()=>{}),u.modal?.setState("error",e.translate("liveBookmarkFailed")),e.onChanged?.(s.id),t.delete(s.id);return}const m=await e.send({type:"LIVE_BOOKMARK_CONFIRMED",intentId:u.intentId,action:i,bookmark:s}).catch(()=>null);if(m?.ok)if(i==="save"){const f=m.data?.bookmark;try{if(u.modal){if(!Ke(f))throw new Error("Invalid bookmark response.");await u.prepareMetadata?.(f)}u.controller.signal.aborted||u.modal?.setState("ready",e.translate("liveBookmarkSaved"))}catch{u.controller.signal.aborted||u.modal?.setState("ready",e.translate("liveBookmarkFailed"))}}else u.modal?.setState("success",e.translate("liveBookmarkArchived"));else u.modal?.setState("error",e.translate("liveBookmarkFailed"));e.onChanged?.(s.id),t.delete(s.id)},o=i=>{if(n||!(i.target instanceof Element))return;const s=i.target.closest("button");if(!s)return;const l=Ue(s);if(!l)return;const d=s.closest('article[data-testid="tweet"]');if(!d)return;const b=$(d)[0];b&&a(l,b,d)};return e.document.addEventListener("click",o,!0),{stop(){if(!n){n=!0,e.document.removeEventListener("click",o,!0);for(const i of t.values())i.controller.abort(),i.metadataController?.abort();for(const i of new Set(r.values()))i.controller.abort(),i.metadataController?.abort(),i.modal?.destroy();t.clear(),r.clear()}}}}function ne(e,t){return(!t.note||e.note.trim().length>0)&&(!t.tags||e.tagIds.length>0)&&(!t.breadcrumb||e.folderId!==null)}const N='article[data-testid="tweet"]',oe="bookmark-x-metadata",je=/^\/[A-Za-z0-9_]+\/status\/(\d+)$/,$e={appearance:{largeText:!0,highContrast:!0,reduceMotion:!1},behavior:{surface:"modal",promptAfterBookmark:!0,metadata:{summary:!0,breadcrumb:!0,tags:!0,note:!0,categoryIndicator:!0}},export:{includeLink:!0,includeText:!0,includeAuthor:!0,includeDate:!0,includeImages:!0,includeVideos:!0,includeNote:!0,includeTags:!0,includeFolder:!0,includeFirstSavedAt:!0,includeLastSeenAt:!0},search:{filterAsYouType:!0},data:{keepArchived:!0}},Xe=String.raw`
  :host {
    --bx-border: #cfd9de;
    --bx-ink: #0f1419;
    --bx-muted: #536471;
    --bx-surface: #ffffff;
    --bx-soft: #eff3f4;
    color: var(--bx-ink);
    display: block;
    font-family: ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
    font-size: 14px;
    line-height: 1.4;
    min-width: 0;
  }

  :host([data-large-text="true"]) { font-size: 15px; }

  .card {
    background: var(--bx-surface);
    border: 1px solid var(--bx-border);
    border-radius: 12px;
    box-sizing: border-box;
    display: grid;
    gap: 6px;
    margin: 6px 12px 4px;
    max-width: calc(100% - 24px);
    padding: 8px 10px;
  }

  .status-row, .tags, .breadcrumb {
    align-items: center;
    display: flex;
    flex-wrap: wrap;
    gap: 5px;
    min-width: 0;
  }

  .status, .category, .tag {
    border-radius: 999px;
    font-size: 0.8125em;
    font-weight: 650;
    padding: 2px 7px;
    max-width: 100%;
    overflow-wrap: anywhere;
    white-space: normal;
  }

  .status::before { content: "✓ "; }
  .status[data-state="pending"]::before { content: "… "; }
  .status[data-state="archived"]::before { content: "↺ "; }
  .category::before { content: "! "; }
  .status { background: var(--bx-soft); color: var(--bx-muted); }
  .category { background: #fff3c4; color: #6b4e00; }
  .tag { background: var(--bx-soft); color: var(--bx-ink); }

  .breadcrumb { color: var(--bx-muted); font-size: 0.875em; font-weight: 600; }
  .crumb + .crumb::before { content: "›"; margin-inline-end: 6px; }

  .note {
    color: var(--bx-muted);
    display: -webkit-box;
    margin: 0;
    overflow: hidden;
    overflow-wrap: anywhere;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 1;
  }

  .visually-hidden {
    border: 0;
    clip: rect(0 0 0 0);
    height: 1px;
    margin: -1px;
    overflow: hidden;
    padding: 0;
    position: absolute;
    white-space: nowrap;
    width: 1px;
  }

  :host([data-high-contrast="true"]) {
    --bx-border: #111;
    --bx-ink: #000;
    --bx-muted: #242424;
    --bx-surface: #fff;
    --bx-soft: #f1f1f1;
  }

  @media (prefers-color-scheme: dark) {
    :host {
      --bx-border: #536471;
      --bx-ink: #e7e9ea;
      --bx-muted: #8b98a5;
      --bx-surface: #000;
      --bx-soft: #16181c;
    }
    .category { background: #3a2b00; color: #ffe28a; }
    .tag { background: #16181c; color: #e7e9ea; }
  }

  @media (forced-colors: active) {
    .card, .status, .category, .tag { border-color: CanvasText; }
    .card { background: Canvas; color: CanvasText; }
  }

  @media (prefers-reduced-motion: reduce) {
    *, *::before, *::after {
      animation-duration: 0.01ms !important;
      animation-iteration-count: 1 !important;
      transition-duration: 0.01ms !important;
    }
  }

  :host([data-reduce-motion="true"]) *,
  :host([data-reduce-motion="true"]) *::before,
  :host([data-reduce-motion="true"]) *::after {
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.01ms !important;
  }
`;function F(e,t,r,n,a){const o=e.createElement(r);return o.className=n,o.textContent=a,t.append(o),o}function We(e){return Object.values(e.behavior.metadata).some(Boolean)}function ie(e){const{document:t,host:r,item:n,settings:a,translate:o}=e,i=r.shadowRoot??r.attachShadow({mode:"open"}),s=t.createElement("style");s.textContent=Xe;const l=t.createElement("section");if(l.className="card",r.dataset.bookmarkId=n.bookmark.id,r.dataset.largeText=String(a.appearance.largeText),r.dataset.highContrast=String(a.appearance.highContrast),r.dataset.reduceMotion=String(a.appearance.reduceMotion),r.dataset.state=e.pending?"pending":n.bookmark.status==="archived"?"archived":ne(n.bookmark,a.behavior.metadata)?"mapped":"uncategorized",r.setAttribute("aria-label",o("bookmarkMetadataLabel")),r.setAttribute("role","group"),a.behavior.metadata.summary||!e.pending&&a.behavior.metadata.categoryIndicator){const d=t.createElement("div");if(d.className="status-row",a.behavior.metadata.summary){const b=F(t,d,"span","status",e.pending?o("liveBookmarkPending"):n.bookmark.status==="archived"?o("bookmarkMetadataArchived"):o("bookmarkMetadataMapped"));b.dataset.state=e.pending?"pending":n.bookmark.status==="archived"?"archived":"mapped"}!e.pending&&a.behavior.metadata.categoryIndicator&&!ne(n.bookmark,a.behavior.metadata)&&F(t,d,"span","category",o("bookmarkNeedsCategory")),l.append(d)}if(!e.pending&&a.behavior.metadata.breadcrumb){const d=t.createElement("div");d.className="breadcrumb",d.setAttribute("aria-label",o("bookmarkPromptFolder"));const b=n.breadcrumb.length?n.breadcrumb:[o("uncategorizedFolder")];for(const u of b)F(t,d,"span","crumb",u);l.append(d)}if(!e.pending&&a.behavior.metadata.tags&&n.tags.length>0){const d=t.createElement("div");d.className="tags",d.setAttribute("aria-label",o("bookmarkPromptTags"));for(const b of n.tags)F(t,d,"span","tag",b.name);l.append(d)}if(!e.pending&&a.behavior.metadata.note&&n.bookmark.note.trim().length>0){const d=t.createElement("p");d.className="note",F(t,d,"span","visually-hidden",`${o("bookmarkPromptNote")}: `),d.append(t.createTextNode(n.bookmark.note)),l.append(d)}i.replaceChildren(s,l)}function se(e){for(const t of Array.from(e.querySelectorAll('a[href*="/status/"]')))try{const r=new URL(t.href,location.href).pathname.match(je);if(r?.[1])return r[1]}catch{}return null}function Ye(e){const t=e.querySelector('button[data-testid="bookmark"], button[data-testid="removeBookmark"]');return t?.closest('[role="group"]')??t}function Qe(e,t){const r=e.defaultView;return typeof r?.requestAnimationFrame=="function"?r.requestAnimationFrame(t):(queueMicrotask(()=>t(performance.now())),0)}function Ze(e){const t=new Map,r=new Map,n=new Set;let a=!1,o=null,i=0,s=null,l=c=>c;const d=c=>{t.get(c)?.host.remove(),t.delete(c),r.delete(c)},b=(c,p)=>{const m=Ye(c);if(!m)return null;const f=t.get(c);if(f?.bookmarkId===p&&f.host.isConnected)return f.host;d(c);const h=e.document.createElement(oe);return m.insertAdjacentElement("afterend",h),t.set(c,{bookmarkId:p,host:h}),h},u=async()=>{if(o=null,a)return;const c=++i;for(const f of[...t.keys()])f.isConnected||d(f);const p=[...n].filter(f=>f.isConnected);n.clear();const m=new Map;for(const f of p){const h=se(f);if(!h){d(f);continue}const g=m.get(h)??[];g.push(f),m.set(h,g)}if(m.size!==0)try{const f=[...m.keys()];let h=null;const g=[];for(let A=0;A<f.length;A+=100){const S=await e.lookup(f.slice(A,A+100));if(a||c!==i)return;h=S,g.push(...S.items)}if(!h)return;h={...h,items:g};const k=A=>h.messages[A]??A;if(a||c!==i)return;s=h,l=k;const T=new Map(h.items.map(A=>[A.bookmark.id,A]));for(const[A,S]of m){const E=T.get(A);for(const I of S){if(!E){if(r.get(I)===A)continue;d(I);continue}if(!We(h.settings)){d(I);continue}const K=b(I,A);K&&ie({document:e.document,host:K,item:E,settings:h.settings,translate:k,pending:r.get(I)===A})}}}catch{}},w=()=>{a||o!==null||(o=(e.scheduleFrame??(c=>Qe(e.document,c)))(()=>{u()}))},x=c=>{n.add(c),w()},v=c=>{if(!(c instanceof Element))return;c.matches(N)&&x(c);for(const m of Array.from(c.querySelectorAll(N)))x(m);const p=c.closest(N);p&&x(p)},y=new MutationObserver(c=>{for(const p of c)if(!(p.type==="childList"&&[...Array.from(p.addedNodes),...Array.from(p.removedNodes)].length>0&&[...Array.from(p.addedNodes),...Array.from(p.removedNodes)].every(m=>m instanceof Element&&m.localName===oe))){v(p.target);for(const m of Array.from(p.addedNodes))v(m);for(const m of Array.from(p.removedNodes))v(m)}});y.observe(e.document.documentElement,{attributes:!0,attributeFilter:["href","data-testid"],childList:!0,subtree:!0});for(const c of Array.from(e.document.querySelectorAll(N)))x(c);return{refresh(c){for(const[p,m]of r)(!c||m===c)&&r.delete(p);for(const p of Array.from(e.document.querySelectorAll(N)))(!c||se(p)===c)&&x(p)},setPending(c,p){const m=b(c,p);if(!m)return;const f=s?.settings??$e;if(!f.behavior.metadata.summary){d(c);return}r.set(c,p);const g=s?.items.find(k=>k.bookmark.id===p)??{bookmark:{id:p,text:"",url:"",author:{id:"",username:"",name:""},postCreatedAt:"",media:{images:[],videos:[]},note:"",folderId:null,tagIds:[],firstSavedAt:"",lastSeenAt:"",archivedAt:null,metadataUpdatedAt:"",status:"current"},breadcrumb:[],tags:[]};ie({document:e.document,host:m,item:g,settings:f,translate:l,pending:!0})},stop(){if(!a){a=!0,i+=1,y.disconnect(),o!==null&&o!==0&&(e.cancelFrame?e.cancelFrame(o):e.document.defaultView?.cancelAnimationFrame(o));for(const c of[...t.keys()])d(c);n.clear(),r.clear()}}}}let M;function de(e){return chrome.runtime.sendMessage(e)}class H extends Error{constructor(t){super(`Capture event was rejected: ${t}`),this.code=t}code}async function D(e){const t=await de(e);if(typeof t!="object"||t===null)throw new H("invalid_response");const r=t;if(r.ok===!0)return;const n=r.error,a=typeof n=="object"&&n!==null&&typeof n.code=="string"?String(n.code):"rejected";throw new H(a)}async function Je(e,t,r){try{const n=await ke({scan:()=>$(document),checkpointIds:r,isLoading:()=>B(document),isPageValid:()=>{const a=new URL(window.location.href);return(a.hostname==="x.com"||a.hostname==="www.x.com")&&(a.pathname==="/i/bookmarks"||a.pathname.startsWith("/i/bookmarks/"))},isAtEnd:()=>{const a=document.scrollingElement??document.documentElement;return ye({scrollTop:Math.max(window.scrollY,a.scrollTop),viewportHeight:window.innerHeight,documentHeight:a.scrollHeight})},scroll:()=>{ve(document,{viewportHeight:window.innerHeight,scrollBy:()=>{window.scrollBy({top:Math.max(Math.round(window.innerHeight*.9),640),behavior:"auto"})}})},waitForContent:a=>xe({root:document.querySelector("main")??document.body,view:window,signal:a}),signal:t.signal,onBatch:async a=>{await D({type:"SCRAPE_BATCH",runId:e,bookmarks:a})},onProgress:async({fetched:a})=>{await D({type:"SCRAPE_PROGRESS",runId:e,fetched:a})}});if(n.status==="incomplete"){await D({type:"SCRAPE_FAILED",runId:e,errorCode:n.errorCode??"scrape_incomplete"});return}if(n.status==="completed"){await D({type:"SCRAPE_COMPLETE",runId:e,status:"completed",fetched:n.fetched,completionReason:n.completionReason??"stable_end"});return}await D({type:"SCRAPE_COMPLETE",runId:e,status:"cancelled",fetched:n.fetched})}catch(n){if(n instanceof H&&n.code==="stale_capture")return;try{await de({type:"SCRAPE_FAILED",runId:e,errorCode:t.signal.aborted?"capture_cancelled":"scrape_failed"})}catch{}}finally{M?.runId===e&&(M=void 0)}}function et(e){if(typeof e!="object"||e===null)return!1;const t=e;return t.type==="REFRESH_BOOKMARK_METADATA"?t.bookmarkIds===void 0||Array.isArray(t.bookmarkIds)&&t.bookmarkIds.length<=100&&t.bookmarkIds.every(r=>typeof r=="string"&&/^\d+$/.test(r)):typeof t.runId!="string"?!1:t.type==="CANCEL_SCRAPE"?!0:t.type!=="START_SCRAPE"||t.mode!=="quick"&&t.mode!=="full"||!Array.isArray(t.checkpointIds)||t.checkpointIds.length>10?!1:t.checkpointIds.every(r=>typeof r=="string"&&/^\d+$/.test(r))&&new Set(t.checkpointIds).size===t.checkpointIds.length}const P=Ze({document,async lookup(e){const t=await chrome.runtime.sendMessage({type:"GET_BOOKMARK_DECORATIONS",payload:{ids:e}});if(!t.ok)throw new Error(t.error.message);return t.data}});chrome.runtime.onMessage.addListener((e,t,r)=>{if(t.id!==chrome.runtime.id||!et(e))return r({accepted:!1}),!1;if(e.type==="REFRESH_BOOKMARK_METADATA"){if(e.bookmarkIds)for(const a of e.bookmarkIds)P.refresh(a);else P.refresh();return r({accepted:!0}),!1}if(e.type==="CANCEL_SCRAPE")return M?.runId===e.runId&&M.controller.abort(),r({accepted:!0}),!1;if(M)return r({accepted:!1,reason:"capture_in_progress"}),!1;const n=new AbortController;return M={runId:e.runId,controller:n},r({accepted:!0}),Je(e.runId,n,e.checkpointIds),!1});const tt=Ge({document,send:e=>chrome.runtime.sendMessage(e),translate:e=>chrome.i18n.getMessage(e)||e,onPending:(e,t)=>P.setPending(e,t),onChanged:e=>P.refresh(e)});window.addEventListener("pagehide",()=>{M?.controller.abort(),tt.stop(),P.stop()},{once:!0})})();
