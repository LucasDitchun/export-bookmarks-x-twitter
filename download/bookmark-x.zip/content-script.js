(function(){"use strict";function oe(e){return typeof e=="object"&&e!==null&&!Array.isArray(e)}function j(e){if(typeof e!="string"||e.length===0||e.length>2048)return null;try{const t=new URL(e);return t.protocol!=="https:"||t.hostname!=="pbs.twimg.com"||t.username!==""||t.password!==""||t.port!==""?null:(t.hash="",t.toString())}catch{return null}}function ie(e){const t=new URL(e);return`${t.origin}${t.pathname}`}function se(e){return j(e.currentSrc)??j(e.getAttribute("src")||e.src)}function Ie(e){const t=new Set(e.filter(({thumbnailUrl:n})=>n!==null).map(({postUrl:n})=>n)),a=[],r=new Set;for(const n of e){if(n.thumbnailUrl===null&&t.has(n.postUrl))continue;const o=`${n.postUrl}\0${n.thumbnailUrl===null?"":ie(n.thumbnailUrl)}`;if(!r.has(o)&&(r.add(o),a.push(n),a.length===4))break}return a}function Oe(e,t){const a=[],r=new Set;for(const s of Array.from(e.querySelectorAll('[data-testid="tweetPhoto"] img'))){const d=se(s);if(d===null)continue;const k=ie(d);if(!r.has(k)&&(r.add(k),a.push(d),a.length===16))break}const o=Array.from(e.querySelectorAll("video")).map(s=>({thumbnailUrl:j(s.poster||s.getAttribute("poster")),postUrl:t}));for(const s of Array.from(e.querySelectorAll('[data-testid="videoPlayer"], [data-testid="videoComponent"]'))){if(s.querySelector("video"))continue;const d=s.querySelector("img");o.push({thumbnailUrl:d?se(d):null,postUrl:t})}return{images:a,videos:Ie(o)}}function Ne(e,t){return!oe(e)||!Array.isArray(e.images)||!Array.isArray(e.videos)||e.images.length>16||e.videos.length>4||e.images.some(a=>typeof a!="string"||j(a)!==a)?!1:e.videos.every(a=>oe(a)&&a.postUrl===t&&(a.thumbnailUrl===null||typeof a.thumbnailUrl=="string"&&j(a.thumbnailUrl)===a.thumbnailUrl))}const Pe=/^\/([A-Za-z0-9_]+)\/status\/(\d+)(?:\/|$)/;function Z(e){return(e?.textContent??"").replace(/\s+/g," ").trim()}function Re(e){const t=e.querySelector("time[datetime]")?.closest("a[href]"),a=Array.from(e.querySelectorAll("a[href]"));if(t){const r=a.indexOf(t);r>=0&&a.splice(r,1),a.unshift(t)}for(const r of a){let n;try{n=new URL(r.getAttribute("href")??"","https://x.com")}catch{continue}if(n.hostname!=="x.com"&&n.hostname!=="www.x.com")continue;const o=Pe.exec(n.pathname);if(!o)continue;const s=o[1],d=o[2];if(!(!s||!d))return{id:d,username:s,url:`https://x.com/${s}/status/${d}`}}return null}function ze(e,t){const a=e.querySelector('[data-testid="User-Name"]'),r=Array.from(a?.querySelectorAll("a[href]")??[]).find(s=>s.getAttribute("href")?.toLocaleLowerCase()===`/${t.toLocaleLowerCase()}`),n=Z(r);return n&&!n.startsWith("@")?n:Array.from(a?.querySelectorAll("span")??[]).map(Z).filter(s=>s.length>0&&!s.startsWith("@")&&s!=="·"&&s.toLocaleLowerCase()!==t.toLocaleLowerCase())[0]??t}function le(e=document){const t=new Map,a=Array.from(e.querySelectorAll('article[data-testid="tweet"]')),r=e instanceof Element&&e.matches('article[data-testid="tweet"]')?[e,...a]:a;for(const n of r){const o=Re(n);if(!o||t.has(o.id))continue;const s=n.querySelector("time[datetime]");t.set(o.id,{id:o.id,text:Z(n.querySelector('[data-testid="tweetText"]')),url:o.url,author:{id:o.username.toLocaleLowerCase(),username:o.username,name:ze(n,o.username)},postCreatedAt:s?.dateTime??"",media:Oe(n,o.url)})}return[...t.values()]}const Be=['main [role="progressbar"]','main [data-testid="progressBar"]','main [aria-busy="true"]','main[aria-busy="true"]'].join(",");function Fe(e){if(e.closest('[hidden], [aria-hidden="true"]'))return!0;const t=e.ownerDocument.defaultView;if(!t)return!1;const a=t.getComputedStyle(e);return a.display==="none"||a.visibility==="hidden"}function V(e){return Array.from(e.querySelectorAll(Be)).some(t=>!Fe(t))}function De({scrollTop:e,viewportHeight:t,documentHeight:a},r=8){return e+t>=a-r}const He=15,Ke=3,de=50,Ue=de;function ce(e){return Number.isSafeInteger(e)&&typeof e=="number"&&e>=Ke&&e<=de}async function $e({scan:e,checkpointIds:t=[],quickStopThreshold:a=He,isLoading:r=()=>!1,isAtEnd:n=()=>!0,isPageValid:o=()=>!0,scroll:s,waitForContent:d,onBatch:k,onProgress:b,signal:w,idlePassLimit:m=4,maximumLoadingPasses:E=180,batchSize:f=100}){if(!Number.isSafeInteger(f)||f<1||f>100)throw new RangeError("Scrape batch size must be between 1 and 100.");if(!ce(a))throw new RangeError("Quick stop threshold is outside the supported range.");if(!Number.isSafeInteger(m)||m<1)throw new RangeError("Idle pass limit must be a positive integer.");if(!Number.isSafeInteger(E)||E<1)throw new RangeError("Loading pass limit must be a positive integer.");const y=new Set,O=new Set(t);let h=0,M=0,_=0,I=0,A=-1;for(;!w?.aborted;){if(!o())return{status:"incomplete",fetched:h,errorCode:"capture_navigation_changed"};const N=[];let R=!1;for(const S of e()){if(y.has(S.id))continue;const{id:z}=S;if(y.add(z),N.push(S),M=O.has(z)?M+1:0,O.size>0&&M>=a){R=!0;break}}const i=r(),c=n(),u=N.length===0&&!i&&c;if(N.length>0){_=0;const S=h;for(let z=0;z<N.length&&!w?.aborted;z+=f){const C=N.slice(z,z+f);await k(C),h+=C.length}h>S&&(I=0)}else(i||!c)&&(_=0);A!==h&&(await b({fetched:h}),A=h);const x=R?new Set(e().map(({id:S})=>S)):null,p=d(w);!i&&!u&&!R&&s();const v=await p;if(!o())return{status:"incomplete",fetched:h,errorCode:"capture_navigation_changed"};const g=r(),T=n();if((i||v?.loadingObserved||g)&&(I+=1,I>=E))return{status:"incomplete",fetched:h,errorCode:"capture_loading_timeout"};if(R&&!w?.aborted){const S=e().some(({id:C})=>!x?.has(C));if(!i&&!v?.loadingObserved&&!g&&!S)return{status:"completed",fetched:h,completionReason:"checkpoint_stop"};M=0}if(u&&!w?.aborted&&v?.reason!=="activity"&&!v?.loadingObserved&&!g&&T){if(_+=1,_>=m)return{status:"completed",fetched:h,...O.size>0?{completionReason:"stable_end"}:{}}}else(v?.loadingObserved||v?.reason==="activity"||g||!T)&&(_=0)}return{status:"cancelled",fetched:h}}const ue='article[data-testid="tweet"]';function qe(e){return Array.from(e.querySelectorAll(ue)).filter(t=>!t.parentElement?.closest(ue))}function je(e,{viewportHeight:t,scrollBy:a}){const r=qe(e).at(-1),n=r&&r.getBoundingClientRect().top>t*.25;return!r||!n?(a(),"fallback"):(r.scrollIntoView({behavior:"auto",block:"start"}),"anchor")}const Ve='article[data-testid="tweet"] a[href*="/status/"]',me='[role="progressbar"], [data-testid="progressBar"], [aria-busy="true"]';function fe(e){return e.some(t=>Array.from(t.addedNodes).some(a=>{if(a.nodeType!==1)return!1;const r=a;return r.matches(me)||r.querySelector(me)!==null}))}function pe(e){const t=Array.from(e.querySelectorAll(Ve),a=>a.getAttribute("href")??"");return`${V(e.ownerDocument)?"loading":"idle"}|${t.join("|")}`}function Ge({root:e,view:t,signal:a,settleMs:r=75,scrollSettleMs:n=180,maximumWaitMs:o=1100}){return a?.aborted?Promise.resolve({reason:"aborted",loadingObserved:!1}):new Promise(s=>{const d=pe(e);let k=V(e.ownerDocument),b=!1,w;const m=_=>{if(b)return;b=!0;const I=h.takeRecords(),A=fe(I);k||=A||V(e.ownerDocument),h.disconnect(),w!==void 0&&t.clearTimeout(w),t.clearTimeout(M),t.removeEventListener("scroll",y),a?.removeEventListener("abort",O),s({reason:_==="timeout"&&A?"activity":_,loadingObserved:k})},E=(_,I)=>{w!==void 0&&t.clearTimeout(w),w=t.setTimeout(()=>m(_),I)},f=_=>{const I=fe(_);if(k||=I||V(e.ownerDocument),I){E("activity",r);return}pe(e)!==d&&E("activity",r)},y=()=>E("activity",n),O=()=>m("aborted"),h=new t.MutationObserver(f);h.observe(e,{attributes:!0,attributeFilter:["aria-busy","aria-hidden","data-testid","hidden","href","style"],childList:!0,subtree:!0}),t.addEventListener("scroll",y,{passive:!0});const M=t.setTimeout(()=>m("timeout"),o);a?.addEventListener("abort",O,{once:!0})})}const Xe=`
  :host {
    all: initial;
    --modal-bg: #fff;
    --modal-subtle: #f7f9f9;
    --modal-text: #0f1419;
    --modal-muted: #536471;
    --modal-line: #cfd9de;
    --modal-action: #0f1419;
    --modal-action-text: #fff;
    color-scheme: light dark;
    font-family: "Segoe UI Variable Text", "Helvetica Neue", Helvetica, sans-serif;
    font-size: 15px;
    line-height: 1.4;
    position: fixed;
    inset: 0;
    z-index: 2147483647;
  }
  :host([data-theme="dark"]) {
    --modal-bg: #000;
    --modal-subtle: #16181c;
    --modal-text: #e7e9ea;
    --modal-muted: #8b98a5;
    --modal-line: #2f3336;
    --modal-action: #eff3f4;
    --modal-action-text: #0f1419;
  }
  :host([hidden]) { display: none; }
  *, *::before, *::after { box-sizing: border-box; }
  .backdrop {
    align-items: center;
    background: rgb(15 20 25 / 48%);
    display: flex;
    inset: 0;
    justify-content: center;
    padding: 16px;
    position: absolute;
  }
  .dialog {
    background: var(--modal-bg);
    border: 1px solid var(--modal-line);
    border-radius: 20px;
    box-shadow: 0 20px 64px rgb(15 20 25 / 24%);
    color: var(--modal-text);
    max-height: min(680px, calc(100vh - 32px));
    max-width: 480px;
    overflow: auto;
    padding: 20px;
    width: 100%;
  }
  .heading { align-items: start; display: flex; gap: 12px; justify-content: space-between; }
  h2 { font-size: 1.25rem; letter-spacing: -0.02em; line-height: 1.2; margin: 0; }
  .bookmark {
    background: var(--modal-subtle);
    border-radius: 12px;
    color: var(--modal-muted);
    font-size: 0.875rem;
    margin: 14px 0;
    max-height: 84px;
    overscroll-behavior: contain;
    overflow-y: auto;
    overflow-wrap: anywhere;
    padding: 10px 12px;
    scrollbar-gutter: stable;
    white-space: pre-wrap;
  }
  .status { border: 1px solid var(--modal-line); border-radius: 12px; margin: 0 0 14px; padding: 10px 12px; }
  .status[data-state="success"] { border-color: #16733d; }
  .status[data-state="error"] { border-color: #a52222; }
  form { display: grid; gap: 12px; }
  form[hidden] { display: none; }
  label { color: var(--modal-muted); display: block; font-size: 0.8125rem; font-weight: 700; }
  .field-help {
    color: var(--modal-muted);
    font-size: 0.75rem;
    line-height: 1.35;
    margin: 6px 2px 0;
  }
  .metadata-grid { display: grid; gap: 12px; grid-template-columns: repeat(2, minmax(0, 1fr)); }
  .field { min-width: 0; }
  .tokens { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 7px; }
  .token {
    align-items: center;
    background: var(--modal-subtle);
    border: 1px solid var(--modal-line);
    color: var(--modal-text);
    display: inline-flex;
    font-size: 0.75rem;
    min-height: 30px;
    padding: 5px 9px;
  }
  input, select, textarea {
    background: var(--modal-bg);
    border: 1px solid var(--modal-line);
    border-radius: 12px;
    color: var(--modal-text);
    display: block;
    font: inherit;
    margin-top: 5px;
    min-height: 44px;
    padding: 10px 12px;
    width: 100%;
  }
  textarea {
    height: 120px;
    max-height: 120px;
    min-height: 120px;
    overflow-y: auto;
    resize: none;
  }
  button {
    background: var(--modal-action);
    border: 1px solid var(--modal-action);
    border-radius: 999px;
    color: var(--modal-action-text);
    cursor: pointer;
    font: 700 0.875rem/1 "Segoe UI Variable Text", "Helvetica Neue", Helvetica, sans-serif;
    min-height: 44px;
    padding: 10px 18px;
  }
  .close { background: transparent; color: var(--modal-text); flex: 0 0 auto; }
  .save { margin-top: 2px; width: 100%; }
  :focus-visible { outline: 3px solid #1d9bf0; outline-offset: 2px; }
  @media (max-width: 520px) {
    .backdrop { align-items: end; padding: 8px; }
    .dialog { border-radius: 20px 20px 12px 12px; max-height: calc(100vh - 16px); padding: 18px; }
    .metadata-grid { grid-template-columns: 1fr; }
  }
  @media (prefers-reduced-motion: reduce) {
    *, *::before, *::after { scroll-behavior: auto !important; }
  }
`;function Qe(e){const t=e.defaultView;for(const a of[e.body,e.documentElement]){if(!a||!t)continue;const r=t.getComputedStyle(a).backgroundColor.match(/[\d.]+/g)?.map(Number);if(!r||r.length<3||(r[3]??1)===0)continue;const n=r[0]??255,o=r[1]??255,s=r[2]??255;return n*.2126+o*.7152+s*.0722<128}return t?.matchMedia?.("(prefers-color-scheme: dark)").matches??!1}function ge(e,t,a,r,n){const o=e.createElement("label");o.htmlFor=a,o.textContent=r;const s=e.createElement("input");s.id=a,s.value=n,s.autocomplete="off";const d=e.createElement("div");return d.className="field",d.append(o,s),t.append(d),s}function he(e){const{document:t}=e,a=t.createElement("bookmark-x-note-modal");a.dataset.theme=Qe(t)?"dark":"light",a.hidden=!0,a.tabIndex=-1;const r=a.attachShadow({mode:"open"}),n=t.createElement("style");n.textContent=Xe;const o=t.createElement("div");o.className="backdrop";const s=t.createElement("section");s.className="dialog",s.setAttribute("role","dialog"),s.setAttribute("aria-modal","true"),s.setAttribute("aria-labelledby","bookmark-x-modal-title");const d=t.createElement("div");d.className="heading";const k=t.createElement("h2");k.id="bookmark-x-modal-title",k.textContent=e.title;const b=t.createElement("button");b.className="close",b.type="button",b.textContent=e.labels.close,d.append(k,b);const w=t.createElement("p");w.className="bookmark",w.textContent=e.bookmarkTitle;const m=t.createElement("p");m.className="status",m.setAttribute("role","status"),m.setAttribute("aria-live","polite"),m.setAttribute("aria-atomic","true"),m.dataset.state=e.labels.pending?"pending":"ready",m.textContent=e.labels.pending??"",m.hidden=m.textContent.length===0;const E=t.createElement("form"),f=t.createElement("label");f.htmlFor="bookmark-x-modal-description",f.textContent=e.labels.description;const y=t.createElement("textarea");y.id="bookmark-x-modal-description",y.maxLength=2e4,y.value=e.values?.description??"",E.append(f,y);const O=t.createElement("div");O.className="metadata-grid";const h=ge(t,O,"bookmark-x-modal-tags",e.labels.tags,""),M=h.parentElement?.querySelector("label"),_=t.createElement("div");_.className="tokens",h.parentElement?.append(_);const I=t.createElement("datalist");I.id="bookmark-x-modal-tag-choices",h.setAttribute("list",I.id);const A=t.createElement("p");A.className="field-help",A.id="bookmark-x-modal-tags-help",A.textContent=e.labels.tagsHelp??"",A.hidden=!e.labels.tagsHelp,h.setAttribute("aria-describedby",A.id),h.parentElement?.append(A);const N=ge(t,O,"bookmark-x-modal-folder",e.labels.folder,""),R=N.parentElement?.querySelector("label"),i=t.createElement("div");i.className="tokens folder-tokens",N.parentElement?.append(i);const c=t.createElement("datalist");c.id="bookmark-x-modal-folder-choices",N.setAttribute("list",c.id);const u=t.createElement("button");u.className="save",u.type="submit",u.textContent=e.labels.save,E.append(O,I,c,u),E.hidden=e.labels.pending!==void 0,s.append(d,w,m,E),o.append(s),r.append(n,o),t.body.append(a);let x=null,p=[...e.values?.tags??[]],v=e.values?.folder??null,g=!1,T=!1,S=[],z=[];const C=l=>l.trim().normalize("NFKC").toLocaleLowerCase("und"),D=l=>l.path.join(" / "),U=()=>{if(i.replaceChildren(),!v)return;const l=t.createElement("button");l.className="token folder-token",l.type="button",l.textContent=`${D(v)} ×`,l.setAttribute("aria-label",`Remove ${D(v)}`),l.addEventListener("click",()=>{v=null,T=!0,U(),N.focus()}),i.append(l)},P=()=>{_.replaceChildren(...p.map(l=>{const L=t.createElement("button");return L.className="token",L.type="button",L.textContent=`${l.name} ×`,L.setAttribute("aria-label",`Remove ${l.name}`),L.addEventListener("click",()=>{p=p.filter(B=>B!==l),g=!0,P(),h.focus()}),L}))},Q=()=>{const l=h.value.trim().normalize("NFKC");if(!l)return;const B=S.find(F=>C(F.name)===C(l))??{id:null,name:l};p.some(F=>C(F.name)===C(l))||(p=[...p,B],g=!0,P()),h.value=""},Me=()=>{const l=N.value.trim();if(!l)return;const L=z.find(F=>D(F)===l),B=v?.id??null;v=L??{id:B,path:[...v?.path??[],l],...B===null?{}:{newSegments:[...v?.newSegments??[],l]}},T=!0,N.value="",U()};P(),U(),h.addEventListener("keydown",l=>{l.key==="Enter"&&(l.preventDefault(),Q())}),N.addEventListener("keydown",l=>{l.key==="Enter"&&(l.preventDefault(),Me())});const W=()=>{a.hidden||(a.hidden=!0,e.onClose?.(),x?.focus())};b.addEventListener("click",W),o.addEventListener("click",l=>{l.target===o&&W()}),a.addEventListener("keydown",l=>{if(l.key==="Escape"){l.preventDefault(),W();return}if(l.key!=="Tab")return;const L=Array.from(r.querySelectorAll("button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled])")).filter(F=>!F.hidden),B=r.activeElement;l.shiftKey&&B===L[0]?(l.preventDefault(),L.at(-1)?.focus()):!l.shiftKey&&B===L.at(-1)&&(l.preventDefault(),L[0]?.focus())});let ne=!1;return E.addEventListener("submit",l=>{l.preventDefault(),!ne&&(ne=!0,u.disabled=!0,Q(),Me(),Promise.resolve(e.onSave?.({description:y.value,folder:v,tags:[...p],organizationChanges:{tags:g,folder:T}})).then(L=>{L!==!1&&W()}).catch(()=>{}).finally(()=>{ne=!1,a.hidden||(u.disabled=!1)}))}),{host:a,open(){const l=t.activeElement;x=l instanceof HTMLElement?l:null,a.hidden=!1,b.focus()},close:W,setValues(l){l.tags!==void 0&&(p=[...l.tags],g=!1,h.value="",P()),l.folder!==void 0&&(v=l.folder,T=!1,N.value="",U()),l.description!==void 0&&(y.value=l.description)},setChoices(l){const L=(B,F,Ct)=>{F&&B.replaceChildren(...[...new Set(F.map(Ct))].map(St=>{const _e=t.createElement("option");return _e.value=St,_e}))};l.tags&&(S=[...l.tags]),l.folders&&(z=[...l.folders]),L(I,l.tags,B=>B.name),L(c,l.folders,D)},setLabels(l){k.textContent=l.title,b.textContent=l.labels.close,f.textContent=l.labels.description,M&&(M.textContent=l.labels.tags),R&&(R.textContent=l.labels.folder),A.textContent=l.labels.tagsHelp??"",A.hidden=!l.labels.tagsHelp,u.textContent=l.labels.save,m.dataset.state==="pending"&&l.labels.pending&&(m.textContent=l.labels.pending)},setState(l,L){m.dataset.state=l,m.textContent=L,m.hidden=L.length===0,E.hidden=l!=="ready"},destroy(){a.remove()}}}const We=2e4,Ze=50,be=50,Ye=100,ke=32;function ye(e){return e.trim().normalize("NFKC")}function Je(e){return ye(e).toLocaleLowerCase("en-US")}function et(e){return Array.from(e).some(t=>{const a=t.codePointAt(0)??0;return a<=31||a===127})}function Y(e,t){const a=ye(e),r=t==="tag"?Ze:Ye;if(!a||a.length>r||et(a))throw new Error(`Invalid ${t} name.`);return a}function tt(e){if(e.description.length>We)throw new Error("The note must contain at most 20,000 characters.");const t=[...new Map(e.tags.map(({id:n,name:o})=>{const s=Y(o,"tag");if(n!==null&&!/^[A-Za-z0-9_-]{1,128}$/.test(n))throw new Error("Invalid tag ID.");const d={id:n,name:s};return[n===null?`name:${Je(s)}`:`id:${n}`,d]})).values()];if(t.length>be)throw new Error(`A bookmark can have at most ${be} tags.`);if(e.folder?.id!==null&&e.folder?.id!==void 0&&!/^[A-Za-z0-9_-]{1,128}$/.test(e.folder.id))throw new Error("Invalid folder ID.");const a=e.folder?.path??[];if(a.length>ke)throw new Error(`A folder path can have at most ${ke} levels.`);const r=e.folder&&{id:e.folder.id,path:a.map(n=>Y(n,"folder")),...e.folder.newSegments===void 0?{}:{newSegments:e.folder.newSegments.map(n=>Y(n,"folder"))}};return{note:e.description,tags:t,folder:r,...e.organizationChanges===void 0?{}:{organizationChanges:{...e.organizationChanges}}}}function J(e){if(e?.aborted)throw new DOMException("The operation was aborted.","AbortError")}async function ee(e,t,a){J(a);const r=await e(t);if(J(a),!r.ok)throw new Error(r.error.message||r.error.code);return r.data}function at(e){return typeof e=="object"&&e!==null&&Array.isArray(e.tags)}function rt(e){return typeof e=="object"&&e!==null&&Array.isArray(e.folders)}function ve(e,t){if(!e)return null;const a=new Map(t.map(s=>[s.id,s])),r=[],n=new Set;let o=a.get(e);for(;o&&!n.has(o.id);)n.add(o.id),r.unshift(o.name),o=o.parentId?a.get(o.parentId):void 0;return r.length>0?{id:e,path:r}:null}async function we(e){const[t,a]=await Promise.all([ee(e.send,{type:"LIST_TAGS"},e.signal),ee(e.send,{type:"LIST_FOLDERS"},e.signal)]);if(!at(t)||!rt(a))throw new Error("Invalid metadata response.");const r=new Map(t.tags.map(n=>[n.id,n]));return{values:{description:e.bookmark.note,folder:ve(e.bookmark.folderId,a.folders),tags:e.bookmark.tagIds.map(n=>r.get(n)).filter(n=>n!==void 0).map(n=>({id:n.id,name:n.name}))},choices:{folders:a.folders.flatMap(n=>{const o=ve(n.id,a.folders);return o?[{...o,id:n.id}]:[]}),tags:t.tags.map(n=>({id:n.id,name:n.name}))}}}async function Ae(e){const t=tt(e.values);J(e.signal),await ee(e.send,{type:"SAVE_BOOKMARK_METADATA",payload:{id:e.bookmark.id,note:t.note,tags:t.tags,folder:t.folder,...t.organizationChanges===void 0?{}:{organizationChanges:t.organizationChanges}}},e.signal)}const nt=900,ot=6e3;function it(e){if(typeof e!="object"||e===null)return!1;const t=e;return typeof t.id=="string"&&typeof t.text=="string"&&typeof t.url=="string"&&typeof t.author=="object"&&t.author!==null&&typeof t.author.id=="string"&&typeof t.author.username=="string"&&typeof t.author.name=="string"&&typeof t.postCreatedAt=="string"&&Ne(t.media,t.url)&&typeof t.note=="string"&&(t.folderId===null||typeof t.folderId=="string")&&Array.isArray(t.tagIds)&&t.tagIds.every(a=>typeof a=="string")&&typeof t.firstSavedAt=="string"&&typeof t.lastSeenAt=="string"&&(t.archivedAt===null||typeof t.archivedAt=="string")&&typeof t.metadataUpdatedAt=="string"&&(t.status==="current"||t.status==="archived")}function st(e){return e.dataset.testid==="bookmark"?"save":e.dataset.testid==="removeBookmark"?"remove":null}function lt(e,t){const a=e.querySelector('button[data-testid="bookmark"], button[data-testid="removeBookmark"]');return a?t==="save"?a.dataset.testid==="removeBookmark"||a.getAttribute("aria-pressed")==="true":a.dataset.testid==="bookmark"||a.getAttribute("aria-pressed")==="false":!1}function dt(e){return new Promise(t=>{let a=!1,r=null;const n=b=>{a||(a=!0,s.disconnect(),r!==null&&clearTimeout(r),clearTimeout(d),e.signal.removeEventListener("abort",k),t(b))},o=()=>{lt(e.article,e.action)?r??=setTimeout(()=>n(!0),e.stableForMs):r!==null&&(clearTimeout(r),r=null)},s=new MutationObserver(o),d=setTimeout(()=>n(!1),e.timeoutMs),k=()=>n(!1);e.signal.addEventListener("abort",k,{once:!0}),s.observe(e.document.documentElement,{attributes:!0,attributeFilter:["aria-pressed","data-testid"],childList:!0,subtree:!0}),o()})}function ct(){return crypto.randomUUID()}function xe(e){return{close:e("bookmarkPromptClose"),description:e("bookmarkPromptNote"),folder:e("bookmarkPromptFolder"),save:e("bookmarkPromptSave"),tags:e("bookmarkPromptTags"),tagsHelp:e("bookmarkPromptTagsHelp"),pending:e("liveBookmarkPending")}}function Ee(e,t){return!e||typeof e.messages!="object"||e.messages===null?t:a=>e.messages?.[a]??t(a)}function ut(e){const t=new Map,a=new Map;let r=!1;const n=async(s,d,k)=>{const b=t.get(d.id);b?.controller.abort(),b?.metadataController?.abort();const w=a.get(d.id);w?.controller.abort(),w?.metadataController?.abort(),w?.modal?.destroy(),a.delete(d.id);const m={controller:new AbortController,intentId:ct(),metadataController:null,modal:null};t.set(d.id,m);const E={type:"LIVE_BOOKMARK_PENDING",intentId:m.intentId,action:s,bookmark:d};e.onPending?.(k,d.id);const f=e.send(E),y=dt({document:e.document,article:k,action:s,signal:m.controller.signal,stableForMs:e.stableForMs??nt,timeoutMs:e.timeoutMs??ot}),O=await f.catch(()=>null),h=O?.ok?O.data:null;let M=e.translate,_="pending",I="liveBookmarkPending";const A=(i,c)=>{_=i,I=c,m.modal?.setState(i,M(c))};if(!r&&!m.controller.signal.aborted&&h?.prompt&&h.surface==="modal"){M=Ee(h.localization,e.translate);let i=null;const c=new AbortController;m.metadataController=c;let u=null,x=null,p=null;const v=g=>(x=g,p??=Promise.resolve().then(async()=>{for(;x;){const T=x;if(x=null,!u)throw new Error("Bookmark metadata is not ready.");await Ae({bookmark:u,values:T,send:e.send,signal:c.signal})}}).finally(()=>{p=null}),p);i=he({document:e.document,title:M("bookmarkPromptTitle"),bookmarkTitle:d.text||d.url,labels:xe(M),onSave:async g=>{A("pending","liveBookmarkPending");try{return await v(g),e.onChanged?.(d.id),A("ready","liveBookmarkSaved"),!0}catch{return c.signal.aborted||A("ready","liveBookmarkFailed"),!1}},onClose:()=>{i&&a.get(d.id)===m&&(a.delete(d.id),m.metadataController?.abort(),m.metadataController=null,m.modal=null,delete m.prepareMetadata,delete m.setLocalization,i.destroy(),i=null)}}),m.modal=i,m.setLocalization=g=>{M=Ee(g,e.translate),i?.setLabels({title:M("bookmarkPromptTitle"),labels:xe(M)}),i?.setState(_,M(I))},a.set(d.id,m),i.open(),m.prepareMetadata=async g=>{u=g;const{values:T,choices:S}=await we({bookmark:g,send:e.send,signal:c.signal});c.signal.aborted||(i?.setValues(T),i?.setChoices(S))}}const N=await y;if(r||t.get(d.id)!==m)return;if(!N){await e.send({type:"LIVE_BOOKMARK_CANCELLED",intentId:m.intentId}).catch(()=>{}),A("error","liveBookmarkFailed"),e.onChanged?.(d.id),t.delete(d.id);return}const R=await e.send({type:"LIVE_BOOKMARK_CONFIRMED",intentId:m.intentId,action:s,bookmark:d}).catch(()=>null);if(R?.ok)if(s==="save"){const i=R.data?.bookmark;try{if(m.modal){if(!it(i))throw new Error("Invalid bookmark response.");await m.prepareMetadata?.(i)}m.controller.signal.aborted||A("ready","liveBookmarkSaved")}catch{m.controller.signal.aborted||A("ready","liveBookmarkFailed")}}else A("success","liveBookmarkArchived");else A("error","liveBookmarkFailed");e.onChanged?.(d.id),t.delete(d.id)},o=s=>{if(r||!(s.target instanceof Element))return;const d=s.target.closest("button");if(!d)return;const k=st(d);if(!k)return;const b=d.closest('article[data-testid="tweet"]');if(!b)return;const w=le(b)[0];w&&n(k,w,b)};return e.document.addEventListener("click",o,!0),{setLocalization(s){for(const d of new Set(a.values()))d.setLocalization?.(s)},stop(){if(!r){r=!0,e.document.removeEventListener("click",o,!0);for(const s of t.values())s.controller.abort(),s.metadataController?.abort();for(const s of new Set(a.values()))s.controller.abort(),s.metadataController?.abort(),s.modal?.destroy();t.clear(),a.clear()}}}}const Ce="http://www.w3.org/2000/svg",mt={edit:["M13.5 6.5l4 4","M4 20l3.75-.75L18.5 8.5a2.83 2.83 0 0 0-4-4L3.75 15.25 3 19a.83.83 0 0 0 1 1Z"],restore:["M4 9V4l3 3","M5 6a8 8 0 1 1-1 8"],trash:["M4 7h16","M9 7V4h6v3","M7 7l1 13h8l1-13","M10 11v5","M14 11v5"]};function ft(e,t){const a=e.createElementNS(Ce,"svg");a.setAttribute("viewBox","0 0 24 24"),a.setAttribute("width","18"),a.setAttribute("height","18"),a.setAttribute("fill","none"),a.setAttribute("stroke","currentColor"),a.setAttribute("stroke-width","1.8"),a.setAttribute("stroke-linecap","round"),a.setAttribute("stroke-linejoin","round"),a.setAttribute("aria-hidden","true"),a.setAttribute("focusable","false");for(const r of mt[t]){const n=e.createElementNS(Ce,"path");n.setAttribute("d",r),a.append(n)}return a}function pt(e){const t=e.document.createElement("button");return t.type="button",t.className=["icon-button",e.className].filter(Boolean).join(" "),t.setAttribute("aria-label",e.label),t.title=e.label,t.append(ft(e.document,e.icon)),t}const G='article[data-testid="tweet"]',Se="bookmark-x-metadata",gt=/^\/[A-Za-z0-9_]+\/status\/(\d+)$/,ht=String.raw`
  :host {
    color: inherit;
    display: block;
    font-family: inherit;
    font-size: 14px;
    line-height: 1.4;
    min-width: 0;
    width: 100%;
  }

  :host([data-large-text="true"]) { font-size: 15px; }

  .card {
    background: transparent;
    border: 0;
    border-top: 1px solid color-mix(in srgb, currentColor 14%, transparent);
    border-radius: 0;
    box-sizing: border-box;
    display: grid;
    gap: 5px;
    margin: 8px 0 2px;
    max-width: 100%;
    padding: 6px 0 0;
    width: 100%;
  }

  .metadata-heading, .status-row, .tags, .breadcrumb, .metadata-field {
    align-items: center;
    display: flex;
    flex-wrap: wrap;
    gap: 5px;
    min-width: 0;
  }

  .metadata-heading { flex-wrap: nowrap; justify-content: space-between; }
  .metadata-line {
    color: color-mix(in srgb, currentColor 78%, transparent);
    display: grid;
    gap: 5px;
    min-width: 0;
  }
  .metadata-field { align-items: baseline; }
  .metadata-label {
    color: inherit;
    flex: 0 0 auto;
    font-size: 0.75em;
    font-weight: 700;
  }

  .status, .tag {
    border-radius: 999px;
    font-size: 0.75em;
    font-weight: 650;
    padding: 2px 6px;
    max-width: 100%;
    overflow-wrap: anywhere;
    white-space: normal;
  }

  .status[data-state="pending"]::before { content: "… "; }
  .status[data-state="archived"]::before { content: "↺ "; }
  .status, .tag {
    background: color-mix(in srgb, currentColor 9%, transparent);
    color: inherit;
  }
  .status[data-state="uncategorized"] {
    background: color-mix(in srgb, #f4b400 18%, transparent);
  }

  .breadcrumb { font-size: 0.8125em; font-weight: 600; }
  .crumb + .crumb::before { content: "›"; margin-inline-end: 6px; }

  .note {
    color: color-mix(in srgb, currentColor 72%, transparent);
    display: -webkit-box;
    font-size: 0.8125em;
    margin: 0;
    overflow: hidden;
    overflow-wrap: anywhere;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 1;
  }

  .organize {
    align-items: center;
    background: transparent;
    border: 0;
    border-radius: 999px;
    color: inherit;
    cursor: pointer;
    display: inline-flex;
    flex: 0 0 auto;
    gap: 6px;
    justify-content: center;
    height: 34px;
    margin-inline-start: auto;
    padding: 0 10px;
  }
  .organize svg { display: block; height: 18px; width: 18px; }
  .organize-label { font-size: 0.8125em; font-weight: 700; }
  .organize:hover { background: color-mix(in srgb, currentColor 10%, transparent); }
  .organize:focus-visible { outline: 2px solid #1d9bf0; outline-offset: 2px; }

  .visually-hidden {
    border: 0;
    clip: rect(0 0 0 0);
    height: 1px;
    margin: -1px;
    overflow: hidden;
    padding: 0;
    position: absolute;
    white-space: nowrap;
    width: 1px;
  }

  :host([data-high-contrast="true"]) .card {
    border-top-color: color-mix(in srgb, currentColor 34%, transparent);
  }

  @media (forced-colors: active) {
    .card, .status, .tag { border-color: CanvasText; }
    .card { background: Canvas; color: CanvasText; }
  }

  @media (prefers-reduced-motion: reduce) {
    *, *::before, *::after {
      animation-duration: 0.01ms !important;
      animation-iteration-count: 1 !important;
      transition-duration: 0.01ms !important;
    }
  }

  :host([data-reduce-motion="true"]) *,
  :host([data-reduce-motion="true"]) *::before,
  :host([data-reduce-motion="true"]) *::after {
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.01ms !important;
  }
`;function H(e,t,a,r,n){const o=e.createElement(a);return o.className=r,o.textContent=n,t.append(o),o}function bt(e){return Object.values(e.behavior.metadata).some(Boolean)}function te(e){const{document:t,host:a,item:r,settings:n,translate:o}=e,s=a.shadowRoot??a.attachShadow({mode:"open"}),d=t.createElement("style");d.textContent=ht;const k=t.createElement("section");k.className="card";const b=t.createElement("div");b.className="metadata-heading",a.dataset.bookmarkId=r.bookmark.id,a.dataset.largeText=String(n.appearance.largeText),a.dataset.highContrast=String(n.appearance.highContrast),a.dataset.reduceMotion=String(n.appearance.reduceMotion);const w=r.breadcrumb.length>0||r.tags.length>0;if(a.dataset.state=e.pending?"pending":r.bookmark.status==="archived"?"archived":w?"mapped":"uncategorized",a.setAttribute("aria-label",o("bookmarkMetadataLabel")),a.setAttribute("role","group"),e.pending||r.bookmark.status==="archived"?n.behavior.metadata.summary:n.behavior.metadata.categoryIndicator&&!w){const f=t.createElement("div");f.className="status-row";const y=H(t,f,"span","status",e.pending?o("liveBookmarkPending"):r.bookmark.status==="archived"?o("bookmarkMetadataArchived"):o("uncategorizedFolder"));y.dataset.state=e.pending?"pending":r.bookmark.status==="archived"?"archived":"uncategorized",b.append(f)}if(!e.pending&&e.onOrganize){const f=pt({document:t,icon:"edit",label:o("bookmarkMetadataOrganize"),className:"organize"});H(t,f,"span","organize-label",o("bookmarkMetadataOrganize")),f.addEventListener("click",y=>{y.preventDefault(),y.stopPropagation(),e.onOrganize?.(r,o,f)}),b.append(f)}b.childElementCount>0&&k.append(b);const E=t.createElement("div");if(E.className="metadata-line",!e.pending&&n.behavior.metadata.breadcrumb&&r.breadcrumb.length>0){const f=t.createElement("div");f.className="metadata-field metadata-folder",H(t,f,"span","metadata-label",`${o("bookmarkPromptFolder")}:`);const y=t.createElement("div");y.className="breadcrumb",y.setAttribute("aria-label",o("bookmarkPromptFolder"));for(const O of r.breadcrumb)H(t,y,"span","crumb",O);f.append(y),E.append(f)}if(!e.pending&&n.behavior.metadata.tags&&r.tags.length>0){const f=t.createElement("div");f.className="metadata-field metadata-tags",H(t,f,"span","metadata-label",`${o("bookmarkPromptTags")}:`);const y=t.createElement("div");y.className="tags",y.setAttribute("aria-label",o("bookmarkPromptTags"));for(const O of r.tags)H(t,y,"span","tag",O.name);f.append(y),E.append(f)}if(E.childElementCount>0&&k.append(E),!e.pending&&n.behavior.metadata.note&&r.bookmark.note.trim().length>0){const f=t.createElement("p");f.className="note",H(t,f,"span","visually-hidden",`${o("bookmarkPromptNote")}: `),f.append(t.createTextNode(r.bookmark.note)),k.append(f)}s.replaceChildren(d,k)}function ae(e){for(const t of Array.from(e.querySelectorAll('a[href*="/status/"]')))try{const a=new URL(t.href,location.href).pathname.match(gt);if(a?.[1])return a[1]}catch{}return null}function kt(e){const t=e.querySelector('button[data-testid="bookmark"], button[data-testid="removeBookmark"]');return t?.closest('[role="group"]')??t}function yt(e,t){const a=e.defaultView;return typeof a?.requestAnimationFrame=="function"?a.requestAnimationFrame(t):(queueMicrotask(()=>t(performance.now())),0)}function vt(e){const t=new Map,a=new Map,r=new Set;let n=!1,o=null,s=!1,d=0,k=0,b=null,w=!0,m=null,E=i=>i,f=null;const y=(i,c,u,x=!0)=>{const p=m,v=p!==null&&c<p.epoch;let g=v?{...i,...p.value}:i;if(!x&&b){const T=new Map(b.items.map(S=>[S.bookmark.id,S]));for(const S of u??[])T.delete(S);for(const S of g.items)T.set(S.bookmark.id,S);g={...g,items:[...T.values()]}}return v||(k+=1,m={epoch:k,value:{locale:i.locale,messages:i.messages}}),b=g,E=T=>g.messages[T]??T,g},O=i=>{if(b)return Promise.resolve(b);const c=k;return f??=e.lookup([i]).then(u=>n?null:y(u,c)).catch(()=>null).finally(()=>{f=null}),f},h=i=>{t.get(i)?.host.remove(),t.delete(i),a.delete(i)},M=(i,c)=>{const u=kt(i);if(!u)return null;const x=t.get(i);if(x?.bookmarkId===c&&x.host.isConnected)return x.host;h(i);const p=e.document.createElement(Se);for(const v of["click","auxclick","pointerdown","mousedown"])p.addEventListener(v,g=>g.stopPropagation());return u.insertAdjacentElement("afterend",p),t.set(i,{bookmarkId:c,host:p}),p},_=async()=>{if(o=null,n||s)return;s=!0;const i=d;try{for(;!n&&i===d&&r.size>0;){for(const p of[...t.keys()])p.isConnected||h(p);const c=[...r].filter(p=>p.isConnected);r.clear();const u=new Map;for(const p of c){const v=ae(p);if(!v){h(p);continue}const g=u.get(v)??[];g.push(p),u.set(v,g)}if(u.size===0)continue;const x=w;w=!1;try{const p=[...u.keys()],v=k;let g=null;const T=[];for(let C=0;C<p.length;C+=100){const D=await e.lookup(p.slice(C,C+100));if(n||i!==d)return;g=D,T.push(...D.items)}if(!g)continue;g=y({...g,items:T},v,p,x);const S=C=>g.messages[C]??C;if(n||i!==d)return;const z=new Map(g.items.map(C=>[C.bookmark.id,C]));for(const[C,D]of u){const U=z.get(C);for(const P of D){if(!P.isConnected){h(P);continue}if(ae(P)!==C){r.add(P);continue}if(!U){if(a.get(P)===C)continue;h(P);continue}if(!bt(g.settings)){h(P);continue}const Q=M(P,C);Q&&te({document:e.document,host:Q,item:U,settings:g.settings,translate:S,pending:a.get(P)===C,onOrganize:e.onOrganize})}}}catch{}}}finally{s=!1,!n&&r.size>0&&I()}},I=()=>{n||o!==null||(o=(e.scheduleFrame??(i=>yt(e.document,i)))(()=>{_()}))},A=i=>{r.add(i),I()},N=i=>{if(!(i instanceof Element))return;i.matches(G)&&A(i);for(const u of Array.from(i.querySelectorAll(G)))A(u);const c=i.closest(G);c&&A(c)},R=new MutationObserver(i=>{for(const c of i)if(!(c.type==="childList"&&[...Array.from(c.addedNodes),...Array.from(c.removedNodes)].length>0&&[...Array.from(c.addedNodes),...Array.from(c.removedNodes)].every(u=>u instanceof Element&&u.localName===Se))){N(c.target);for(const u of Array.from(c.addedNodes))N(u);for(const u of Array.from(c.removedNodes))N(u)}});R.observe(e.document.documentElement,{attributes:!0,attributeFilter:["href","data-testid"],childList:!0,subtree:!0});for(const i of Array.from(e.document.querySelectorAll(G)))A(i);return{refresh(i){const c=typeof i=="string"?new Set([i]):i?new Set(i):null;c||(w=!0);for(const[u,x]of a)(!c||c.has(x))&&a.delete(u);for(const u of Array.from(e.document.querySelectorAll(G))){const x=c?ae(u):null;(!c||x!==null&&c.has(x))&&A(u)}},setLocalization(i){if(k+=1,m={epoch:k,value:i},!b)return;b={...b,...i},E=u=>i.messages[u]??u;const c=new Map(b.items.map(u=>[u.bookmark.id,u]));for(const[u,x]of t){const p=c.get(x.bookmarkId);p&&te({document:e.document,host:x.host,item:p,settings:b.settings,translate:E,pending:a.get(u)===x.bookmarkId,onOrganize:e.onOrganize})}},async setPending(i,c){a.set(i,c);const u=await O(c);if(!u||n||!i.isConnected||a.get(i)!==c){a.delete(i);return}const x=u.settings;if(!x.behavior.metadata.summary){h(i);return}const p=M(i,c);if(!p)return;a.set(i,c);const g=u.items.find(T=>T.bookmark.id===c)??{bookmark:{id:c,text:"",url:"",note:"",folderId:null,tagIds:[],status:"current"},breadcrumb:[],tags:[]};te({document:e.document,host:p,item:g,settings:x,translate:E,pending:!0})},stop(){if(!n){n=!0,d+=1,R.disconnect(),o!==null&&o!==0&&(e.cancelFrame?e.cancelFrame(o):e.document.defaultView?.cancelAnimationFrame(o));for(const i of[...t.keys()])h(i);r.clear(),a.clear()}}}}const wt=["en","pt_BR","ja","es","zh_CN","de","fr","it"];function At(e){return typeof e=="string"&&wt.includes(e)}let K,$=null;function Te(e){return chrome.runtime.sendMessage(e)}class re extends Error{constructor(t){super(`Capture event was rejected: ${t}`),this.code=t}code}async function X(e){const t=await Te(e);if(typeof t!="object"||t===null)throw new re("invalid_response");const a=t;if(a.ok===!0)return;const r=a.error,n=typeof r=="object"&&r!==null&&typeof r.code=="string"?String(r.code):"rejected";throw new re(n)}async function xt(e,t,a,r){try{const n=await $e({scan:()=>le(document),checkpointIds:a,quickStopThreshold:r,isLoading:()=>V(document),isPageValid:()=>{const o=new URL(window.location.href);return(o.hostname==="x.com"||o.hostname==="www.x.com")&&(o.pathname==="/i/bookmarks"||o.pathname.startsWith("/i/bookmarks/"))},isAtEnd:()=>{const o=document.scrollingElement??document.documentElement;return De({scrollTop:Math.max(window.scrollY,o.scrollTop),viewportHeight:window.innerHeight,documentHeight:o.scrollHeight})},scroll:()=>{je(document,{viewportHeight:window.innerHeight,scrollBy:()=>{window.scrollBy({top:Math.max(Math.round(window.innerHeight*.9),640),behavior:"auto"})}})},waitForContent:o=>Ge({root:document.querySelector("main")??document.body,view:window,signal:o}),signal:t.signal,onBatch:async o=>{await X({type:"SCRAPE_BATCH",runId:e,bookmarks:o})},onProgress:async({fetched:o})=>{await X({type:"SCRAPE_PROGRESS",runId:e,fetched:o})}});if(n.status==="incomplete"){await X({type:"SCRAPE_FAILED",runId:e,errorCode:n.errorCode??"scrape_incomplete"});return}if(n.status==="completed"){await X({type:"SCRAPE_COMPLETE",runId:e,status:"completed",fetched:n.fetched,completionReason:n.completionReason??"stable_end"});return}await X({type:"SCRAPE_COMPLETE",runId:e,status:"cancelled",fetched:n.fetched})}catch(n){if(n instanceof re&&n.code==="stale_capture")return;try{await Te({type:"SCRAPE_FAILED",runId:e,errorCode:t.signal.aborted?"capture_cancelled":"scrape_failed"})}catch{}}finally{K?.runId===e&&(K=void 0)}}function Et(e){if(typeof e!="object"||e===null)return!1;const t=e;if(t.type==="REFRESH_BOOKMARK_LOCALIZATION"){const a=t.localization;return typeof a=="object"&&a!==null&&At(a.locale)&&typeof a.messages=="object"&&a.messages!==null}return t.type==="REFRESH_BOOKMARK_METADATA"?t.bookmarkIds===void 0||Array.isArray(t.bookmarkIds)&&t.bookmarkIds.length<=100&&t.bookmarkIds.every(a=>typeof a=="string"&&/^\d+$/.test(a)):typeof t.runId!="string"?!1:t.type==="CANCEL_SCRAPE"?!0:t.type!=="START_SCRAPE"||t.mode!=="quick"&&t.mode!=="full"||!Array.isArray(t.checkpointIds)||t.checkpointIds.length>Ue||!ce(t.quickStopThreshold)?!1:t.checkpointIds.every(a=>typeof a=="string"&&/^\d+$/.test(a))&&new Set(t.checkpointIds).size===t.checkpointIds.length}const q=vt({document,async lookup(e){const t=await chrome.runtime.sendMessage({type:"GET_BOOKMARK_DECORATIONS",payload:{ids:e}});if(!t.ok)throw new Error(t.error.message);return t.data},onOrganize(e,t){$?.destroy();const a=new AbortController;let r=t;const n=he({document,title:r("bookmarkPromptTitle"),bookmarkTitle:e.bookmark.text||e.bookmark.url,labels:{close:r("bookmarkPromptClose"),description:r("bookmarkPromptNote"),folder:r("bookmarkPromptFolder"),save:r("bookmarkPromptSave"),tags:r("bookmarkPromptTags"),tagsHelp:r("bookmarkPromptTagsHelp"),pending:r("liveBookmarkPending")},onSave:async o=>{n.setState("pending",r("liveBookmarkPending"));try{return await Ae({bookmark:e.bookmark,values:o,send:s=>chrome.runtime.sendMessage(s),signal:a.signal}),n.setState("ready",r("liveBookmarkSaved")),q.refresh(e.bookmark.id),!0}catch{return a.signal.aborted||n.setState("ready",r("liveBookmarkFailed")),!1}},onClose:()=>{a.abort(),n.destroy(),$?.abort===a&&($=null)}});$={abort:a,setLocalization(o){r=s=>o[s]??s,n.setLabels({title:r("bookmarkPromptTitle"),labels:{close:r("bookmarkPromptClose"),description:r("bookmarkPromptNote"),folder:r("bookmarkPromptFolder"),save:r("bookmarkPromptSave"),tags:r("bookmarkPromptTags"),tagsHelp:r("bookmarkPromptTagsHelp"),pending:r("liveBookmarkPending")}})},destroy(){a.abort(),n.destroy()}},n.open(),we({bookmark:e.bookmark,send:o=>chrome.runtime.sendMessage(o),signal:a.signal}).then(({values:o,choices:s})=>{a.signal.aborted||(n.setValues(o),n.setChoices(s),n.setState("ready",""))},()=>{a.signal.aborted||n.setState("ready",r("liveBookmarkFailed"))})}});chrome.runtime.onMessage.addListener((e,t,a)=>{if(t.id!==chrome.runtime.id||!Et(e))return a({accepted:!1}),!1;if(e.type==="REFRESH_BOOKMARK_METADATA")return q.refresh(e.bookmarkIds),a({accepted:!0}),!1;if(e.type==="REFRESH_BOOKMARK_LOCALIZATION")return Le.setLocalization(e.localization),$?.setLocalization(e.localization.messages),q.setLocalization(e.localization),a({accepted:!0}),!1;if(e.type==="CANCEL_SCRAPE")return K?.runId===e.runId&&K.controller.abort(),a({accepted:!0}),!1;if(K)return a({accepted:!1,reason:"capture_in_progress"}),!1;const r=new AbortController;return K={runId:e.runId,controller:r},a({accepted:!0}),xt(e.runId,r,e.checkpointIds,e.quickStopThreshold),!1});const Le=ut({document,send:e=>chrome.runtime.sendMessage(e),translate:e=>chrome.i18n.getMessage(e)||e,onPending:(e,t)=>{q.setPending(e,t)},onChanged:e=>{q.refresh(e)}});window.addEventListener("pagehide",()=>{K?.controller.abort(),$?.destroy(),Le.stop(),q.stop()},{once:!0})})();
