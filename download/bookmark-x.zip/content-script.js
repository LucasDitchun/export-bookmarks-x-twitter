(function(){"use strict";function $(e){return typeof e=="object"&&e!==null&&!Array.isArray(e)}function F(e){if(typeof e!="string"||e.length===0||e.length>2048)return null;try{const t=new URL(e);return t.protocol!=="https:"||t.hostname!=="pbs.twimg.com"||t.username!==""||t.password!==""||t.port!==""?null:(t.hash="",t.toString())}catch{return null}}function X(e){const t=new URL(e);return`${t.origin}${t.pathname}`}function Q(e){return F(e.currentSrc)??F(e.getAttribute("src")||e.src)}function we(e){const t=new Set(e.filter(({thumbnailUrl:n})=>n!==null).map(({postUrl:n})=>n)),r=[],a=new Set;for(const n of e){if(n.thumbnailUrl===null&&t.has(n.postUrl))continue;const o=`${n.postUrl}\0${n.thumbnailUrl===null?"":X(n.thumbnailUrl)}`;if(!a.has(o)&&(a.add(o),r.push(n),r.length===4))break}return r}function ve(e,t){const r=[],a=new Set;for(const i of Array.from(e.querySelectorAll('[data-testid="tweetPhoto"] img'))){const l=Q(i);if(l===null)continue;const c=X(l);if(!a.has(c)&&(a.add(c),r.push(l),r.length===16))break}const o=Array.from(e.querySelectorAll("video")).map(i=>({thumbnailUrl:F(i.poster||i.getAttribute("poster")),postUrl:t}));for(const i of Array.from(e.querySelectorAll('[data-testid="videoPlayer"], [data-testid="videoComponent"]'))){if(i.querySelector("video"))continue;const l=i.querySelector("img");o.push({thumbnailUrl:l?Q(l):null,postUrl:t})}return{images:r,videos:we(o)}}function Ae(e,t){return!$(e)||!Array.isArray(e.images)||!Array.isArray(e.videos)||e.images.length>16||e.videos.length>4||e.images.some(r=>typeof r!="string"||F(r)!==r)?!1:e.videos.every(r=>$(r)&&r.postUrl===t&&(r.thumbnailUrl===null||typeof r.thumbnailUrl=="string"&&F(r.thumbnailUrl)===r.thumbnailUrl))}const Ee=/^\/([A-Za-z0-9_]+)\/status\/(\d+)(?:\/|$)/;function V(e){return(e?.textContent??"").replace(/\s+/g," ").trim()}function xe(e){const t=e.querySelector("time[datetime]")?.closest("a[href]"),r=Array.from(e.querySelectorAll("a[href]"));if(t){const a=r.indexOf(t);a>=0&&r.splice(a,1),r.unshift(t)}for(const a of r){let n;try{n=new URL(a.getAttribute("href")??"","https://x.com")}catch{continue}if(n.hostname!=="x.com"&&n.hostname!=="www.x.com")continue;const o=Ee.exec(n.pathname);if(!o)continue;const i=o[1],l=o[2];if(!(!i||!l))return{id:l,username:i,url:`https://x.com/${i}/status/${l}`}}return null}function Se(e,t){const r=e.querySelector('[data-testid="User-Name"]'),a=Array.from(r?.querySelectorAll("a[href]")??[]).find(i=>i.getAttribute("href")?.toLocaleLowerCase()===`/${t.toLocaleLowerCase()}`),n=V(a);return n&&!n.startsWith("@")?n:Array.from(r?.querySelectorAll("span")??[]).map(V).filter(i=>i.length>0&&!i.startsWith("@")&&i!=="·"&&i.toLocaleLowerCase()!==t.toLocaleLowerCase())[0]??t}function W(e=document){const t=new Map,r=Array.from(e.querySelectorAll('article[data-testid="tweet"]')),a=e instanceof Element&&e.matches('article[data-testid="tweet"]')?[e,...r]:r;for(const n of a){const o=xe(n);if(!o||t.has(o.id))continue;const i=n.querySelector("time[datetime]");t.set(o.id,{id:o.id,text:V(n.querySelector('[data-testid="tweetText"]')),url:o.url,author:{id:o.username.toLocaleLowerCase(),username:o.username,name:Se(n,o.username)},postCreatedAt:i?.dateTime??"",media:ve(n,o.url)})}return[...t.values()]}const Ce=['main [role="progressbar"]','main [data-testid="progressBar"]','main [aria-busy="true"]','main[aria-busy="true"]'].join(",");function Te(e){if(e.closest('[hidden], [aria-hidden="true"]'))return!0;const t=e.ownerDocument.defaultView;if(!t)return!1;const r=t.getComputedStyle(e);return r.display==="none"||r.visibility==="hidden"}function D(e){return Array.from(e.querySelectorAll(Ce)).some(t=>!Te(t))}function Ie({scrollTop:e,viewportHeight:t,documentHeight:r},a=8){return e+t>=r-a}const Y=15,Me=3,Z=50,_e=Z;function J(e){return Number.isSafeInteger(e)&&typeof e=="number"&&e>=Me&&e<=Z}async function Oe({scan:e,checkpointIds:t=[],quickStopThreshold:r=Y,isLoading:a=()=>!1,isAtEnd:n=()=>!0,isPageValid:o=()=>!0,scroll:i,waitForContent:l,onBatch:c,onProgress:b,signal:y,idlePassLimit:u=4,maximumLoadingPasses:v=180,batchSize:f=100}){if(!Number.isSafeInteger(f)||f<1||f>100)throw new RangeError("Scrape batch size must be between 1 and 100.");if(!J(r))throw new RangeError("Quick stop threshold is outside the supported range.");if(!Number.isSafeInteger(u)||u<1)throw new RangeError("Idle pass limit must be a positive integer.");if(!Number.isSafeInteger(v)||v<1)throw new RangeError("Loading pass limit must be a positive integer.");const k=new Set,x=new Set(t);let s=0,g=0,p=0,m=0,h=-1;for(;!y?.aborted;){if(!o())return{status:"incomplete",fetched:s,errorCode:"capture_navigation_changed"};const A=[];let E=!1;for(const _ of e()){if(k.has(_.id))continue;const{id:O}=_;if(k.add(O),A.push(_),g=x.has(O)?g+1:0,x.size>0&&g>=r){E=!0;break}}const S=a(),d=n(),w=A.length===0&&!S&&d;if(A.length>0){p=0;const _=s;for(let O=0;O<A.length&&!y?.aborted;O+=f){const q=A.slice(O,O+f);await c(q),s+=q.length}s>_&&(m=0)}else(S||!d)&&(p=0);h!==s&&(await b({fetched:s}),h=s);const T=E?new Set(e().map(({id:_})=>_)):null,C=l(y);!S&&!w&&!E&&i();const I=await C;if(!o())return{status:"incomplete",fetched:s,errorCode:"capture_navigation_changed"};const R=a(),ye=n();if((S||I?.loadingObserved||R)&&(m+=1,m>=v))return{status:"incomplete",fetched:s,errorCode:"capture_loading_timeout"};if(E&&!y?.aborted){const _=e().some(({id:q})=>!T?.has(q));if(!S&&!I?.loadingObserved&&!R&&!_)return{status:"completed",fetched:s,completionReason:"checkpoint_stop"};g=0}if(w&&!y?.aborted&&I?.reason!=="activity"&&!I?.loadingObserved&&!R&&ye){if(p+=1,p>=u)return{status:"completed",fetched:s,...x.size>0?{completionReason:"stable_end"}:{}}}else(I?.loadingObserved||I?.reason==="activity"||R||!ye)&&(p=0)}return{status:"cancelled",fetched:s}}const ee='article[data-testid="tweet"]';function Le(e){return Array.from(e.querySelectorAll(ee)).filter(t=>!t.parentElement?.closest(ee))}function Ne(e,{viewportHeight:t,scrollBy:r}){const a=Le(e).at(-1),n=a&&a.getBoundingClientRect().top>t*.25;return!a||!n?(r(),"fallback"):(a.scrollIntoView({behavior:"auto",block:"start"}),"anchor")}const Re='article[data-testid="tweet"] a[href*="/status/"]',te='[role="progressbar"], [data-testid="progressBar"], [aria-busy="true"]';function re(e){return e.some(t=>Array.from(t.addedNodes).some(r=>{if(r.nodeType!==1)return!1;const a=r;return a.matches(te)||a.querySelector(te)!==null}))}function ae(e){const t=Array.from(e.querySelectorAll(Re),r=>r.getAttribute("href")??"");return`${D(e.ownerDocument)?"loading":"idle"}|${t.join("|")}`}function Be({root:e,view:t,signal:r,settleMs:a=75,scrollSettleMs:n=180,maximumWaitMs:o=1100}){return r?.aborted?Promise.resolve({reason:"aborted",loadingObserved:!1}):new Promise(i=>{const l=ae(e);let c=D(e.ownerDocument),b=!1,y;const u=p=>{if(b)return;b=!0;const m=s.takeRecords(),h=re(m);c||=h||D(e.ownerDocument),s.disconnect(),y!==void 0&&t.clearTimeout(y),t.clearTimeout(g),t.removeEventListener("scroll",k),r?.removeEventListener("abort",x),i({reason:p==="timeout"&&h?"activity":p,loadingObserved:c})},v=(p,m)=>{y!==void 0&&t.clearTimeout(y),y=t.setTimeout(()=>u(p),m)},f=p=>{const m=re(p);if(c||=m||D(e.ownerDocument),m){v("activity",a);return}ae(e)!==l&&v("activity",a)},k=()=>v("activity",n),x=()=>u("aborted"),s=new t.MutationObserver(f);s.observe(e,{attributes:!0,attributeFilter:["aria-busy","aria-hidden","data-testid","hidden","href","style"],childList:!0,subtree:!0}),t.addEventListener("scroll",k,{passive:!0});const g=t.setTimeout(()=>u("timeout"),o);r?.addEventListener("abort",x,{once:!0})})}const Pe=`
  :host {
    all: initial;
    --modal-bg: #fff;
    --modal-subtle: #f7f9f9;
    --modal-text: #0f1419;
    --modal-muted: #536471;
    --modal-line: #cfd9de;
    --modal-action: #0f1419;
    --modal-action-text: #fff;
    color-scheme: light dark;
    font-family: "Segoe UI Variable Text", "Helvetica Neue", Helvetica, sans-serif;
    font-size: 15px;
    line-height: 1.4;
    position: fixed;
    inset: 0;
    z-index: 2147483647;
  }
  :host([data-theme="dark"]) {
    --modal-bg: #000;
    --modal-subtle: #16181c;
    --modal-text: #e7e9ea;
    --modal-muted: #8b98a5;
    --modal-line: #2f3336;
    --modal-action: #eff3f4;
    --modal-action-text: #0f1419;
  }
  :host([hidden]) { display: none; }
  *, *::before, *::after { box-sizing: border-box; }
  .backdrop {
    align-items: center;
    background: rgb(15 20 25 / 48%);
    display: flex;
    inset: 0;
    justify-content: center;
    padding: 16px;
    position: absolute;
  }
  .dialog {
    background: var(--modal-bg);
    border: 1px solid var(--modal-line);
    border-radius: 20px;
    box-shadow: 0 20px 64px rgb(15 20 25 / 24%);
    color: var(--modal-text);
    max-height: min(680px, calc(100vh - 32px));
    max-width: 480px;
    overflow: auto;
    padding: 20px;
    width: 100%;
  }
  .heading { align-items: start; display: flex; gap: 12px; justify-content: space-between; }
  h2 { font-size: 1.25rem; letter-spacing: -0.02em; line-height: 1.2; margin: 0; }
  .bookmark {
    background: var(--modal-subtle);
    border-radius: 12px;
    color: var(--modal-muted);
    font-size: 0.875rem;
    margin: 14px 0;
    max-height: 84px;
    overscroll-behavior: contain;
    overflow-y: auto;
    overflow-wrap: anywhere;
    padding: 10px 12px;
    scrollbar-gutter: stable;
    white-space: pre-wrap;
  }
  .status { border: 1px solid var(--modal-line); border-radius: 12px; margin: 0 0 14px; padding: 10px 12px; }
  .status[data-state="success"] { border-color: #16733d; }
  .status[data-state="error"] { border-color: #a52222; }
  form { display: grid; gap: 12px; }
  form[hidden] { display: none; }
  label { color: var(--modal-muted); display: block; font-size: 0.8125rem; font-weight: 700; }
  .field-help {
    color: var(--modal-muted);
    font-size: 0.75rem;
    line-height: 1.35;
    margin: 6px 2px 0;
  }
  .metadata-grid { display: grid; gap: 12px; grid-template-columns: repeat(2, minmax(0, 1fr)); }
  .field { min-width: 0; }
  input, select, textarea {
    background: var(--modal-bg);
    border: 1px solid var(--modal-line);
    border-radius: 12px;
    color: var(--modal-text);
    display: block;
    font: inherit;
    margin-top: 5px;
    min-height: 44px;
    padding: 10px 12px;
    width: 100%;
  }
  textarea {
    height: 120px;
    max-height: 120px;
    min-height: 120px;
    overflow-y: auto;
    resize: none;
  }
  button {
    background: var(--modal-action);
    border: 1px solid var(--modal-action);
    border-radius: 999px;
    color: var(--modal-action-text);
    cursor: pointer;
    font: 700 0.875rem/1 "Segoe UI Variable Text", "Helvetica Neue", Helvetica, sans-serif;
    min-height: 44px;
    padding: 10px 18px;
  }
  .close { background: transparent; color: var(--modal-text); flex: 0 0 auto; }
  .save { margin-top: 2px; width: 100%; }
  :focus-visible { outline: 3px solid #1d9bf0; outline-offset: 2px; }
  @media (max-width: 520px) {
    .backdrop { align-items: end; padding: 8px; }
    .dialog { border-radius: 20px 20px 12px 12px; max-height: calc(100vh - 16px); padding: 18px; }
    .metadata-grid { grid-template-columns: 1fr; }
  }
  @media (prefers-reduced-motion: reduce) {
    *, *::before, *::after { scroll-behavior: auto !important; }
  }
`;function Fe(e){const t=e.defaultView;for(const r of[e.body,e.documentElement]){if(!r||!t)continue;const a=t.getComputedStyle(r).backgroundColor.match(/[\d.]+/g)?.map(Number);if(!a||a.length<3||(a[3]??1)===0)continue;const n=a[0]??255,o=a[1]??255,i=a[2]??255;return n*.2126+o*.7152+i*.0722<128}return t?.matchMedia?.("(prefers-color-scheme: dark)").matches??!1}function ne(e,t,r,a,n){const o=e.createElement("label");o.htmlFor=r,o.textContent=a;const i=e.createElement("input");i.id=r,i.value=n,i.autocomplete="off";const l=e.createElement("div");return l.className="field",l.append(o,i),t.append(l),i}function oe(e){const{document:t}=e,r=t.createElement("bookmark-x-note-modal");r.dataset.theme=Fe(t)?"dark":"light",r.hidden=!0,r.tabIndex=-1;const a=r.attachShadow({mode:"open"}),n=t.createElement("style");n.textContent=Pe;const o=t.createElement("div");o.className="backdrop";const i=t.createElement("section");i.className="dialog",i.setAttribute("role","dialog"),i.setAttribute("aria-modal","true"),i.setAttribute("aria-labelledby","bookmark-x-modal-title");const l=t.createElement("div");l.className="heading";const c=t.createElement("h2");c.id="bookmark-x-modal-title",c.textContent=e.title;const b=t.createElement("button");b.className="close",b.type="button",b.textContent=e.labels.close,l.append(c,b);const y=t.createElement("p");y.className="bookmark",y.textContent=e.bookmarkTitle;const u=t.createElement("p");u.className="status",u.setAttribute("role","status"),u.setAttribute("aria-live","polite"),u.setAttribute("aria-atomic","true"),u.dataset.state=e.labels.pending?"pending":"ready",u.textContent=e.labels.pending??"",u.hidden=u.textContent.length===0;const v=t.createElement("form"),f=t.createElement("label");f.htmlFor="bookmark-x-modal-description",f.textContent=e.labels.description;const k=t.createElement("textarea");k.id="bookmark-x-modal-description",k.maxLength=2e4,k.value=e.values?.description??"",v.append(f,k);const x=t.createElement("div");x.className="metadata-grid";const s=ne(t,x,"bookmark-x-modal-tags",e.labels.tags,e.values?.tags??""),g=t.createElement("datalist");if(g.id="bookmark-x-modal-tag-choices",s.setAttribute("list",g.id),e.labels.tagsHelp){const d=t.createElement("p");d.className="field-help",d.id="bookmark-x-modal-tags-help",d.textContent=e.labels.tagsHelp,s.setAttribute("aria-describedby",d.id),s.parentElement?.append(d)}const p=ne(t,x,"bookmark-x-modal-folder",e.labels.folder,e.values?.folder??""),m=t.createElement("datalist");m.id="bookmark-x-modal-folder-choices",p.setAttribute("list",m.id);const h=t.createElement("button");h.className="save",h.type="submit",h.textContent=e.labels.save,v.append(x,g,m,h),v.hidden=e.labels.pending!==void 0,i.append(l,y,u,v),o.append(i),a.append(n,o),t.body.append(r);let A=null;const E=()=>{r.hidden||(r.hidden=!0,e.onClose?.(),A?.focus())};b.addEventListener("click",E),o.addEventListener("click",d=>{d.target===o&&E()}),r.addEventListener("keydown",d=>{if(d.key==="Escape"){d.preventDefault(),E();return}if(d.key!=="Tab")return;const w=Array.from(a.querySelectorAll("button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled])")).filter(C=>!C.hidden),T=a.activeElement;d.shiftKey&&T===w[0]?(d.preventDefault(),w.at(-1)?.focus()):!d.shiftKey&&T===w.at(-1)&&(d.preventDefault(),w[0]?.focus())});let S=!1;return v.addEventListener("submit",d=>{d.preventDefault(),!S&&(S=!0,h.disabled=!0,Promise.resolve(e.onSave?.({description:k.value,folder:p.value,tags:s.value})).then(w=>{w!==!1&&E()}).catch(()=>{}).finally(()=>{S=!1,r.hidden||(h.disabled=!1)}))}),{host:r,open(){const d=t.activeElement;A=d instanceof HTMLElement?d:null,r.hidden=!1,b.focus()},close:E,setValues(d){d.tags!==void 0&&(s.value=d.tags),d.folder!==void 0&&(p.value=d.folder),d.description!==void 0&&(k.value=d.description)},setChoices(d){const w=(T,C)=>{C&&T.replaceChildren(...[...new Set(C)].map(I=>{const R=t.createElement("option");return R.value=I,R}))};w(g,d.tags),w(m,d.folders)},setState(d,w){u.dataset.state=d,u.textContent=w,u.hidden=w.length===0,v.hidden=d!=="ready"},destroy(){r.remove()}}}const De=2e4,ze=50,ie=50,Ke=100,se=32;function H(e){return e.trim().normalize("NFKC")}function B(e){return H(e).toLocaleLowerCase("en-US")}function Ue(e){return Array.from(e).some(t=>{const r=t.codePointAt(0)??0;return r<=31||r===127})}function le(e,t){const r=H(e),a=t==="tag"?ze:Ke;if(!r||r.length>a||Ue(r))throw new Error(`Invalid ${t} name.`);return r}function He(e){if(e.description.length>De)throw new Error("The note must contain at most 20,000 characters.");const t=[...new Map(e.tags.split(",").filter(n=>H(n).length>0).map(n=>{const o=le(n,"tag");return[B(o),o]})).values()];if(t.length>ie)throw new Error(`A bookmark can have at most ${ie} tags.`);const r=e.folder.split("/").filter(n=>H(n).length>0);if(r.length>se)throw new Error(`A folder path can have at most ${se} levels.`);const a=r.map(n=>le(n,"folder"));return{note:e.description,tags:t,folderPath:a}}function j(e){if(e?.aborted)throw new DOMException("The operation was aborted.","AbortError")}async function M(e,t,r){j(r);const a=await e(t);if(j(r),!a.ok)throw new Error(a.error.message||a.error.code);return a.data}function de(e){return typeof e=="object"&&e!==null&&Array.isArray(e.tags)}function qe(e,t){if(typeof e!="object"||e===null)return!1;const r=e.bookmark;return typeof r=="object"&&r!==null&&r.id===t&&Array.isArray(r.tagIds)&&r.tagIds.every(a=>typeof a=="string")}function ce(e){return typeof e=="object"&&e!==null&&Array.isArray(e.folders)}function ue(e,t){if(!e)return"";const r=new Map(t.map(i=>[i.id,i])),a=[],n=new Set;let o=r.get(e);for(;o&&!n.has(o.id);)n.add(o.id),a.unshift(o.name),o=o.parentId?r.get(o.parentId):void 0;return a.join(" / ")}async function me(e){const[t,r]=await Promise.all([M(e.send,{type:"LIST_TAGS"},e.signal),M(e.send,{type:"LIST_FOLDERS"},e.signal)]);if(!de(t)||!ce(r))throw new Error("Invalid metadata response.");const a=new Map(t.tags.map(n=>[n.id,n]));return{values:{description:e.bookmark.note,folder:ue(e.bookmark.folderId,r.folders),tags:e.bookmark.tagIds.map(n=>a.get(n)?.name).filter(n=>typeof n=="string").join(", ")},choices:{folders:r.folders.map(n=>ue(n.id,r.folders)),tags:t.tags.map(n=>n.name)}}}async function Ve(e,t){const[r,a]=await Promise.all([M(e.send,{type:"LIST_TAGS"},e.signal),M(e.send,{type:"GET_BOOKMARK",payload:{id:e.bookmark.id}},e.signal)]);if(!de(r))throw new Error("Invalid tag response.");if(!qe(a,e.bookmark.id))throw new Error("Invalid bookmark response.");const n=new Map(r.tags.map(c=>[c.id,c])),o=a.bookmark.tagIds.map(c=>n.get(c)).filter(c=>c!==void 0),i=new Map(t.map(c=>[B(c),c]));for(const c of o)i.has(B(c.normalizedName||c.name))||await M(e.send,{type:"REMOVE_BOOKMARK_TAG",payload:{id:e.bookmark.id,tagId:c.id}},e.signal);const l=new Set(o.map(c=>B(c.normalizedName||c.name)));for(const[c,b]of i)l.has(c)||await M(e.send,{type:"ADD_BOOKMARK_TAG",payload:{id:e.bookmark.id,name:b}},e.signal)}async function je(e,t){if(t.length===0)return null;const r=await M(e.send,{type:"LIST_FOLDERS"},e.signal);if(!ce(r))throw new Error("Invalid folder response.");const a=[...r.folders];let n=null;for(const o of t){let i=a.find(l=>l.parentId===n&&B(l.name)===B(o));if(!i){const l=await M(e.send,{type:"CREATE_FOLDER",payload:{name:o,parentId:n}},e.signal);if(!l?.folder)throw new Error("Invalid folder response.");const c=l.folder;i=c,a.push(c)}n=i.id}return n}async function fe(e){const t=He(e.values);j(e.signal),await M(e.send,{type:"SAVE_BOOKMARK_NOTE",payload:{id:e.bookmark.id,note:t.note}},e.signal),await Ve(e,t.tags);const r=await je(e,t.folderPath);await M(e.send,{type:"ASSIGN_BOOKMARK_FOLDER",payload:{bookmarkId:e.bookmark.id,folderId:r}},e.signal)}const Ge=900,$e=6e3;function Xe(e){if(typeof e!="object"||e===null)return!1;const t=e;return typeof t.id=="string"&&typeof t.text=="string"&&typeof t.url=="string"&&typeof t.author=="object"&&t.author!==null&&typeof t.author.id=="string"&&typeof t.author.username=="string"&&typeof t.author.name=="string"&&typeof t.postCreatedAt=="string"&&Ae(t.media,t.url)&&typeof t.note=="string"&&(t.folderId===null||typeof t.folderId=="string")&&Array.isArray(t.tagIds)&&t.tagIds.every(r=>typeof r=="string")&&typeof t.firstSavedAt=="string"&&typeof t.lastSeenAt=="string"&&(t.archivedAt===null||typeof t.archivedAt=="string")&&typeof t.metadataUpdatedAt=="string"&&(t.status==="current"||t.status==="archived")}function Qe(e){return e.dataset.testid==="bookmark"?"save":e.dataset.testid==="removeBookmark"?"remove":null}function We(e,t){const r=e.querySelector('button[data-testid="bookmark"], button[data-testid="removeBookmark"]');return r?t==="save"?r.dataset.testid==="removeBookmark"||r.getAttribute("aria-pressed")==="true":r.dataset.testid==="bookmark"||r.getAttribute("aria-pressed")==="false":!1}function Ye(e){return new Promise(t=>{let r=!1,a=null;const n=b=>{r||(r=!0,i.disconnect(),a!==null&&clearTimeout(a),clearTimeout(l),e.signal.removeEventListener("abort",c),t(b))},o=()=>{We(e.article,e.action)?a??=setTimeout(()=>n(!0),e.stableForMs):a!==null&&(clearTimeout(a),a=null)},i=new MutationObserver(o),l=setTimeout(()=>n(!1),e.timeoutMs),c=()=>n(!1);e.signal.addEventListener("abort",c,{once:!0}),i.observe(e.document.documentElement,{attributes:!0,attributeFilter:["aria-pressed","data-testid"],childList:!0,subtree:!0}),o()})}function Ze(){return crypto.randomUUID()}function Je(e){return{close:e("bookmarkPromptClose"),description:e("bookmarkPromptNote"),folder:e("bookmarkPromptFolder"),save:e("bookmarkPromptSave"),tags:e("bookmarkPromptTags"),tagsHelp:e("bookmarkPromptTagsHelp"),pending:e("liveBookmarkPending")}}function et(e){const t=new Map,r=new Map;let a=!1;const n=async(i,l,c)=>{const b=t.get(l.id);b?.controller.abort(),b?.metadataController?.abort();const y=r.get(l.id);y?.controller.abort(),y?.metadataController?.abort(),y?.modal?.destroy(),r.delete(l.id);const u={controller:new AbortController,intentId:Ze(),metadataController:null,modal:null};t.set(l.id,u);const v={type:"LIVE_BOOKMARK_PENDING",intentId:u.intentId,action:i,bookmark:l};e.onPending?.(c,l.id);const f=e.send(v),k=Ye({document:e.document,article:c,action:i,signal:u.controller.signal,stableForMs:e.stableForMs??Ge,timeoutMs:e.timeoutMs??$e}),x=await f.catch(()=>null),s=x?.ok?x.data:null;if(!a&&!u.controller.signal.aborted&&s?.prompt&&s.surface==="modal"){let m=null;const h=new AbortController;u.metadataController=h;let A=null,E=null,S=null;const d=w=>(E=w,S??=Promise.resolve().then(async()=>{for(;E;){const T=E;if(E=null,!A)throw new Error("Bookmark metadata is not ready.");await fe({bookmark:A,values:T,send:e.send,signal:h.signal})}}).finally(()=>{S=null}),S);m=oe({document:e.document,title:e.translate("bookmarkPromptTitle"),bookmarkTitle:l.text||l.url,labels:Je(e.translate),onSave:async w=>{u.modal?.setState("pending",e.translate("liveBookmarkPending"));try{return await d(w),e.onChanged?.(l.id),u.modal?.setState("ready",e.translate("liveBookmarkSaved")),!0}catch{return h.signal.aborted||u.modal?.setState("ready",e.translate("liveBookmarkFailed")),!1}},onClose:()=>{m&&r.get(l.id)===u&&(r.delete(l.id),u.metadataController?.abort(),u.metadataController=null,u.modal=null,delete u.prepareMetadata,m.destroy(),m=null)}}),u.modal=m,r.set(l.id,u),m.open(),u.prepareMetadata=async w=>{A=w;const{values:T,choices:C}=await me({bookmark:w,send:e.send,signal:h.signal});h.signal.aborted||(m?.setValues(T),m?.setChoices(C))}}const g=await k;if(a||t.get(l.id)!==u)return;if(!g){await e.send({type:"LIVE_BOOKMARK_CANCELLED",intentId:u.intentId}).catch(()=>{}),u.modal?.setState("error",e.translate("liveBookmarkFailed")),e.onChanged?.(l.id),t.delete(l.id);return}const p=await e.send({type:"LIVE_BOOKMARK_CONFIRMED",intentId:u.intentId,action:i,bookmark:l}).catch(()=>null);if(p?.ok)if(i==="save"){const m=p.data?.bookmark;try{if(u.modal){if(!Xe(m))throw new Error("Invalid bookmark response.");await u.prepareMetadata?.(m)}u.controller.signal.aborted||u.modal?.setState("ready",e.translate("liveBookmarkSaved"))}catch{u.controller.signal.aborted||u.modal?.setState("ready",e.translate("liveBookmarkFailed"))}}else u.modal?.setState("success",e.translate("liveBookmarkArchived"));else u.modal?.setState("error",e.translate("liveBookmarkFailed"));e.onChanged?.(l.id),t.delete(l.id)},o=i=>{if(a||!(i.target instanceof Element))return;const l=i.target.closest("button");if(!l)return;const c=Qe(l);if(!c)return;const b=l.closest('article[data-testid="tweet"]');if(!b)return;const y=W(b)[0];y&&n(c,y,b)};return e.document.addEventListener("click",o,!0),{stop(){if(!a){a=!0,e.document.removeEventListener("click",o,!0);for(const i of t.values())i.controller.abort(),i.metadataController?.abort();for(const i of new Set(r.values()))i.controller.abort(),i.metadataController?.abort(),i.modal?.destroy();t.clear(),r.clear()}}}}const pe="http://www.w3.org/2000/svg",tt={edit:["M13.5 6.5l4 4","M4 20l3.75-.75L18.5 8.5a2.83 2.83 0 0 0-4-4L3.75 15.25 3 19a.83.83 0 0 0 1 1Z"],trash:["M4 7h16","M9 7V4h6v3","M7 7l1 13h8l1-13","M10 11v5","M14 11v5"]};function rt(e,t){const r=e.createElementNS(pe,"svg");r.setAttribute("viewBox","0 0 24 24"),r.setAttribute("width","18"),r.setAttribute("height","18"),r.setAttribute("fill","none"),r.setAttribute("stroke","currentColor"),r.setAttribute("stroke-width","1.8"),r.setAttribute("stroke-linecap","round"),r.setAttribute("stroke-linejoin","round"),r.setAttribute("aria-hidden","true"),r.setAttribute("focusable","false");for(const a of tt[t]){const n=e.createElementNS(pe,"path");n.setAttribute("d",a),r.append(n)}return r}function at(e){const t=e.document.createElement("button");return t.type="button",t.className=["icon-button",e.className].filter(Boolean).join(" "),t.setAttribute("aria-label",e.label),t.title=e.label,t.append(rt(e.document,e.icon)),t}const z='article[data-testid="tweet"]',ge="bookmark-x-metadata",nt=/^\/[A-Za-z0-9_]+\/status\/(\d+)$/,ot={appearance:{largeText:!0,highContrast:!0,reduceMotion:!1},behavior:{surface:"modal",promptAfterBookmark:!0,metadata:{summary:!0,breadcrumb:!0,tags:!0,note:!0,categoryIndicator:!0}},export:{includeLink:!0,includeText:!0,includeAuthor:!0,includeDate:!0,includeImages:!0,includeVideos:!0,includeNote:!0,includeTags:!0,includeFolder:!0,includeFirstSavedAt:!0,includeLastSeenAt:!0},search:{filterAsYouType:!0},data:{keepArchived:!0,quickStopThreshold:Y}},it=String.raw`
  :host {
    color: inherit;
    display: block;
    font-family: inherit;
    font-size: 14px;
    line-height: 1.4;
    min-width: 0;
    width: 100%;
  }

  :host([data-large-text="true"]) { font-size: 15px; }

  .card {
    background: transparent;
    border: 0;
    border-top: 1px solid color-mix(in srgb, currentColor 14%, transparent);
    border-radius: 0;
    box-sizing: border-box;
    display: grid;
    gap: 5px;
    margin: 8px 0 2px;
    max-width: 100%;
    padding: 6px 0 0;
    width: 100%;
  }

  .metadata-heading, .status-row, .tags, .breadcrumb, .metadata-field {
    align-items: center;
    display: flex;
    flex-wrap: wrap;
    gap: 5px;
    min-width: 0;
  }

  .metadata-heading { flex-wrap: nowrap; justify-content: space-between; }
  .metadata-line {
    color: color-mix(in srgb, currentColor 78%, transparent);
    display: grid;
    gap: 5px;
    min-width: 0;
  }
  .metadata-field { align-items: baseline; }
  .metadata-label {
    color: inherit;
    flex: 0 0 auto;
    font-size: 0.75em;
    font-weight: 700;
  }

  .status, .tag {
    border-radius: 999px;
    font-size: 0.75em;
    font-weight: 650;
    padding: 2px 6px;
    max-width: 100%;
    overflow-wrap: anywhere;
    white-space: normal;
  }

  .status[data-state="pending"]::before { content: "… "; }
  .status[data-state="archived"]::before { content: "↺ "; }
  .status, .tag {
    background: color-mix(in srgb, currentColor 9%, transparent);
    color: inherit;
  }
  .status[data-state="uncategorized"] {
    background: color-mix(in srgb, #f4b400 18%, transparent);
  }

  .breadcrumb { font-size: 0.8125em; font-weight: 600; }
  .crumb + .crumb::before { content: "›"; margin-inline-end: 6px; }

  .note {
    color: color-mix(in srgb, currentColor 72%, transparent);
    display: -webkit-box;
    font-size: 0.8125em;
    margin: 0;
    overflow: hidden;
    overflow-wrap: anywhere;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 1;
  }

  .organize {
    align-items: center;
    background: transparent;
    border: 0;
    border-radius: 999px;
    color: inherit;
    cursor: pointer;
    display: inline-flex;
    flex: 0 0 auto;
    gap: 6px;
    justify-content: center;
    height: 34px;
    margin-inline-start: auto;
    padding: 0 10px;
  }
  .organize svg { display: block; height: 18px; width: 18px; }
  .organize-label { font-size: 0.8125em; font-weight: 700; }
  .organize:hover { background: color-mix(in srgb, currentColor 10%, transparent); }
  .organize:focus-visible { outline: 2px solid #1d9bf0; outline-offset: 2px; }

  .visually-hidden {
    border: 0;
    clip: rect(0 0 0 0);
    height: 1px;
    margin: -1px;
    overflow: hidden;
    padding: 0;
    position: absolute;
    white-space: nowrap;
    width: 1px;
  }

  :host([data-high-contrast="true"]) .card {
    border-top-color: color-mix(in srgb, currentColor 34%, transparent);
  }

  @media (forced-colors: active) {
    .card, .status, .tag { border-color: CanvasText; }
    .card { background: Canvas; color: CanvasText; }
  }

  @media (prefers-reduced-motion: reduce) {
    *, *::before, *::after {
      animation-duration: 0.01ms !important;
      animation-iteration-count: 1 !important;
      transition-duration: 0.01ms !important;
    }
  }

  :host([data-reduce-motion="true"]) *,
  :host([data-reduce-motion="true"]) *::before,
  :host([data-reduce-motion="true"]) *::after {
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.01ms !important;
  }
`;function L(e,t,r,a,n){const o=e.createElement(r);return o.className=a,o.textContent=n,t.append(o),o}function st(e){return Object.values(e.behavior.metadata).some(Boolean)}function he(e){const{document:t,host:r,item:a,settings:n,translate:o}=e,i=r.shadowRoot??r.attachShadow({mode:"open"}),l=t.createElement("style");l.textContent=it;const c=t.createElement("section");c.className="card";const b=t.createElement("div");b.className="metadata-heading",r.dataset.bookmarkId=a.bookmark.id,r.dataset.largeText=String(n.appearance.largeText),r.dataset.highContrast=String(n.appearance.highContrast),r.dataset.reduceMotion=String(n.appearance.reduceMotion);const y=a.breadcrumb.length>0||a.tags.length>0;if(r.dataset.state=e.pending?"pending":a.bookmark.status==="archived"?"archived":y?"mapped":"uncategorized",r.setAttribute("aria-label",o("bookmarkMetadataLabel")),r.setAttribute("role","group"),e.pending||a.bookmark.status==="archived"?n.behavior.metadata.summary:n.behavior.metadata.categoryIndicator&&!y){const f=t.createElement("div");f.className="status-row";const k=L(t,f,"span","status",e.pending?o("liveBookmarkPending"):a.bookmark.status==="archived"?o("bookmarkMetadataArchived"):o("uncategorizedFolder"));k.dataset.state=e.pending?"pending":a.bookmark.status==="archived"?"archived":"uncategorized",b.append(f)}if(!e.pending&&e.onOrganize){const f=at({document:t,icon:"edit",label:o("bookmarkMetadataOrganize"),className:"organize"});L(t,f,"span","organize-label",o("bookmarkMetadataOrganize")),f.addEventListener("click",k=>{k.preventDefault(),k.stopPropagation(),e.onOrganize?.(a,o,f)}),b.append(f)}b.childElementCount>0&&c.append(b);const v=t.createElement("div");if(v.className="metadata-line",!e.pending&&n.behavior.metadata.breadcrumb&&a.breadcrumb.length>0){const f=t.createElement("div");f.className="metadata-field metadata-folder",L(t,f,"span","metadata-label",`${o("bookmarkPromptFolder")}:`);const k=t.createElement("div");k.className="breadcrumb",k.setAttribute("aria-label",o("bookmarkPromptFolder"));for(const x of a.breadcrumb)L(t,k,"span","crumb",x);f.append(k),v.append(f)}if(!e.pending&&n.behavior.metadata.tags&&a.tags.length>0){const f=t.createElement("div");f.className="metadata-field metadata-tags",L(t,f,"span","metadata-label",`${o("bookmarkPromptTags")}:`);const k=t.createElement("div");k.className="tags",k.setAttribute("aria-label",o("bookmarkPromptTags"));for(const x of a.tags)L(t,k,"span","tag",x.name);f.append(k),v.append(f)}if(v.childElementCount>0&&c.append(v),!e.pending&&n.behavior.metadata.note&&a.bookmark.note.trim().length>0){const f=t.createElement("p");f.className="note",L(t,f,"span","visually-hidden",`${o("bookmarkPromptNote")}: `),f.append(t.createTextNode(a.bookmark.note)),c.append(f)}i.replaceChildren(l,c)}function be(e){for(const t of Array.from(e.querySelectorAll('a[href*="/status/"]')))try{const r=new URL(t.href,location.href).pathname.match(nt);if(r?.[1])return r[1]}catch{}return null}function lt(e){const t=e.querySelector('button[data-testid="bookmark"], button[data-testid="removeBookmark"]');return t?.closest('[role="group"]')??t}function dt(e,t){const r=e.defaultView;return typeof r?.requestAnimationFrame=="function"?r.requestAnimationFrame(t):(queueMicrotask(()=>t(performance.now())),0)}function ct(e){const t=new Map,r=new Map,a=new Set;let n=!1,o=null,i=0,l=null,c=s=>s;const b=s=>{t.get(s)?.host.remove(),t.delete(s),r.delete(s)},y=(s,g)=>{const p=lt(s);if(!p)return null;const m=t.get(s);if(m?.bookmarkId===g&&m.host.isConnected)return m.host;b(s);const h=e.document.createElement(ge);for(const A of["click","auxclick","pointerdown","mousedown"])h.addEventListener(A,E=>E.stopPropagation());return p.insertAdjacentElement("afterend",h),t.set(s,{bookmarkId:g,host:h}),h},u=async()=>{if(o=null,n)return;const s=++i;for(const m of[...t.keys()])m.isConnected||b(m);const g=[...a].filter(m=>m.isConnected);a.clear();const p=new Map;for(const m of g){const h=be(m);if(!h){b(m);continue}const A=p.get(h)??[];A.push(m),p.set(h,A)}if(p.size!==0)try{const m=[...p.keys()];let h=null;const A=[];for(let d=0;d<m.length;d+=100){const w=await e.lookup(m.slice(d,d+100));if(n||s!==i)return;h=w,A.push(...w.items)}if(!h)return;h={...h,items:A};const E=d=>h.messages[d]??d;if(n||s!==i)return;l=h,c=E;const S=new Map(h.items.map(d=>[d.bookmark.id,d]));for(const[d,w]of p){const T=S.get(d);for(const C of w){if(!T){if(r.get(C)===d)continue;b(C);continue}if(!st(h.settings)){b(C);continue}const I=y(C,d);I&&he({document:e.document,host:I,item:T,settings:h.settings,translate:E,pending:r.get(C)===d,onOrganize:e.onOrganize})}}}catch{}},v=()=>{n||o!==null||(o=(e.scheduleFrame??(s=>dt(e.document,s)))(()=>{u()}))},f=s=>{a.add(s),v()},k=s=>{if(!(s instanceof Element))return;s.matches(z)&&f(s);for(const p of Array.from(s.querySelectorAll(z)))f(p);const g=s.closest(z);g&&f(g)},x=new MutationObserver(s=>{for(const g of s)if(!(g.type==="childList"&&[...Array.from(g.addedNodes),...Array.from(g.removedNodes)].length>0&&[...Array.from(g.addedNodes),...Array.from(g.removedNodes)].every(p=>p instanceof Element&&p.localName===ge))){k(g.target);for(const p of Array.from(g.addedNodes))k(p);for(const p of Array.from(g.removedNodes))k(p)}});x.observe(e.document.documentElement,{attributes:!0,attributeFilter:["href","data-testid"],childList:!0,subtree:!0});for(const s of Array.from(e.document.querySelectorAll(z)))f(s);return{refresh(s){for(const[g,p]of r)(!s||p===s)&&r.delete(g);for(const g of Array.from(e.document.querySelectorAll(z)))(!s||be(g)===s)&&f(g)},setPending(s,g){const p=y(s,g);if(!p)return;const m=l?.settings??ot;if(!m.behavior.metadata.summary){b(s);return}r.set(s,g);const A=l?.items.find(E=>E.bookmark.id===g)??{bookmark:{id:g,text:"",url:"",author:{id:"",username:"",name:""},postCreatedAt:"",media:{images:[],videos:[]},note:"",folderId:null,tagIds:[],firstSavedAt:"",lastSeenAt:"",archivedAt:null,metadataUpdatedAt:"",status:"current"},breadcrumb:[],tags:[]};he({document:e.document,host:p,item:A,settings:m,translate:c,pending:!0})},stop(){if(!n){n=!0,i+=1,x.disconnect(),o!==null&&o!==0&&(e.cancelFrame?e.cancelFrame(o):e.document.defaultView?.cancelAnimationFrame(o));for(const s of[...t.keys()])b(s);a.clear(),r.clear()}}}}let N,K=null;function ke(e){return chrome.runtime.sendMessage(e)}class G extends Error{constructor(t){super(`Capture event was rejected: ${t}`),this.code=t}code}async function U(e){const t=await ke(e);if(typeof t!="object"||t===null)throw new G("invalid_response");const r=t;if(r.ok===!0)return;const a=r.error,n=typeof a=="object"&&a!==null&&typeof a.code=="string"?String(a.code):"rejected";throw new G(n)}async function ut(e,t,r,a){try{const n=await Oe({scan:()=>W(document),checkpointIds:r,quickStopThreshold:a,isLoading:()=>D(document),isPageValid:()=>{const o=new URL(window.location.href);return(o.hostname==="x.com"||o.hostname==="www.x.com")&&(o.pathname==="/i/bookmarks"||o.pathname.startsWith("/i/bookmarks/"))},isAtEnd:()=>{const o=document.scrollingElement??document.documentElement;return Ie({scrollTop:Math.max(window.scrollY,o.scrollTop),viewportHeight:window.innerHeight,documentHeight:o.scrollHeight})},scroll:()=>{Ne(document,{viewportHeight:window.innerHeight,scrollBy:()=>{window.scrollBy({top:Math.max(Math.round(window.innerHeight*.9),640),behavior:"auto"})}})},waitForContent:o=>Be({root:document.querySelector("main")??document.body,view:window,signal:o}),signal:t.signal,onBatch:async o=>{await U({type:"SCRAPE_BATCH",runId:e,bookmarks:o})},onProgress:async({fetched:o})=>{await U({type:"SCRAPE_PROGRESS",runId:e,fetched:o})}});if(n.status==="incomplete"){await U({type:"SCRAPE_FAILED",runId:e,errorCode:n.errorCode??"scrape_incomplete"});return}if(n.status==="completed"){await U({type:"SCRAPE_COMPLETE",runId:e,status:"completed",fetched:n.fetched,completionReason:n.completionReason??"stable_end"});return}await U({type:"SCRAPE_COMPLETE",runId:e,status:"cancelled",fetched:n.fetched})}catch(n){if(n instanceof G&&n.code==="stale_capture")return;try{await ke({type:"SCRAPE_FAILED",runId:e,errorCode:t.signal.aborted?"capture_cancelled":"scrape_failed"})}catch{}}finally{N?.runId===e&&(N=void 0)}}function mt(e){if(typeof e!="object"||e===null)return!1;const t=e;return t.type==="REFRESH_BOOKMARK_METADATA"?t.bookmarkIds===void 0||Array.isArray(t.bookmarkIds)&&t.bookmarkIds.length<=100&&t.bookmarkIds.every(r=>typeof r=="string"&&/^\d+$/.test(r)):typeof t.runId!="string"?!1:t.type==="CANCEL_SCRAPE"?!0:t.type!=="START_SCRAPE"||t.mode!=="quick"&&t.mode!=="full"||!Array.isArray(t.checkpointIds)||t.checkpointIds.length>_e||!J(t.quickStopThreshold)?!1:t.checkpointIds.every(r=>typeof r=="string"&&/^\d+$/.test(r))&&new Set(t.checkpointIds).size===t.checkpointIds.length}const P=ct({document,async lookup(e){const t=await chrome.runtime.sendMessage({type:"GET_BOOKMARK_DECORATIONS",payload:{ids:e}});if(!t.ok)throw new Error(t.error.message);return t.data},onOrganize(e,t){K?.destroy();const r=new AbortController,a=oe({document,title:t("bookmarkPromptTitle"),bookmarkTitle:e.bookmark.text||e.bookmark.url,labels:{close:t("bookmarkPromptClose"),description:t("bookmarkPromptNote"),folder:t("bookmarkPromptFolder"),save:t("bookmarkPromptSave"),tags:t("bookmarkPromptTags"),tagsHelp:t("bookmarkPromptTagsHelp"),pending:t("liveBookmarkPending")},onSave:async n=>{a.setState("pending",t("liveBookmarkPending"));try{return await fe({bookmark:e.bookmark,values:n,send:o=>chrome.runtime.sendMessage(o),signal:r.signal}),a.setState("ready",t("liveBookmarkSaved")),P.refresh(e.bookmark.id),!0}catch{return r.signal.aborted||a.setState("ready",t("liveBookmarkFailed")),!1}},onClose:()=>{r.abort(),a.destroy(),K?.abort===r&&(K=null)}});K={abort:r,destroy(){r.abort(),a.destroy()}},a.open(),me({bookmark:e.bookmark,send:n=>chrome.runtime.sendMessage(n),signal:r.signal}).then(({values:n,choices:o})=>{r.signal.aborted||(a.setValues(n),a.setChoices(o),a.setState("ready",""))},()=>{r.signal.aborted||a.setState("ready",t("liveBookmarkFailed"))})}});chrome.runtime.onMessage.addListener((e,t,r)=>{if(t.id!==chrome.runtime.id||!mt(e))return r({accepted:!1}),!1;if(e.type==="REFRESH_BOOKMARK_METADATA"){if(e.bookmarkIds)for(const n of e.bookmarkIds)P.refresh(n);else P.refresh();return r({accepted:!0}),!1}if(e.type==="CANCEL_SCRAPE")return N?.runId===e.runId&&N.controller.abort(),r({accepted:!0}),!1;if(N)return r({accepted:!1,reason:"capture_in_progress"}),!1;const a=new AbortController;return N={runId:e.runId,controller:a},r({accepted:!0}),ut(e.runId,a,e.checkpointIds,e.quickStopThreshold),!1});const ft=et({document,send:e=>chrome.runtime.sendMessage(e),translate:e=>chrome.i18n.getMessage(e)||e,onPending:(e,t)=>P.setPending(e,t),onChanged:e=>P.refresh(e)});window.addEventListener("pagehide",()=>{N?.controller.abort(),K?.destroy(),ft.stop(),P.stop()},{once:!0})})();
