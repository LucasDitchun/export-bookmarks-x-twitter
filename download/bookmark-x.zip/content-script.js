(function(){"use strict";function H(e){return typeof e=="object"&&e!==null&&!Array.isArray(e)}function R(e){if(typeof e!="string"||e.length===0||e.length>2048)return null;try{const t=new URL(e);return t.protocol!=="https:"||t.hostname!=="pbs.twimg.com"||t.username!==""||t.password!==""||t.port!==""?null:(t.hash="",t.toString())}catch{return null}}function V(e){const t=new URL(e);return`${t.origin}${t.pathname}`}function j(e){return R(e.currentSrc)??R(e.getAttribute("src")||e.src)}function le(e){const t=new Set(e.filter(({thumbnailUrl:a})=>a!==null).map(({postUrl:a})=>a)),r=[],n=new Set;for(const a of e){if(a.thumbnailUrl===null&&t.has(a.postUrl))continue;const o=`${a.postUrl}\0${a.thumbnailUrl===null?"":V(a.thumbnailUrl)}`;if(!n.has(o)&&(n.add(o),r.push(a),r.length===4))break}return r}function ue(e,t){const r=[],n=new Set;for(const i of Array.from(e.querySelectorAll('[data-testid="tweetPhoto"] img'))){const s=j(i);if(s===null)continue;const h=V(s);if(!n.has(h)&&(n.add(h),r.push(s),r.length===16))break}const o=Array.from(e.querySelectorAll("video")).map(i=>({thumbnailUrl:R(i.poster||i.getAttribute("poster")),postUrl:t}));for(const i of Array.from(e.querySelectorAll('[data-testid="videoPlayer"], [data-testid="videoComponent"]'))){if(i.querySelector("video"))continue;const s=i.querySelector("img");o.push({thumbnailUrl:s?j(s):null,postUrl:t})}return{images:r,videos:le(o)}}function me(e,t){return!H(e)||!Array.isArray(e.images)||!Array.isArray(e.videos)||e.images.length>16||e.videos.length>4||e.images.some(r=>typeof r!="string"||R(r)!==r)?!1:e.videos.every(r=>H(r)&&r.postUrl===t&&(r.thumbnailUrl===null||typeof r.thumbnailUrl=="string"&&R(r.thumbnailUrl)===r.thumbnailUrl))}const fe=/^\/([A-Za-z0-9_]+)\/status\/(\d+)(?:\/|$)/;function q(e){return(e?.textContent??"").replace(/\s+/g," ").trim()}function pe(e){const t=e.querySelector("time[datetime]")?.closest("a[href]"),r=Array.from(e.querySelectorAll("a[href]"));if(t){const n=r.indexOf(t);n>=0&&r.splice(n,1),r.unshift(t)}for(const n of r){let a;try{a=new URL(n.getAttribute("href")??"","https://x.com")}catch{continue}if(a.hostname!=="x.com"&&a.hostname!=="www.x.com")continue;const o=fe.exec(a.pathname);if(!o)continue;const i=o[1],s=o[2];if(!(!i||!s))return{id:s,username:i,url:`https://x.com/${i}/status/${s}`}}return null}function he(e,t){const r=e.querySelector('[data-testid="User-Name"]'),n=Array.from(r?.querySelectorAll("a[href]")??[]).find(i=>i.getAttribute("href")?.toLocaleLowerCase()===`/${t.toLocaleLowerCase()}`),a=q(n);return a&&!a.startsWith("@")?a:Array.from(r?.querySelectorAll("span")??[]).map(q).filter(i=>i.length>0&&!i.startsWith("@")&&i!=="·"&&i.toLocaleLowerCase()!==t.toLocaleLowerCase())[0]??t}function $(e=document){const t=new Map,r=Array.from(e.querySelectorAll('article[data-testid="tweet"]')),n=e instanceof Element&&e.matches('article[data-testid="tweet"]')?[e,...r]:r;for(const a of n){const o=pe(a);if(!o||t.has(o.id))continue;const i=a.querySelector("time[datetime]");t.set(o.id,{id:o.id,text:q(a.querySelector('[data-testid="tweetText"]')),url:o.url,author:{id:o.username.toLocaleLowerCase(),username:o.username,name:he(a,o.username)},postCreatedAt:i?.dateTime??"",media:ue(a,o.url)})}return[...t.values()]}const ge=['main [role="progressbar"]','main [data-testid="progressBar"]','main [aria-busy="true"]','main[aria-busy="true"]'].join(",");function be(e){if(e.closest('[hidden], [aria-hidden="true"]'))return!0;const t=e.ownerDocument.defaultView;if(!t)return!1;const r=t.getComputedStyle(e);return r.display==="none"||r.visibility==="hidden"}function B(e){return Array.from(e.querySelectorAll(ge)).some(t=>!be(t))}function ye({scrollTop:e,viewportHeight:t,documentHeight:r},n=8){return e+t>=r-n}async function ke({scan:e,checkpointIds:t=[],isLoading:r=()=>!1,isAtEnd:n=()=>!0,isPageValid:a=()=>!0,scroll:o,waitForContent:i,onBatch:s,onProgress:h,signal:u,idlePassLimit:g=4,maximumLoadingPasses:l=180,batchSize:w=100}){if(!Number.isSafeInteger(w)||w<1||w>100)throw new RangeError("Scrape batch size must be between 1 and 100.");if(!Number.isSafeInteger(g)||g<1)throw new RangeError("Idle pass limit must be a positive integer.");if(!Number.isSafeInteger(l)||l<1)throw new RangeError("Loading pass limit must be a positive integer.");const A=new Set,x=new Set(t);let b=0,c=0,f=0,p=0,m=-1;for(;!u?.aborted;){if(!a())return{status:"incomplete",fetched:b,errorCode:"capture_navigation_changed"};const d=[];let k=!1;for(const O of e()){if(A.has(O.id))continue;const{id:_}=O;if(A.add(_),d.push(O),c=x.has(_)?c+1:0,x.size>0&&c>=3){k=!0;break}}const v=r(),L=n(),y=d.length===0&&!v&&L;if(d.length>0){f=0;const O=b;for(let _=0;_<d.length&&!u?.aborted;_+=w){const de=d.slice(_,_+w);await s(de),b+=de.length}b>O&&(p=0)}else(v||!L)&&(f=0);m!==b&&(await h({fetched:b}),m=b);const E=i(u);!v&&!y&&!k&&o();const S=await E;if(!a())return{status:"incomplete",fetched:b,errorCode:"capture_navigation_changed"};const T=r(),K=n();if((v||S?.loadingObserved||T)&&(p+=1,p>=l))return{status:"incomplete",fetched:b,errorCode:"capture_loading_timeout"};if(k&&!u?.aborted){if(!v&&S?.reason==="timeout"&&!S?.loadingObserved&&!T)return{status:"completed",fetched:b,completionReason:"checkpoint_stop"};c=0}if(y&&!u?.aborted&&S?.reason!=="activity"&&!S?.loadingObserved&&!T&&K){if(f+=1,f>=g)return{status:"completed",fetched:b,...x.size>0?{completionReason:"stable_end"}:{}}}else(S?.loadingObserved||S?.reason==="activity"||T||!K)&&(f=0)}return{status:"cancelled",fetched:b}}const X='article[data-testid="tweet"]';function we(e){return Array.from(e.querySelectorAll(X)).filter(t=>!t.parentElement?.closest(X))}function ve(e,{viewportHeight:t,scrollBy:r}){const n=we(e).at(-1),a=n&&n.getBoundingClientRect().top>t*.25;return!n||!a?(r(),"fallback"):(n.scrollIntoView({behavior:"auto",block:"start"}),"anchor")}const Ae='article[data-testid="tweet"] a[href*="/status/"]',W='[role="progressbar"], [data-testid="progressBar"], [aria-busy="true"]';function Y(e){return e.some(t=>Array.from(t.addedNodes).some(r=>{if(r.nodeType!==1)return!1;const n=r;return n.matches(W)||n.querySelector(W)!==null}))}function Q(e){const t=Array.from(e.querySelectorAll(Ae),r=>r.getAttribute("href")??"");return`${B(e.ownerDocument)?"loading":"idle"}|${t.join("|")}`}function xe({root:e,view:t,signal:r,settleMs:n=75,scrollSettleMs:a=180,maximumWaitMs:o=1100}){return r?.aborted?Promise.resolve({reason:"aborted",loadingObserved:!1}):new Promise(i=>{const s=Q(e);let h=B(e.ownerDocument),u=!1,g;const l=p=>{if(u)return;u=!0;const m=c.takeRecords(),d=Y(m);h||=d||B(e.ownerDocument),c.disconnect(),g!==void 0&&t.clearTimeout(g),t.clearTimeout(f),t.removeEventListener("scroll",x),r?.removeEventListener("abort",b),i({reason:p==="timeout"&&d?"activity":p,loadingObserved:h})},w=(p,m)=>{g!==void 0&&t.clearTimeout(g),g=t.setTimeout(()=>l(p),m)},A=p=>{const m=Y(p);if(h||=m||B(e.ownerDocument),m){w("activity",n);return}Q(e)!==s&&w("activity",n)},x=()=>w("activity",a),b=()=>l("aborted"),c=new t.MutationObserver(A);c.observe(e,{attributes:!0,attributeFilter:["aria-busy","aria-hidden","data-testid","hidden","href","style"],childList:!0,subtree:!0}),t.addEventListener("scroll",x,{passive:!0});const f=t.setTimeout(()=>l("timeout"),o);r?.addEventListener("abort",b,{once:!0})})}const Ee=`
  :host {
    all: initial;
    color-scheme: light;
    font-family: Georgia, "Times New Roman", serif;
    font-size: 18px;
    line-height: 1.45;
    position: fixed;
    inset: 0;
    z-index: 2147483647;
  }
  :host([hidden]) { display: none; }
  *, *::before, *::after { box-sizing: border-box; }
  .backdrop {
    align-items: center;
    background: rgb(15 17 13 / 72%);
    display: flex;
    inset: 0;
    justify-content: center;
    padding: 24px;
    position: absolute;
  }
  .dialog {
    background: #fffef6;
    border: 2px solid #11120f;
    border-radius: 18px;
    box-shadow: 8px 8px 0 #11120f;
    color: #11120f;
    max-height: min(760px, calc(100vh - 48px));
    max-width: 620px;
    overflow: auto;
    padding: clamp(22px, 5vw, 38px);
    width: 100%;
  }
  .heading { align-items: start; display: flex; gap: 20px; justify-content: space-between; }
  h2 { font-size: clamp(1.6rem, 6vw, 2.35rem); line-height: 1.05; margin: 0; }
  .bookmark { border-left: 5px solid #caff4a; font-family: ui-monospace, monospace; margin: 18px 0 24px; padding-left: 14px; }
  .status { border: 2px solid #45483f; border-radius: 9px; margin: 0 0 18px; padding: 12px 14px; }
  .status[data-state="success"] { border-color: #16733d; }
  .status[data-state="error"] { border-color: #a52222; }
  label { display: block; font-weight: 700; margin-top: 18px; }
  input, textarea {
    background: white;
    border: 2px solid #45483f;
    border-radius: 9px;
    color: #11120f;
    display: block;
    font: inherit;
    margin-top: 7px;
    min-height: 44px;
    padding: 10px 12px;
    width: 100%;
  }
  textarea { min-height: 132px; resize: vertical; }
  button {
    background: #11120f;
    border: 2px solid #11120f;
    border-radius: 9px;
    color: white;
    cursor: pointer;
    font: 700 1rem/1 Georgia, serif;
    min-height: 44px;
    padding: 10px 18px;
  }
  .close { background: transparent; color: #11120f; flex: 0 0 auto; }
  .save { margin-top: 24px; width: 100%; }
  :focus-visible { outline: 4px solid #1769e0; outline-offset: 3px; }
  @media (prefers-reduced-motion: reduce) {
    *, *::before, *::after { scroll-behavior: auto !important; }
  }
`;function Z(e,t,r,n,a){const o=e.createElement("label");o.htmlFor=r,o.textContent=n;const i=e.createElement("input");return i.id=r,i.value=a,i.autocomplete="off",t.append(o,i),i}function Se(e){const{document:t}=e,r=t.createElement("bookmark-x-note-modal");r.hidden=!0,r.tabIndex=-1;const n=r.attachShadow({mode:"open"}),a=t.createElement("style");a.textContent=Ee;const o=t.createElement("div");o.className="backdrop";const i=t.createElement("section");i.className="dialog",i.setAttribute("role","dialog"),i.setAttribute("aria-modal","true"),i.setAttribute("aria-labelledby","bookmark-x-modal-title");const s=t.createElement("div");s.className="heading";const h=t.createElement("h2");h.id="bookmark-x-modal-title",h.textContent=e.title;const u=t.createElement("button");u.className="close",u.type="button",u.textContent=e.labels.close,s.append(h,u);const g=t.createElement("p");g.className="bookmark",g.textContent=e.bookmarkTitle;const l=t.createElement("p");l.className="status",l.setAttribute("role","status"),l.setAttribute("aria-live","polite"),l.setAttribute("aria-atomic","true"),l.dataset.state=e.labels.pending?"pending":"ready",l.textContent=e.labels.pending??"",l.hidden=l.textContent.length===0;const w=t.createElement("form"),A=Z(t,w,"bookmark-x-modal-tags",e.labels.tags,e.values?.tags??""),x=Z(t,w,"bookmark-x-modal-folder",e.labels.folder,e.values?.folder??""),b=t.createElement("label");b.htmlFor="bookmark-x-modal-description",b.textContent=e.labels.description;const c=t.createElement("textarea");c.id="bookmark-x-modal-description",c.maxLength=2e4,c.value=e.values?.description??"";const f=t.createElement("button");f.className="save",f.type="submit",f.textContent=e.labels.save,w.append(b,c,f),w.hidden=e.labels.pending!==void 0,i.append(s,g,l,w),o.append(i),n.append(a,o),t.body.append(r);let p=null;const m=()=>{r.hidden||(r.hidden=!0,e.onClose?.(),p?.focus())};return u.addEventListener("click",m),o.addEventListener("click",d=>{d.target===o&&m()}),r.addEventListener("keydown",d=>{if(d.key==="Escape"){d.preventDefault(),m();return}if(d.key!=="Tab")return;const k=[u,A,x,c,f],v=n.activeElement;d.shiftKey&&v===k[0]?(d.preventDefault(),k.at(-1)?.focus()):!d.shiftKey&&v===k.at(-1)&&(d.preventDefault(),k[0]?.focus())}),w.addEventListener("submit",d=>{d.preventDefault(),Promise.resolve(e.onSave?.({description:c.value,folder:x.value,tags:A.value})).catch(()=>{})}),{host:r,open(){const d=t.activeElement;p=d instanceof HTMLElement?d:null,r.hidden=!1,u.focus()},close:m,setValues(d){d.tags!==void 0&&(A.value=d.tags),d.folder!==void 0&&(x.value=d.folder),d.description!==void 0&&(c.value=d.description)},setState(d,k){l.dataset.state=d,l.textContent=k,l.hidden=k.length===0,w.hidden=d!=="ready"},destroy(){r.remove()}}}const Te=2e4,Ie=50,J=50,Ce=100,ee=32;function U(e){return e.trim().normalize("NFKC")}function M(e){return U(e).toLocaleLowerCase("en-US")}function _e(e){return Array.from(e).some(t=>{const r=t.codePointAt(0)??0;return r<=31||r===127})}function te(e,t){const r=U(e),n=t==="tag"?Ie:Ce;if(!r||r.length>n||_e(r))throw new Error(`Invalid ${t} name.`);return r}function Me(e){if(e.description.length>Te)throw new Error("The note must contain at most 20,000 characters.");const t=[...new Map(e.tags.split(",").filter(a=>U(a).length>0).map(a=>{const o=te(a,"tag");return[M(o),o]})).values()];if(t.length>J)throw new Error(`A bookmark can have at most ${J} tags.`);const r=e.folder.split("/").filter(a=>U(a).length>0);if(r.length>ee)throw new Error(`A folder path can have at most ${ee} levels.`);const n=r.map(a=>te(a,"folder"));return{note:e.description,tags:t,folderPath:n}}function z(e){if(e?.aborted)throw new DOMException("The operation was aborted.","AbortError")}async function I(e,t,r){z(r);const n=await e(t);if(z(r),!n.ok)throw new Error(n.error.message||n.error.code);return n.data}function re(e){return typeof e=="object"&&e!==null&&Array.isArray(e.tags)}function ae(e){return typeof e=="object"&&e!==null&&Array.isArray(e.folders)}function Le(e,t){if(!e)return"";const r=new Map(t.map(i=>[i.id,i])),n=[],a=new Set;let o=r.get(e);for(;o&&!a.has(o.id);)a.add(o.id),n.unshift(o.name),o=o.parentId?r.get(o.parentId):void 0;return n.join(" / ")}async function Oe(e){const[t,r]=await Promise.all([I(e.send,{type:"LIST_TAGS"},e.signal),I(e.send,{type:"LIST_FOLDERS"},e.signal)]);if(!re(t)||!ae(r))throw new Error("Invalid metadata response.");const n=new Map(t.tags.map(a=>[a.id,a]));return{description:e.bookmark.note,folder:Le(e.bookmark.folderId,r.folders),tags:e.bookmark.tagIds.map(a=>n.get(a)?.name).filter(a=>typeof a=="string").join(", ")}}async function Re(e,t){const r=await I(e.send,{type:"LIST_TAGS"},e.signal);if(!re(r))throw new Error("Invalid tag response.");const n=new Map(r.tags.map(s=>[s.id,s])),a=e.bookmark.tagIds.map(s=>n.get(s)).filter(s=>s!==void 0),o=new Map(t.map(s=>[M(s),s]));for(const s of a)o.has(M(s.normalizedName||s.name))||await I(e.send,{type:"REMOVE_BOOKMARK_TAG",payload:{id:e.bookmark.id,tagId:s.id}},e.signal);const i=new Set(a.map(s=>M(s.normalizedName||s.name)));for(const[s,h]of o)i.has(s)||await I(e.send,{type:"ADD_BOOKMARK_TAG",payload:{id:e.bookmark.id,name:h}},e.signal)}async function Be(e,t){if(t.length===0)return null;const r=await I(e.send,{type:"LIST_FOLDERS"},e.signal);if(!ae(r))throw new Error("Invalid folder response.");const n=[...r.folders];let a=null;for(const o of t){let i=n.find(s=>s.parentId===a&&M(s.name)===M(o));if(!i){const s=await I(e.send,{type:"CREATE_FOLDER",payload:{name:o,parentId:a}},e.signal);if(!s?.folder)throw new Error("Invalid folder response.");const h=s.folder;i=h,n.push(h)}a=i.id}return a}async function Ne(e){const t=Me(e.values);z(e.signal),await I(e.send,{type:"SAVE_BOOKMARK_NOTE",payload:{id:e.bookmark.id,note:t.note}},e.signal),await Re(e,t.tags);const r=await Be(e,t.folderPath);await I(e.send,{type:"ASSIGN_BOOKMARK_FOLDER",payload:{bookmarkId:e.bookmark.id,folderId:r}},e.signal)}const Fe=900,De=6e3;function Pe(e){if(typeof e!="object"||e===null)return!1;const t=e;return typeof t.id=="string"&&typeof t.text=="string"&&typeof t.url=="string"&&typeof t.author=="object"&&t.author!==null&&typeof t.author.id=="string"&&typeof t.author.username=="string"&&typeof t.author.name=="string"&&typeof t.postCreatedAt=="string"&&me(t.media,t.url)&&typeof t.note=="string"&&(t.folderId===null||typeof t.folderId=="string")&&Array.isArray(t.tagIds)&&t.tagIds.every(r=>typeof r=="string")&&typeof t.firstSavedAt=="string"&&typeof t.lastSeenAt=="string"&&(t.archivedAt===null||typeof t.archivedAt=="string")&&typeof t.metadataUpdatedAt=="string"&&(t.status==="current"||t.status==="archived")}function Ke(e){return e.dataset.testid==="bookmark"?"save":e.dataset.testid==="removeBookmark"?"remove":null}function Ue(e,t){const r=e.querySelector('button[data-testid="bookmark"], button[data-testid="removeBookmark"]');return r?t==="save"?r.dataset.testid==="removeBookmark"||r.getAttribute("aria-pressed")==="true":r.dataset.testid==="bookmark"||r.getAttribute("aria-pressed")==="false":!1}function qe(e){return new Promise(t=>{let r=!1,n=null;const a=u=>{r||(r=!0,i.disconnect(),n!==null&&clearTimeout(n),clearTimeout(s),e.signal.removeEventListener("abort",h),t(u))},o=()=>{Ue(e.article,e.action)?n??=setTimeout(()=>a(!0),e.stableForMs):n!==null&&(clearTimeout(n),n=null)},i=new MutationObserver(o),s=setTimeout(()=>a(!1),e.timeoutMs),h=()=>a(!1);e.signal.addEventListener("abort",h,{once:!0}),i.observe(e.document.documentElement,{attributes:!0,attributeFilter:["aria-pressed","data-testid"],childList:!0,subtree:!0}),o()})}function ze(){return crypto.randomUUID()}function Ge(e){return{close:e("bookmarkPromptClose"),description:e("bookmarkPromptNote"),folder:e("bookmarkPromptFolder"),save:e("bookmarkPromptSave"),tags:e("bookmarkPromptTags"),pending:e("liveBookmarkPending")}}function He(e){const t=new Map,r=new Map;let n=!1;const a=async(i,s,h)=>{t.get(s.id)?.controller.abort();const g=r.get(s.id);g?.controller.abort(),g?.modal?.destroy(),r.delete(s.id);const l={controller:new AbortController,intentId:ze(),modal:null};t.set(s.id,l);const w={type:"LIVE_BOOKMARK_PENDING",intentId:l.intentId,action:i,bookmark:s};e.onPending?.(h,s.id);const A=e.send(w),x=qe({document:e.document,article:h,action:i,signal:l.controller.signal,stableForMs:e.stableForMs??Fe,timeoutMs:e.timeoutMs??De}),b=await A.catch(()=>null),c=b?.ok?b.data:null;if(!n&&!l.controller.signal.aborted&&c?.prompt&&c.surface==="modal"){let m=null,d=null,k=null,v=null;const L=y=>(k=y,v??=Promise.resolve().then(async()=>{for(;k;){const E=k;if(k=null,!d)throw new Error("Bookmark metadata is not ready.");await Ne({bookmark:d,values:E,send:e.send,signal:l.controller.signal})}}).finally(()=>{v=null}),v);m=Se({document:e.document,title:e.translate("bookmarkPromptTitle"),bookmarkTitle:s.text||s.url,labels:Ge(e.translate),onSave:async y=>{l.modal?.setState("pending",e.translate("liveBookmarkPending"));try{await L(y),e.onChanged?.(s.id),l.modal?.setState("ready",e.translate("liveBookmarkSaved"))}catch{l.controller.signal.aborted||l.modal?.setState("ready",e.translate("liveBookmarkFailed"))}},onClose:()=>{m&&r.get(s.id)===l&&(r.delete(s.id),l.controller.abort(),m.destroy())}}),l.modal=m,r.set(s.id,l),m.open(),l.prepareMetadata=async y=>{d=y;const E=await Oe({bookmark:y,send:e.send,signal:l.controller.signal});l.controller.signal.aborted||m?.setValues(E)}}const f=await x;if(n||t.get(s.id)!==l)return;if(!f){await e.send({type:"LIVE_BOOKMARK_CANCELLED",intentId:l.intentId}).catch(()=>{}),l.modal?.setState("error",e.translate("liveBookmarkFailed")),e.onChanged?.(s.id),t.delete(s.id);return}const p=await e.send({type:"LIVE_BOOKMARK_CONFIRMED",intentId:l.intentId,action:i,bookmark:s}).catch(()=>null);if(p?.ok)if(i==="save"){const m=p.data?.bookmark;try{if(l.modal){if(!Pe(m))throw new Error("Invalid bookmark response.");await l.prepareMetadata?.(m)}l.controller.signal.aborted||l.modal?.setState("ready",e.translate("liveBookmarkSaved"))}catch{l.controller.signal.aborted||l.modal?.setState("ready",e.translate("liveBookmarkFailed"))}}else l.modal?.setState("success",e.translate("liveBookmarkArchived"));else l.modal?.setState("error",e.translate("liveBookmarkFailed"));e.onChanged?.(s.id),t.delete(s.id)},o=i=>{if(n||!(i.target instanceof Element))return;const s=i.target.closest("button");if(!s)return;const h=Ke(s);if(!h)return;const u=s.closest('article[data-testid="tweet"]');if(!u)return;const g=$(u)[0];g&&a(h,g,u)};return e.document.addEventListener("click",o,!0),{stop(){if(!n){n=!0,e.document.removeEventListener("click",o,!0);for(const i of t.values())i.controller.abort();for(const i of new Set(r.values()))i.controller.abort(),i.modal?.destroy();t.clear(),r.clear()}}}}function ne(e,t){return(!t.note||e.note.trim().length>0)&&(!t.tags||e.tagIds.length>0)&&(!t.breadcrumb||e.folderId!==null)}const N='article[data-testid="tweet"]',oe="bookmark-x-metadata",Ve=/^\/[A-Za-z0-9_]+\/status\/(\d+)$/,je={appearance:{largeText:!0,highContrast:!0,reduceMotion:!1},behavior:{surface:"modal",promptAfterBookmark:!0,metadata:{summary:!0,breadcrumb:!0,tags:!0,note:!0,categoryIndicator:!0}},export:{includeLink:!0,includeText:!0,includeAuthor:!0,includeDate:!0,includeImages:!0,includeVideos:!0,includeNote:!0,includeTags:!0,includeFolder:!0,includeFirstSavedAt:!0,includeLastSeenAt:!0},search:{filterAsYouType:!0},data:{keepArchived:!0}},$e=String.raw`
  :host {
    --bx-accent: #a8d500;
    --bx-border: #53610d;
    --bx-ink: #152000;
    --bx-muted: #384511;
    --bx-surface: #f8ffe2;
    color: var(--bx-ink);
    display: block;
    font-family: ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
    font-size: 16px;
    line-height: 1.5;
    min-width: 0;
  }

  :host([data-large-text="true"]) { font-size: 18px; }

  .card {
    background: var(--bx-surface);
    border: 1px solid var(--bx-border);
    border-left: 4px solid var(--bx-accent);
    border-radius: 0 10px 10px 0;
    box-sizing: border-box;
    display: grid;
    gap: 8px;
    margin: 8px 12px 4px;
    max-width: calc(100% - 24px);
    padding: 10px 12px;
  }

  .status-row, .tags, .breadcrumb {
    align-items: center;
    display: flex;
    flex-wrap: wrap;
    gap: 6px;
    min-width: 0;
  }

  .status, .category, .tag {
    border: 1px solid currentColor;
    border-radius: 999px;
    font-size: 0.875em;
    font-weight: 750;
    letter-spacing: 0.01em;
    padding: 2px 8px;
    max-width: 100%;
    overflow-wrap: anywhere;
    white-space: normal;
  }

  .status::before { content: "✓ "; }
  .status[data-state="pending"]::before { content: "… "; }
  .status[data-state="archived"]::before { content: "↺ "; }
  .category::before { content: "! "; }
  .category { background: #fff3c4; color: #5b4100; }
  .tag { background: #e6f5b2; color: #253300; font-weight: 650; }

  .breadcrumb { color: var(--bx-muted); font-weight: 650; }
  .crumb + .crumb::before { content: "›"; margin-inline-end: 6px; }

  .note {
    color: var(--bx-ink);
    display: -webkit-box;
    margin: 0;
    overflow: hidden;
    overflow-wrap: anywhere;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 2;
  }

  .visually-hidden {
    border: 0;
    clip: rect(0 0 0 0);
    height: 1px;
    margin: -1px;
    overflow: hidden;
    padding: 0;
    position: absolute;
    white-space: nowrap;
    width: 1px;
  }

  :host([data-high-contrast="true"]) {
    --bx-accent: #b9f300;
    --bx-border: #111;
    --bx-ink: #080a00;
    --bx-muted: #252b13;
    --bx-surface: #fbffe9;
  }

  @media (prefers-color-scheme: dark) {
    :host {
      --bx-accent: #c8ff3d;
      --bx-border: #a7bd68;
      --bx-ink: #f4ffd6;
      --bx-muted: #d5e5a9;
      --bx-surface: #172000;
    }
    .category { background: #3a2b00; color: #ffe28a; }
    .tag { background: #2e3b0d; color: #efffc0; }
  }

  @media (forced-colors: active) {
    .card, .status, .category, .tag { border-color: CanvasText; }
    .card { background: Canvas; color: CanvasText; }
  }

  @media (prefers-reduced-motion: reduce) {
    *, *::before, *::after {
      animation-duration: 0.01ms !important;
      animation-iteration-count: 1 !important;
      transition-duration: 0.01ms !important;
    }
  }

  :host([data-reduce-motion="true"]) *,
  :host([data-reduce-motion="true"]) *::before,
  :host([data-reduce-motion="true"]) *::after {
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.01ms !important;
  }
`;function F(e,t,r,n,a){const o=e.createElement(r);return o.className=n,o.textContent=a,t.append(o),o}function Xe(e){return Object.values(e.behavior.metadata).some(Boolean)}function se(e){const{document:t,host:r,item:n,settings:a,translate:o}=e,i=r.shadowRoot??r.attachShadow({mode:"open"}),s=t.createElement("style");s.textContent=$e;const h=t.createElement("section");if(h.className="card",r.dataset.bookmarkId=n.bookmark.id,r.dataset.largeText=String(a.appearance.largeText),r.dataset.highContrast=String(a.appearance.highContrast),r.dataset.reduceMotion=String(a.appearance.reduceMotion),r.dataset.state=e.pending?"pending":n.bookmark.status==="archived"?"archived":ne(n.bookmark,a.behavior.metadata)?"mapped":"uncategorized",r.setAttribute("aria-label",o("bookmarkMetadataLabel")),r.setAttribute("role","group"),a.behavior.metadata.summary||!e.pending&&a.behavior.metadata.categoryIndicator){const u=t.createElement("div");if(u.className="status-row",a.behavior.metadata.summary){const g=F(t,u,"span","status",e.pending?o("liveBookmarkPending"):n.bookmark.status==="archived"?o("bookmarkMetadataArchived"):o("bookmarkMetadataMapped"));g.dataset.state=e.pending?"pending":n.bookmark.status==="archived"?"archived":"mapped"}!e.pending&&a.behavior.metadata.categoryIndicator&&!ne(n.bookmark,a.behavior.metadata)&&F(t,u,"span","category",o("bookmarkNeedsCategory")),h.append(u)}if(!e.pending&&a.behavior.metadata.breadcrumb){const u=t.createElement("div");u.className="breadcrumb",u.setAttribute("aria-label",o("bookmarkPromptFolder"));const g=n.breadcrumb.length?n.breadcrumb:[o("uncategorizedFolder")];for(const l of g)F(t,u,"span","crumb",l);h.append(u)}if(!e.pending&&a.behavior.metadata.tags&&n.tags.length>0){const u=t.createElement("div");u.className="tags",u.setAttribute("aria-label",o("bookmarkPromptTags"));for(const g of n.tags)F(t,u,"span","tag",g.name);h.append(u)}if(!e.pending&&a.behavior.metadata.note&&n.bookmark.note.trim().length>0){const u=t.createElement("p");u.className="note",F(t,u,"span","visually-hidden",`${o("bookmarkPromptNote")}: `),u.append(t.createTextNode(n.bookmark.note)),h.append(u)}i.replaceChildren(s,h)}function ie(e){for(const t of Array.from(e.querySelectorAll('a[href*="/status/"]')))try{const r=new URL(t.href,location.href).pathname.match(Ve);if(r?.[1])return r[1]}catch{}return null}function We(e){const t=e.querySelector('button[data-testid="bookmark"], button[data-testid="removeBookmark"]');return t?.closest('[role="group"]')??t}function Ye(e,t){const r=e.defaultView;return typeof r?.requestAnimationFrame=="function"?r.requestAnimationFrame(t):(queueMicrotask(()=>t(performance.now())),0)}function Qe(e){const t=new Map,r=new Map,n=new Set;let a=!1,o=null,i=0,s=null,h=c=>c;const u=c=>{t.get(c)?.host.remove(),t.delete(c),r.delete(c)},g=(c,f)=>{const p=We(c);if(!p)return null;const m=t.get(c);if(m?.bookmarkId===f&&m.host.isConnected)return m.host;u(c);const d=e.document.createElement(oe);return p.insertAdjacentElement("afterend",d),t.set(c,{bookmarkId:f,host:d}),d},l=async()=>{if(o=null,a)return;const c=++i;for(const m of[...t.keys()])m.isConnected||u(m);const f=[...n].filter(m=>m.isConnected);n.clear();const p=new Map;for(const m of f){const d=ie(m);if(!d){u(m);continue}const k=p.get(d)??[];k.push(m),p.set(d,k)}if(p.size!==0)try{const m=[...p.keys()];let d=null;const k=[];for(let y=0;y<m.length;y+=100){const E=await e.lookup(m.slice(y,y+100));if(a||c!==i)return;d=E,k.push(...E.items)}if(!d)return;d={...d,items:k};const v=y=>d.messages[y]??y;if(a||c!==i)return;s=d,h=v;const L=new Map(d.items.map(y=>[y.bookmark.id,y]));for(const[y,E]of p){const S=L.get(y);for(const T of E){if(!S){if(r.get(T)===y)continue;u(T);continue}if(!Xe(d.settings)){u(T);continue}const K=g(T,y);K&&se({document:e.document,host:K,item:S,settings:d.settings,translate:v,pending:r.get(T)===y})}}}catch{}},w=()=>{a||o!==null||(o=(e.scheduleFrame??(c=>Ye(e.document,c)))(()=>{l()}))},A=c=>{n.add(c),w()},x=c=>{if(!(c instanceof Element))return;c.matches(N)&&A(c);for(const p of Array.from(c.querySelectorAll(N)))A(p);const f=c.closest(N);f&&A(f)},b=new MutationObserver(c=>{for(const f of c)if(!(f.type==="childList"&&[...Array.from(f.addedNodes),...Array.from(f.removedNodes)].length>0&&[...Array.from(f.addedNodes),...Array.from(f.removedNodes)].every(p=>p instanceof Element&&p.localName===oe))){x(f.target);for(const p of Array.from(f.addedNodes))x(p);for(const p of Array.from(f.removedNodes))x(p)}});b.observe(e.document.documentElement,{attributes:!0,attributeFilter:["href","data-testid"],childList:!0,subtree:!0});for(const c of Array.from(e.document.querySelectorAll(N)))A(c);return{refresh(c){for(const[f,p]of r)(!c||p===c)&&r.delete(f);for(const f of Array.from(e.document.querySelectorAll(N)))(!c||ie(f)===c)&&A(f)},setPending(c,f){const p=g(c,f);if(!p)return;const m=s?.settings??je;if(!m.behavior.metadata.summary){u(c);return}r.set(c,f);const k=s?.items.find(v=>v.bookmark.id===f)??{bookmark:{id:f,text:"",url:"",author:{id:"",username:"",name:""},postCreatedAt:"",media:{images:[],videos:[]},note:"",folderId:null,tagIds:[],firstSavedAt:"",lastSeenAt:"",archivedAt:null,metadataUpdatedAt:"",status:"current"},breadcrumb:[],tags:[]};se({document:e.document,host:p,item:k,settings:m,translate:h,pending:!0})},stop(){if(!a){a=!0,i+=1,b.disconnect(),o!==null&&o!==0&&(e.cancelFrame?e.cancelFrame(o):e.document.defaultView?.cancelAnimationFrame(o));for(const c of[...t.keys()])u(c);n.clear(),r.clear()}}}}let C;function ce(e){return chrome.runtime.sendMessage(e)}class G extends Error{constructor(t){super(`Capture event was rejected: ${t}`),this.code=t}code}async function D(e){const t=await ce(e);if(typeof t!="object"||t===null)throw new G("invalid_response");const r=t;if(r.ok===!0)return;const n=r.error,a=typeof n=="object"&&n!==null&&typeof n.code=="string"?String(n.code):"rejected";throw new G(a)}async function Ze(e,t,r){try{const n=await ke({scan:()=>$(document),checkpointIds:r,isLoading:()=>B(document),isPageValid:()=>{const a=new URL(window.location.href);return(a.hostname==="x.com"||a.hostname==="www.x.com")&&(a.pathname==="/i/bookmarks"||a.pathname.startsWith("/i/bookmarks/"))},isAtEnd:()=>{const a=document.scrollingElement??document.documentElement;return ye({scrollTop:Math.max(window.scrollY,a.scrollTop),viewportHeight:window.innerHeight,documentHeight:a.scrollHeight})},scroll:()=>{ve(document,{viewportHeight:window.innerHeight,scrollBy:()=>{window.scrollBy({top:Math.max(Math.round(window.innerHeight*.9),640),behavior:"auto"})}})},waitForContent:a=>xe({root:document.querySelector("main")??document.body,view:window,signal:a}),signal:t.signal,onBatch:async a=>{await D({type:"SCRAPE_BATCH",runId:e,bookmarks:a})},onProgress:async({fetched:a})=>{await D({type:"SCRAPE_PROGRESS",runId:e,fetched:a})}});if(n.status==="incomplete"){await D({type:"SCRAPE_FAILED",runId:e,errorCode:n.errorCode??"scrape_incomplete"});return}if(n.status==="completed"){await D({type:"SCRAPE_COMPLETE",runId:e,status:"completed",fetched:n.fetched,completionReason:n.completionReason??"stable_end"});return}await D({type:"SCRAPE_COMPLETE",runId:e,status:"cancelled",fetched:n.fetched})}catch(n){if(n instanceof G&&n.code==="stale_capture")return;try{await ce({type:"SCRAPE_FAILED",runId:e,errorCode:t.signal.aborted?"capture_cancelled":"scrape_failed"})}catch{}}finally{C?.runId===e&&(C=void 0)}}function Je(e){if(typeof e!="object"||e===null)return!1;const t=e;return t.type==="REFRESH_BOOKMARK_METADATA"?t.bookmarkIds===void 0||Array.isArray(t.bookmarkIds)&&t.bookmarkIds.length<=100&&t.bookmarkIds.every(r=>typeof r=="string"&&/^\d+$/.test(r)):typeof t.runId!="string"?!1:t.type==="CANCEL_SCRAPE"?!0:t.type!=="START_SCRAPE"||t.mode!=="quick"&&t.mode!=="full"||!Array.isArray(t.checkpointIds)||t.checkpointIds.length>10?!1:t.checkpointIds.every(r=>typeof r=="string"&&/^\d+$/.test(r))&&new Set(t.checkpointIds).size===t.checkpointIds.length}const P=Qe({document,async lookup(e){const t=await chrome.runtime.sendMessage({type:"GET_BOOKMARK_DECORATIONS",payload:{ids:e}});if(!t.ok)throw new Error(t.error.message);return t.data}});chrome.runtime.onMessage.addListener((e,t,r)=>{if(t.id!==chrome.runtime.id||!Je(e))return r({accepted:!1}),!1;if(e.type==="REFRESH_BOOKMARK_METADATA"){if(e.bookmarkIds)for(const a of e.bookmarkIds)P.refresh(a);else P.refresh();return r({accepted:!0}),!1}if(e.type==="CANCEL_SCRAPE")return C?.runId===e.runId&&C.controller.abort(),r({accepted:!0}),!1;if(C)return r({accepted:!1,reason:"capture_in_progress"}),!1;const n=new AbortController;return C={runId:e.runId,controller:n},r({accepted:!0}),Ze(e.runId,n,e.checkpointIds),!1});const et=He({document,send:e=>chrome.runtime.sendMessage(e),translate:e=>chrome.i18n.getMessage(e)||e,onPending:(e,t)=>P.setPending(e,t),onChanged:e=>P.refresh(e)});window.addEventListener("pagehide",()=>{C?.controller.abort(),et.stop(),P.stop()},{once:!0})})();
