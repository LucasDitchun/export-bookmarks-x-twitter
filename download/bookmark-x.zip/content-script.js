(function(){"use strict";function H(e){return typeof e=="object"&&e!==null&&!Array.isArray(e)}function R(e){if(typeof e!="string"||e.length===0||e.length>2048)return null;try{const t=new URL(e);return t.protocol!=="https:"||t.hostname!=="pbs.twimg.com"||t.username!==""||t.password!==""||t.port!==""?null:(t.hash="",t.toString())}catch{return null}}function V(e){const t=new URL(e);return`${t.origin}${t.pathname}`}function j(e){return R(e.currentSrc)??R(e.getAttribute("src")||e.src)}function le(e){const t=new Set(e.filter(({thumbnailUrl:a})=>a!==null).map(({postUrl:a})=>a)),r=[],n=new Set;for(const a of e){if(a.thumbnailUrl===null&&t.has(a.postUrl))continue;const o=`${a.postUrl}\0${a.thumbnailUrl===null?"":V(a.thumbnailUrl)}`;if(!n.has(o)&&(n.add(o),r.push(a),r.length===4))break}return r}function ue(e,t){const r=[],n=new Set;for(const s of Array.from(e.querySelectorAll('[data-testid="tweetPhoto"] img'))){const i=j(s);if(i===null)continue;const u=V(i);if(!n.has(u)&&(n.add(u),r.push(i),r.length===16))break}const o=Array.from(e.querySelectorAll("video")).map(s=>({thumbnailUrl:R(s.poster||s.getAttribute("poster")),postUrl:t}));for(const s of Array.from(e.querySelectorAll('[data-testid="videoPlayer"], [data-testid="videoComponent"]'))){if(s.querySelector("video"))continue;const i=s.querySelector("img");o.push({thumbnailUrl:i?j(i):null,postUrl:t})}return{images:r,videos:le(o)}}function me(e,t){return!H(e)||!Array.isArray(e.images)||!Array.isArray(e.videos)||e.images.length>16||e.videos.length>4||e.images.some(r=>typeof r!="string"||R(r)!==r)?!1:e.videos.every(r=>H(r)&&r.postUrl===t&&(r.thumbnailUrl===null||typeof r.thumbnailUrl=="string"&&R(r.thumbnailUrl)===r.thumbnailUrl))}const fe=/^\/([A-Za-z0-9_]+)\/status\/(\d+)(?:\/|$)/;function q(e){return(e?.textContent??"").replace(/\s+/g," ").trim()}function pe(e){const t=e.querySelector("time[datetime]")?.closest("a[href]"),r=Array.from(e.querySelectorAll("a[href]"));if(t){const n=r.indexOf(t);n>=0&&r.splice(n,1),r.unshift(t)}for(const n of r){let a;try{a=new URL(n.getAttribute("href")??"","https://x.com")}catch{continue}if(a.hostname!=="x.com"&&a.hostname!=="www.x.com")continue;const o=fe.exec(a.pathname);if(!o)continue;const s=o[1],i=o[2];if(!(!s||!i))return{id:i,username:s,url:`https://x.com/${s}/status/${i}`}}return null}function he(e,t){const r=e.querySelector('[data-testid="User-Name"]'),n=Array.from(r?.querySelectorAll("a[href]")??[]).find(s=>s.getAttribute("href")?.toLocaleLowerCase()===`/${t.toLocaleLowerCase()}`),a=q(n);return a&&!a.startsWith("@")?a:Array.from(r?.querySelectorAll("span")??[]).map(q).filter(s=>s.length>0&&!s.startsWith("@")&&s!=="·"&&s.toLocaleLowerCase()!==t.toLocaleLowerCase())[0]??t}function $(e=document){const t=new Map,r=Array.from(e.querySelectorAll('article[data-testid="tweet"]')),n=e instanceof Element&&e.matches('article[data-testid="tweet"]')?[e,...r]:r;for(const a of n){const o=pe(a);if(!o||t.has(o.id))continue;const s=a.querySelector("time[datetime]");t.set(o.id,{id:o.id,text:q(a.querySelector('[data-testid="tweetText"]')),url:o.url,author:{id:o.username.toLocaleLowerCase(),username:o.username,name:he(a,o.username)},postCreatedAt:s?.dateTime??"",media:ue(a,o.url)})}return[...t.values()]}const ge=['main [role="progressbar"]','main [data-testid="progressBar"]','main [aria-busy="true"]','main[aria-busy="true"]'].join(",");function be(e){if(e.closest('[hidden], [aria-hidden="true"]'))return!0;const t=e.ownerDocument.defaultView;if(!t)return!1;const r=t.getComputedStyle(e);return r.display==="none"||r.visibility==="hidden"}function B(e){return Array.from(e.querySelectorAll(ge)).some(t=>!be(t))}function ye({scrollTop:e,viewportHeight:t,documentHeight:r},n=8){return e+t>=r-n}async function ke({scan:e,checkpointIds:t=[],isLoading:r=()=>!1,isAtEnd:n=()=>!0,isPageValid:a=()=>!0,scroll:o,waitForContent:s,onBatch:i,onProgress:u,signal:l,idlePassLimit:g=4,maximumLoadingPasses:m=180,batchSize:k=100}){if(!Number.isSafeInteger(k)||k<1||k>100)throw new RangeError("Scrape batch size must be between 1 and 100.");if(!Number.isSafeInteger(g)||g<1)throw new RangeError("Idle pass limit must be a positive integer.");if(!Number.isSafeInteger(m)||m<1)throw new RangeError("Loading pass limit must be a positive integer.");const v=new Set,E=new Set(t);let b=0,c=0,p=0,h=0,f=-1;for(;!l?.aborted;){if(!a())return{status:"incomplete",fetched:b,errorCode:"capture_navigation_changed"};const d=[];let y=!1;for(const O of e()){if(v.has(O.id))continue;const{id:_}=O;if(v.add(_),d.push(O),c=E.has(_)?c+1:0,E.size>0&&c>=3){y=!0;break}}const A=r(),I=n(),w=d.length===0&&!A&&I;if(d.length>0){p=0;const O=b;for(let _=0;_<d.length&&!l?.aborted;_+=k){const de=d.slice(_,_+k);await i(de),b+=de.length}b>O&&(h=0)}else(A||!I)&&(p=0);f!==b&&(await u({fetched:b}),f=b);const S=s(l);!A&&!w&&!y&&o();const x=await S;if(!a())return{status:"incomplete",fetched:b,errorCode:"capture_navigation_changed"};const C=r(),K=n();if((A||x?.loadingObserved||C)&&(h+=1,h>=m))return{status:"incomplete",fetched:b,errorCode:"capture_loading_timeout"};if(y&&!l?.aborted){if(!A&&x?.reason==="timeout"&&!x?.loadingObserved&&!C)return{status:"completed",fetched:b,completionReason:"checkpoint_stop"};c=0}if(w&&!l?.aborted&&x?.reason!=="activity"&&!x?.loadingObserved&&!C&&K){if(p+=1,p>=g)return{status:"completed",fetched:b,...E.size>0?{completionReason:"stable_end"}:{}}}else(x?.loadingObserved||x?.reason==="activity"||C||!K)&&(p=0)}return{status:"cancelled",fetched:b}}const X='article[data-testid="tweet"]';function we(e){return Array.from(e.querySelectorAll(X)).filter(t=>!t.parentElement?.closest(X))}function Ae(e,{viewportHeight:t,scrollBy:r}){const n=we(e).at(-1),a=n&&n.getBoundingClientRect().top>t*.25;return!n||!a?(r(),"fallback"):(n.scrollIntoView({behavior:"auto",block:"start"}),"anchor")}const ve='article[data-testid="tweet"] a[href*="/status/"]',W='[role="progressbar"], [data-testid="progressBar"], [aria-busy="true"]';function Y(e){return e.some(t=>Array.from(t.addedNodes).some(r=>{if(r.nodeType!==1)return!1;const n=r;return n.matches(W)||n.querySelector(W)!==null}))}function Q(e){const t=Array.from(e.querySelectorAll(ve),r=>r.getAttribute("href")??"");return`${B(e.ownerDocument)?"loading":"idle"}|${t.join("|")}`}function Ee({root:e,view:t,signal:r,settleMs:n=75,scrollSettleMs:a=180,maximumWaitMs:o=1100}){return r?.aborted?Promise.resolve({reason:"aborted",loadingObserved:!1}):new Promise(s=>{const i=Q(e);let u=B(e.ownerDocument),l=!1,g;const m=h=>{if(l)return;l=!0;const f=c.takeRecords(),d=Y(f);u||=d||B(e.ownerDocument),c.disconnect(),g!==void 0&&t.clearTimeout(g),t.clearTimeout(p),t.removeEventListener("scroll",E),r?.removeEventListener("abort",b),s({reason:h==="timeout"&&d?"activity":h,loadingObserved:u})},k=(h,f)=>{g!==void 0&&t.clearTimeout(g),g=t.setTimeout(()=>m(h),f)},v=h=>{const f=Y(h);if(u||=f||B(e.ownerDocument),f){k("activity",n);return}Q(e)!==i&&k("activity",n)},E=()=>k("activity",a),b=()=>m("aborted"),c=new t.MutationObserver(v);c.observe(e,{attributes:!0,attributeFilter:["aria-busy","aria-hidden","data-testid","hidden","href","style"],childList:!0,subtree:!0}),t.addEventListener("scroll",E,{passive:!0});const p=t.setTimeout(()=>m("timeout"),o);r?.addEventListener("abort",b,{once:!0})})}const xe=`
  :host {
    all: initial;
    color-scheme: light;
    font-family: Georgia, "Times New Roman", serif;
    font-size: 18px;
    line-height: 1.45;
    position: fixed;
    inset: 0;
    z-index: 2147483647;
  }
  :host([hidden]) { display: none; }
  *, *::before, *::after { box-sizing: border-box; }
  .backdrop {
    align-items: center;
    background: rgb(15 17 13 / 72%);
    display: flex;
    inset: 0;
    justify-content: center;
    padding: 24px;
    position: absolute;
  }
  .dialog {
    background: #fffef6;
    border: 2px solid #11120f;
    border-radius: 18px;
    box-shadow: 8px 8px 0 #11120f;
    color: #11120f;
    max-height: min(760px, calc(100vh - 48px));
    max-width: 620px;
    overflow: auto;
    padding: clamp(22px, 5vw, 38px);
    width: 100%;
  }
  .heading { align-items: start; display: flex; gap: 20px; justify-content: space-between; }
  h2 { font-size: clamp(1.6rem, 6vw, 2.35rem); line-height: 1.05; margin: 0; }
  .bookmark { border-left: 5px solid #caff4a; font-family: ui-monospace, monospace; margin: 18px 0 24px; padding-left: 14px; }
  .status { border: 2px solid #45483f; border-radius: 9px; margin: 0 0 18px; padding: 12px 14px; }
  .status[data-state="success"] { border-color: #16733d; }
  .status[data-state="error"] { border-color: #a52222; }
  label { display: block; font-weight: 700; margin-top: 18px; }
  input, textarea {
    background: white;
    border: 2px solid #45483f;
    border-radius: 9px;
    color: #11120f;
    display: block;
    font: inherit;
    margin-top: 7px;
    min-height: 44px;
    padding: 10px 12px;
    width: 100%;
  }
  textarea { min-height: 132px; resize: vertical; }
  button {
    background: #11120f;
    border: 2px solid #11120f;
    border-radius: 9px;
    color: white;
    cursor: pointer;
    font: 700 1rem/1 Georgia, serif;
    min-height: 44px;
    padding: 10px 18px;
  }
  .close { background: transparent; color: #11120f; flex: 0 0 auto; }
  .save { margin-top: 24px; width: 100%; }
  :focus-visible { outline: 4px solid #1769e0; outline-offset: 3px; }
  @media (prefers-reduced-motion: reduce) {
    *, *::before, *::after { scroll-behavior: auto !important; }
  }
`;function Z(e,t,r,n,a){const o=e.createElement("label");o.htmlFor=r,o.textContent=n;const s=e.createElement("input");return s.id=r,s.value=a,s.autocomplete="off",t.append(o,s),s}function Se(e){const{document:t}=e,r=t.createElement("bookmark-x-note-modal");r.hidden=!0,r.tabIndex=-1;const n=r.attachShadow({mode:"open"}),a=t.createElement("style");a.textContent=xe;const o=t.createElement("div");o.className="backdrop";const s=t.createElement("section");s.className="dialog",s.setAttribute("role","dialog"),s.setAttribute("aria-modal","true"),s.setAttribute("aria-labelledby","bookmark-x-modal-title");const i=t.createElement("div");i.className="heading";const u=t.createElement("h2");u.id="bookmark-x-modal-title",u.textContent=e.title;const l=t.createElement("button");l.className="close",l.type="button",l.textContent=e.labels.close,i.append(u,l);const g=t.createElement("p");g.className="bookmark",g.textContent=e.bookmarkTitle;const m=t.createElement("p");m.className="status",m.setAttribute("role","status"),m.setAttribute("aria-live","polite"),m.setAttribute("aria-atomic","true"),m.dataset.state=e.labels.pending?"pending":"ready",m.textContent=e.labels.pending??"",m.hidden=m.textContent.length===0;const k=t.createElement("form"),v=Z(t,k,"bookmark-x-modal-tags",e.labels.tags,e.values?.tags??""),E=Z(t,k,"bookmark-x-modal-folder",e.labels.folder,e.values?.folder??""),b=t.createElement("label");b.htmlFor="bookmark-x-modal-description",b.textContent=e.labels.description;const c=t.createElement("textarea");c.id="bookmark-x-modal-description",c.maxLength=2e4,c.value=e.values?.description??"";const p=t.createElement("button");p.className="save",p.type="submit",p.textContent=e.labels.save,k.append(b,c,p),k.hidden=e.labels.pending!==void 0,s.append(i,g,m,k),o.append(s),n.append(a,o),t.body.append(r);let h=null;const f=()=>{r.hidden||(r.hidden=!0,e.onClose?.(),h?.focus())};return l.addEventListener("click",f),o.addEventListener("click",d=>{d.target===o&&f()}),r.addEventListener("keydown",d=>{if(d.key==="Escape"){d.preventDefault(),f();return}if(d.key!=="Tab")return;const y=[l,v,E,c,p],A=n.activeElement;d.shiftKey&&A===y[0]?(d.preventDefault(),y.at(-1)?.focus()):!d.shiftKey&&A===y.at(-1)&&(d.preventDefault(),y[0]?.focus())}),k.addEventListener("submit",d=>{d.preventDefault(),Promise.resolve(e.onSave?.({description:c.value,folder:E.value,tags:v.value})).catch(()=>{})}),{host:r,open(){const d=t.activeElement;h=d instanceof HTMLElement?d:null,r.hidden=!1,l.focus()},close:f,setValues(d){d.tags!==void 0&&(v.value=d.tags),d.folder!==void 0&&(E.value=d.folder),d.description!==void 0&&(c.value=d.description)},setState(d,y){m.dataset.state=d,m.textContent=y,m.hidden=y.length===0,k.hidden=d!=="ready"},destroy(){r.remove()}}}const Te=2e4,Ce=50,J=50,Ie=100,ee=32;function U(e){return e.trim().normalize("NFKC")}function L(e){return U(e).toLocaleLowerCase("en-US")}function Me(e){return Array.from(e).some(t=>{const r=t.codePointAt(0)??0;return r<=31||r===127})}function te(e,t){const r=U(e),n=t==="tag"?Ce:Ie;if(!r||r.length>n||Me(r))throw new Error(`Invalid ${t} name.`);return r}function _e(e){if(e.description.length>Te)throw new Error("The note must contain at most 20,000 characters.");const t=[...new Map(e.tags.split(",").filter(a=>U(a).length>0).map(a=>{const o=te(a,"tag");return[L(o),o]})).values()];if(t.length>J)throw new Error(`A bookmark can have at most ${J} tags.`);const r=e.folder.split("/").filter(a=>U(a).length>0);if(r.length>ee)throw new Error(`A folder path can have at most ${ee} levels.`);const n=r.map(a=>te(a,"folder"));return{note:e.description,tags:t,folderPath:n}}function z(e){if(e?.aborted)throw new DOMException("The operation was aborted.","AbortError")}async function T(e,t,r){z(r);const n=await e(t);if(z(r),!n.ok)throw new Error(n.error.message||n.error.code);return n.data}function re(e){return typeof e=="object"&&e!==null&&Array.isArray(e.tags)}function Le(e,t){if(typeof e!="object"||e===null)return!1;const r=e.bookmark;return typeof r=="object"&&r!==null&&r.id===t&&Array.isArray(r.tagIds)&&r.tagIds.every(n=>typeof n=="string")}function ae(e){return typeof e=="object"&&e!==null&&Array.isArray(e.folders)}function Oe(e,t){if(!e)return"";const r=new Map(t.map(s=>[s.id,s])),n=[],a=new Set;let o=r.get(e);for(;o&&!a.has(o.id);)a.add(o.id),n.unshift(o.name),o=o.parentId?r.get(o.parentId):void 0;return n.join(" / ")}async function Re(e){const[t,r]=await Promise.all([T(e.send,{type:"LIST_TAGS"},e.signal),T(e.send,{type:"LIST_FOLDERS"},e.signal)]);if(!re(t)||!ae(r))throw new Error("Invalid metadata response.");const n=new Map(t.tags.map(a=>[a.id,a]));return{description:e.bookmark.note,folder:Oe(e.bookmark.folderId,r.folders),tags:e.bookmark.tagIds.map(a=>n.get(a)?.name).filter(a=>typeof a=="string").join(", ")}}async function Be(e,t){const[r,n]=await Promise.all([T(e.send,{type:"LIST_TAGS"},e.signal),T(e.send,{type:"GET_BOOKMARK",payload:{id:e.bookmark.id}},e.signal)]);if(!re(r))throw new Error("Invalid tag response.");if(!Le(n,e.bookmark.id))throw new Error("Invalid bookmark response.");const a=new Map(r.tags.map(u=>[u.id,u])),o=n.bookmark.tagIds.map(u=>a.get(u)).filter(u=>u!==void 0),s=new Map(t.map(u=>[L(u),u]));for(const u of o)s.has(L(u.normalizedName||u.name))||await T(e.send,{type:"REMOVE_BOOKMARK_TAG",payload:{id:e.bookmark.id,tagId:u.id}},e.signal);const i=new Set(o.map(u=>L(u.normalizedName||u.name)));for(const[u,l]of s)i.has(u)||await T(e.send,{type:"ADD_BOOKMARK_TAG",payload:{id:e.bookmark.id,name:l}},e.signal)}async function Ne(e,t){if(t.length===0)return null;const r=await T(e.send,{type:"LIST_FOLDERS"},e.signal);if(!ae(r))throw new Error("Invalid folder response.");const n=[...r.folders];let a=null;for(const o of t){let s=n.find(i=>i.parentId===a&&L(i.name)===L(o));if(!s){const i=await T(e.send,{type:"CREATE_FOLDER",payload:{name:o,parentId:a}},e.signal);if(!i?.folder)throw new Error("Invalid folder response.");const u=i.folder;s=u,n.push(u)}a=s.id}return a}async function Fe(e){const t=_e(e.values);z(e.signal),await T(e.send,{type:"SAVE_BOOKMARK_NOTE",payload:{id:e.bookmark.id,note:t.note}},e.signal),await Be(e,t.tags);const r=await Ne(e,t.folderPath);await T(e.send,{type:"ASSIGN_BOOKMARK_FOLDER",payload:{bookmarkId:e.bookmark.id,folderId:r}},e.signal)}const De=900,Pe=6e3;function Ke(e){if(typeof e!="object"||e===null)return!1;const t=e;return typeof t.id=="string"&&typeof t.text=="string"&&typeof t.url=="string"&&typeof t.author=="object"&&t.author!==null&&typeof t.author.id=="string"&&typeof t.author.username=="string"&&typeof t.author.name=="string"&&typeof t.postCreatedAt=="string"&&me(t.media,t.url)&&typeof t.note=="string"&&(t.folderId===null||typeof t.folderId=="string")&&Array.isArray(t.tagIds)&&t.tagIds.every(r=>typeof r=="string")&&typeof t.firstSavedAt=="string"&&typeof t.lastSeenAt=="string"&&(t.archivedAt===null||typeof t.archivedAt=="string")&&typeof t.metadataUpdatedAt=="string"&&(t.status==="current"||t.status==="archived")}function Ue(e){return e.dataset.testid==="bookmark"?"save":e.dataset.testid==="removeBookmark"?"remove":null}function qe(e,t){const r=e.querySelector('button[data-testid="bookmark"], button[data-testid="removeBookmark"]');return r?t==="save"?r.dataset.testid==="removeBookmark"||r.getAttribute("aria-pressed")==="true":r.dataset.testid==="bookmark"||r.getAttribute("aria-pressed")==="false":!1}function ze(e){return new Promise(t=>{let r=!1,n=null;const a=l=>{r||(r=!0,s.disconnect(),n!==null&&clearTimeout(n),clearTimeout(i),e.signal.removeEventListener("abort",u),t(l))},o=()=>{qe(e.article,e.action)?n??=setTimeout(()=>a(!0),e.stableForMs):n!==null&&(clearTimeout(n),n=null)},s=new MutationObserver(o),i=setTimeout(()=>a(!1),e.timeoutMs),u=()=>a(!1);e.signal.addEventListener("abort",u,{once:!0}),s.observe(e.document.documentElement,{attributes:!0,attributeFilter:["aria-pressed","data-testid"],childList:!0,subtree:!0}),o()})}function Ge(){return crypto.randomUUID()}function He(e){return{close:e("bookmarkPromptClose"),description:e("bookmarkPromptNote"),folder:e("bookmarkPromptFolder"),save:e("bookmarkPromptSave"),tags:e("bookmarkPromptTags"),pending:e("liveBookmarkPending")}}function Ve(e){const t=new Map,r=new Map;let n=!1;const a=async(s,i,u)=>{const l=t.get(i.id);l?.controller.abort(),l?.metadataController?.abort();const g=r.get(i.id);g?.controller.abort(),g?.metadataController?.abort(),g?.modal?.destroy(),r.delete(i.id);const m={controller:new AbortController,intentId:Ge(),metadataController:null,modal:null};t.set(i.id,m);const k={type:"LIVE_BOOKMARK_PENDING",intentId:m.intentId,action:s,bookmark:i};e.onPending?.(u,i.id);const v=e.send(k),E=ze({document:e.document,article:u,action:s,signal:m.controller.signal,stableForMs:e.stableForMs??De,timeoutMs:e.timeoutMs??Pe}),b=await v.catch(()=>null),c=b?.ok?b.data:null;if(!n&&!m.controller.signal.aborted&&c?.prompt&&c.surface==="modal"){let f=null;const d=new AbortController;m.metadataController=d;let y=null,A=null,I=null;const w=S=>(A=S,I??=Promise.resolve().then(async()=>{for(;A;){const x=A;if(A=null,!y)throw new Error("Bookmark metadata is not ready.");await Fe({bookmark:y,values:x,send:e.send,signal:d.signal})}}).finally(()=>{I=null}),I);f=Se({document:e.document,title:e.translate("bookmarkPromptTitle"),bookmarkTitle:i.text||i.url,labels:He(e.translate),onSave:async S=>{m.modal?.setState("pending",e.translate("liveBookmarkPending"));try{await w(S),e.onChanged?.(i.id),m.modal?.setState("ready",e.translate("liveBookmarkSaved"))}catch{d.signal.aborted||m.modal?.setState("ready",e.translate("liveBookmarkFailed"))}},onClose:()=>{f&&r.get(i.id)===m&&(r.delete(i.id),m.metadataController?.abort(),m.metadataController=null,m.modal=null,delete m.prepareMetadata,f.destroy(),f=null)}}),m.modal=f,r.set(i.id,m),f.open(),m.prepareMetadata=async S=>{y=S;const x=await Re({bookmark:S,send:e.send,signal:d.signal});d.signal.aborted||f?.setValues(x)}}const p=await E;if(n||t.get(i.id)!==m)return;if(!p){await e.send({type:"LIVE_BOOKMARK_CANCELLED",intentId:m.intentId}).catch(()=>{}),m.modal?.setState("error",e.translate("liveBookmarkFailed")),e.onChanged?.(i.id),t.delete(i.id);return}const h=await e.send({type:"LIVE_BOOKMARK_CONFIRMED",intentId:m.intentId,action:s,bookmark:i}).catch(()=>null);if(h?.ok)if(s==="save"){const f=h.data?.bookmark;try{if(m.modal){if(!Ke(f))throw new Error("Invalid bookmark response.");await m.prepareMetadata?.(f)}m.controller.signal.aborted||m.modal?.setState("ready",e.translate("liveBookmarkSaved"))}catch{m.controller.signal.aborted||m.modal?.setState("ready",e.translate("liveBookmarkFailed"))}}else m.modal?.setState("success",e.translate("liveBookmarkArchived"));else m.modal?.setState("error",e.translate("liveBookmarkFailed"));e.onChanged?.(i.id),t.delete(i.id)},o=s=>{if(n||!(s.target instanceof Element))return;const i=s.target.closest("button");if(!i)return;const u=Ue(i);if(!u)return;const l=i.closest('article[data-testid="tweet"]');if(!l)return;const g=$(l)[0];g&&a(u,g,l)};return e.document.addEventListener("click",o,!0),{stop(){if(!n){n=!0,e.document.removeEventListener("click",o,!0);for(const s of t.values())s.controller.abort(),s.metadataController?.abort();for(const s of new Set(r.values()))s.controller.abort(),s.metadataController?.abort(),s.modal?.destroy();t.clear(),r.clear()}}}}function ne(e,t){return(!t.note||e.note.trim().length>0)&&(!t.tags||e.tagIds.length>0)&&(!t.breadcrumb||e.folderId!==null)}const N='article[data-testid="tweet"]',oe="bookmark-x-metadata",je=/^\/[A-Za-z0-9_]+\/status\/(\d+)$/,$e={appearance:{largeText:!0,highContrast:!0,reduceMotion:!1},behavior:{surface:"modal",promptAfterBookmark:!0,metadata:{summary:!0,breadcrumb:!0,tags:!0,note:!0,categoryIndicator:!0}},export:{includeLink:!0,includeText:!0,includeAuthor:!0,includeDate:!0,includeImages:!0,includeVideos:!0,includeNote:!0,includeTags:!0,includeFolder:!0,includeFirstSavedAt:!0,includeLastSeenAt:!0},search:{filterAsYouType:!0},data:{keepArchived:!0}},Xe=String.raw`
  :host {
    --bx-accent: #a8d500;
    --bx-border: #53610d;
    --bx-ink: #152000;
    --bx-muted: #384511;
    --bx-surface: #f8ffe2;
    color: var(--bx-ink);
    display: block;
    font-family: ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
    font-size: 16px;
    line-height: 1.5;
    min-width: 0;
  }

  :host([data-large-text="true"]) { font-size: 18px; }

  .card {
    background: var(--bx-surface);
    border: 1px solid var(--bx-border);
    border-left: 4px solid var(--bx-accent);
    border-radius: 0 10px 10px 0;
    box-sizing: border-box;
    display: grid;
    gap: 8px;
    margin: 8px 12px 4px;
    max-width: calc(100% - 24px);
    padding: 10px 12px;
  }

  .status-row, .tags, .breadcrumb {
    align-items: center;
    display: flex;
    flex-wrap: wrap;
    gap: 6px;
    min-width: 0;
  }

  .status, .category, .tag {
    border: 1px solid currentColor;
    border-radius: 999px;
    font-size: 0.875em;
    font-weight: 750;
    letter-spacing: 0.01em;
    padding: 2px 8px;
    max-width: 100%;
    overflow-wrap: anywhere;
    white-space: normal;
  }

  .status::before { content: "✓ "; }
  .status[data-state="pending"]::before { content: "… "; }
  .status[data-state="archived"]::before { content: "↺ "; }
  .category::before { content: "! "; }
  .category { background: #fff3c4; color: #5b4100; }
  .tag { background: #e6f5b2; color: #253300; font-weight: 650; }

  .breadcrumb { color: var(--bx-muted); font-weight: 650; }
  .crumb + .crumb::before { content: "›"; margin-inline-end: 6px; }

  .note {
    color: var(--bx-ink);
    display: -webkit-box;
    margin: 0;
    overflow: hidden;
    overflow-wrap: anywhere;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 2;
  }

  .visually-hidden {
    border: 0;
    clip: rect(0 0 0 0);
    height: 1px;
    margin: -1px;
    overflow: hidden;
    padding: 0;
    position: absolute;
    white-space: nowrap;
    width: 1px;
  }

  :host([data-high-contrast="true"]) {
    --bx-accent: #b9f300;
    --bx-border: #111;
    --bx-ink: #080a00;
    --bx-muted: #252b13;
    --bx-surface: #fbffe9;
  }

  @media (prefers-color-scheme: dark) {
    :host {
      --bx-accent: #c8ff3d;
      --bx-border: #a7bd68;
      --bx-ink: #f4ffd6;
      --bx-muted: #d5e5a9;
      --bx-surface: #172000;
    }
    .category { background: #3a2b00; color: #ffe28a; }
    .tag { background: #2e3b0d; color: #efffc0; }
  }

  @media (forced-colors: active) {
    .card, .status, .category, .tag { border-color: CanvasText; }
    .card { background: Canvas; color: CanvasText; }
  }

  @media (prefers-reduced-motion: reduce) {
    *, *::before, *::after {
      animation-duration: 0.01ms !important;
      animation-iteration-count: 1 !important;
      transition-duration: 0.01ms !important;
    }
  }

  :host([data-reduce-motion="true"]) *,
  :host([data-reduce-motion="true"]) *::before,
  :host([data-reduce-motion="true"]) *::after {
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.01ms !important;
  }
`;function F(e,t,r,n,a){const o=e.createElement(r);return o.className=n,o.textContent=a,t.append(o),o}function We(e){return Object.values(e.behavior.metadata).some(Boolean)}function se(e){const{document:t,host:r,item:n,settings:a,translate:o}=e,s=r.shadowRoot??r.attachShadow({mode:"open"}),i=t.createElement("style");i.textContent=Xe;const u=t.createElement("section");if(u.className="card",r.dataset.bookmarkId=n.bookmark.id,r.dataset.largeText=String(a.appearance.largeText),r.dataset.highContrast=String(a.appearance.highContrast),r.dataset.reduceMotion=String(a.appearance.reduceMotion),r.dataset.state=e.pending?"pending":n.bookmark.status==="archived"?"archived":ne(n.bookmark,a.behavior.metadata)?"mapped":"uncategorized",r.setAttribute("aria-label",o("bookmarkMetadataLabel")),r.setAttribute("role","group"),a.behavior.metadata.summary||!e.pending&&a.behavior.metadata.categoryIndicator){const l=t.createElement("div");if(l.className="status-row",a.behavior.metadata.summary){const g=F(t,l,"span","status",e.pending?o("liveBookmarkPending"):n.bookmark.status==="archived"?o("bookmarkMetadataArchived"):o("bookmarkMetadataMapped"));g.dataset.state=e.pending?"pending":n.bookmark.status==="archived"?"archived":"mapped"}!e.pending&&a.behavior.metadata.categoryIndicator&&!ne(n.bookmark,a.behavior.metadata)&&F(t,l,"span","category",o("bookmarkNeedsCategory")),u.append(l)}if(!e.pending&&a.behavior.metadata.breadcrumb){const l=t.createElement("div");l.className="breadcrumb",l.setAttribute("aria-label",o("bookmarkPromptFolder"));const g=n.breadcrumb.length?n.breadcrumb:[o("uncategorizedFolder")];for(const m of g)F(t,l,"span","crumb",m);u.append(l)}if(!e.pending&&a.behavior.metadata.tags&&n.tags.length>0){const l=t.createElement("div");l.className="tags",l.setAttribute("aria-label",o("bookmarkPromptTags"));for(const g of n.tags)F(t,l,"span","tag",g.name);u.append(l)}if(!e.pending&&a.behavior.metadata.note&&n.bookmark.note.trim().length>0){const l=t.createElement("p");l.className="note",F(t,l,"span","visually-hidden",`${o("bookmarkPromptNote")}: `),l.append(t.createTextNode(n.bookmark.note)),u.append(l)}s.replaceChildren(i,u)}function ie(e){for(const t of Array.from(e.querySelectorAll('a[href*="/status/"]')))try{const r=new URL(t.href,location.href).pathname.match(je);if(r?.[1])return r[1]}catch{}return null}function Ye(e){const t=e.querySelector('button[data-testid="bookmark"], button[data-testid="removeBookmark"]');return t?.closest('[role="group"]')??t}function Qe(e,t){const r=e.defaultView;return typeof r?.requestAnimationFrame=="function"?r.requestAnimationFrame(t):(queueMicrotask(()=>t(performance.now())),0)}function Ze(e){const t=new Map,r=new Map,n=new Set;let a=!1,o=null,s=0,i=null,u=c=>c;const l=c=>{t.get(c)?.host.remove(),t.delete(c),r.delete(c)},g=(c,p)=>{const h=Ye(c);if(!h)return null;const f=t.get(c);if(f?.bookmarkId===p&&f.host.isConnected)return f.host;l(c);const d=e.document.createElement(oe);return h.insertAdjacentElement("afterend",d),t.set(c,{bookmarkId:p,host:d}),d},m=async()=>{if(o=null,a)return;const c=++s;for(const f of[...t.keys()])f.isConnected||l(f);const p=[...n].filter(f=>f.isConnected);n.clear();const h=new Map;for(const f of p){const d=ie(f);if(!d){l(f);continue}const y=h.get(d)??[];y.push(f),h.set(d,y)}if(h.size!==0)try{const f=[...h.keys()];let d=null;const y=[];for(let w=0;w<f.length;w+=100){const S=await e.lookup(f.slice(w,w+100));if(a||c!==s)return;d=S,y.push(...S.items)}if(!d)return;d={...d,items:y};const A=w=>d.messages[w]??w;if(a||c!==s)return;i=d,u=A;const I=new Map(d.items.map(w=>[w.bookmark.id,w]));for(const[w,S]of h){const x=I.get(w);for(const C of S){if(!x){if(r.get(C)===w)continue;l(C);continue}if(!We(d.settings)){l(C);continue}const K=g(C,w);K&&se({document:e.document,host:K,item:x,settings:d.settings,translate:A,pending:r.get(C)===w})}}}catch{}},k=()=>{a||o!==null||(o=(e.scheduleFrame??(c=>Qe(e.document,c)))(()=>{m()}))},v=c=>{n.add(c),k()},E=c=>{if(!(c instanceof Element))return;c.matches(N)&&v(c);for(const h of Array.from(c.querySelectorAll(N)))v(h);const p=c.closest(N);p&&v(p)},b=new MutationObserver(c=>{for(const p of c)if(!(p.type==="childList"&&[...Array.from(p.addedNodes),...Array.from(p.removedNodes)].length>0&&[...Array.from(p.addedNodes),...Array.from(p.removedNodes)].every(h=>h instanceof Element&&h.localName===oe))){E(p.target);for(const h of Array.from(p.addedNodes))E(h);for(const h of Array.from(p.removedNodes))E(h)}});b.observe(e.document.documentElement,{attributes:!0,attributeFilter:["href","data-testid"],childList:!0,subtree:!0});for(const c of Array.from(e.document.querySelectorAll(N)))v(c);return{refresh(c){for(const[p,h]of r)(!c||h===c)&&r.delete(p);for(const p of Array.from(e.document.querySelectorAll(N)))(!c||ie(p)===c)&&v(p)},setPending(c,p){const h=g(c,p);if(!h)return;const f=i?.settings??$e;if(!f.behavior.metadata.summary){l(c);return}r.set(c,p);const y=i?.items.find(A=>A.bookmark.id===p)??{bookmark:{id:p,text:"",url:"",author:{id:"",username:"",name:""},postCreatedAt:"",media:{images:[],videos:[]},note:"",folderId:null,tagIds:[],firstSavedAt:"",lastSeenAt:"",archivedAt:null,metadataUpdatedAt:"",status:"current"},breadcrumb:[],tags:[]};se({document:e.document,host:h,item:y,settings:f,translate:u,pending:!0})},stop(){if(!a){a=!0,s+=1,b.disconnect(),o!==null&&o!==0&&(e.cancelFrame?e.cancelFrame(o):e.document.defaultView?.cancelAnimationFrame(o));for(const c of[...t.keys()])l(c);n.clear(),r.clear()}}}}let M;function ce(e){return chrome.runtime.sendMessage(e)}class G extends Error{constructor(t){super(`Capture event was rejected: ${t}`),this.code=t}code}async function D(e){const t=await ce(e);if(typeof t!="object"||t===null)throw new G("invalid_response");const r=t;if(r.ok===!0)return;const n=r.error,a=typeof n=="object"&&n!==null&&typeof n.code=="string"?String(n.code):"rejected";throw new G(a)}async function Je(e,t,r){try{const n=await ke({scan:()=>$(document),checkpointIds:r,isLoading:()=>B(document),isPageValid:()=>{const a=new URL(window.location.href);return(a.hostname==="x.com"||a.hostname==="www.x.com")&&(a.pathname==="/i/bookmarks"||a.pathname.startsWith("/i/bookmarks/"))},isAtEnd:()=>{const a=document.scrollingElement??document.documentElement;return ye({scrollTop:Math.max(window.scrollY,a.scrollTop),viewportHeight:window.innerHeight,documentHeight:a.scrollHeight})},scroll:()=>{Ae(document,{viewportHeight:window.innerHeight,scrollBy:()=>{window.scrollBy({top:Math.max(Math.round(window.innerHeight*.9),640),behavior:"auto"})}})},waitForContent:a=>Ee({root:document.querySelector("main")??document.body,view:window,signal:a}),signal:t.signal,onBatch:async a=>{await D({type:"SCRAPE_BATCH",runId:e,bookmarks:a})},onProgress:async({fetched:a})=>{await D({type:"SCRAPE_PROGRESS",runId:e,fetched:a})}});if(n.status==="incomplete"){await D({type:"SCRAPE_FAILED",runId:e,errorCode:n.errorCode??"scrape_incomplete"});return}if(n.status==="completed"){await D({type:"SCRAPE_COMPLETE",runId:e,status:"completed",fetched:n.fetched,completionReason:n.completionReason??"stable_end"});return}await D({type:"SCRAPE_COMPLETE",runId:e,status:"cancelled",fetched:n.fetched})}catch(n){if(n instanceof G&&n.code==="stale_capture")return;try{await ce({type:"SCRAPE_FAILED",runId:e,errorCode:t.signal.aborted?"capture_cancelled":"scrape_failed"})}catch{}}finally{M?.runId===e&&(M=void 0)}}function et(e){if(typeof e!="object"||e===null)return!1;const t=e;return t.type==="REFRESH_BOOKMARK_METADATA"?t.bookmarkIds===void 0||Array.isArray(t.bookmarkIds)&&t.bookmarkIds.length<=100&&t.bookmarkIds.every(r=>typeof r=="string"&&/^\d+$/.test(r)):typeof t.runId!="string"?!1:t.type==="CANCEL_SCRAPE"?!0:t.type!=="START_SCRAPE"||t.mode!=="quick"&&t.mode!=="full"||!Array.isArray(t.checkpointIds)||t.checkpointIds.length>10?!1:t.checkpointIds.every(r=>typeof r=="string"&&/^\d+$/.test(r))&&new Set(t.checkpointIds).size===t.checkpointIds.length}const P=Ze({document,async lookup(e){const t=await chrome.runtime.sendMessage({type:"GET_BOOKMARK_DECORATIONS",payload:{ids:e}});if(!t.ok)throw new Error(t.error.message);return t.data}});chrome.runtime.onMessage.addListener((e,t,r)=>{if(t.id!==chrome.runtime.id||!et(e))return r({accepted:!1}),!1;if(e.type==="REFRESH_BOOKMARK_METADATA"){if(e.bookmarkIds)for(const a of e.bookmarkIds)P.refresh(a);else P.refresh();return r({accepted:!0}),!1}if(e.type==="CANCEL_SCRAPE")return M?.runId===e.runId&&M.controller.abort(),r({accepted:!0}),!1;if(M)return r({accepted:!1,reason:"capture_in_progress"}),!1;const n=new AbortController;return M={runId:e.runId,controller:n},r({accepted:!0}),Je(e.runId,n,e.checkpointIds),!1});const tt=Ve({document,send:e=>chrome.runtime.sendMessage(e),translate:e=>chrome.i18n.getMessage(e)||e,onPending:(e,t)=>P.setPending(e,t),onChanged:e=>P.refresh(e)});window.addEventListener("pagehide",()=>{M?.controller.abort(),tt.stop(),P.stop()},{once:!0})})();
