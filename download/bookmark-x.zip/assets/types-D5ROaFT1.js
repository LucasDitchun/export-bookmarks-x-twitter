const e=["en","pt_BR","ja","es","zh_CN","de","fr","it"];function n(t){return typeof t=="string"&&e.includes(t)}export{n as i};
